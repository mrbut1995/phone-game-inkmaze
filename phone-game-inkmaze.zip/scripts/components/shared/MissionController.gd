class_name MissionController
extends Node
## ============================================================================
## Controller: tối đa 3 Nhiệm vụ (Mission) của mỗi màn/tầng — nguồn tính Sao.
##
## LUẬT (Number_Maze_Game_Design.md — mục 3.1 & 5.10):
##   - Mỗi match-up (Màn ở Play Mode / Tầng ở Dungeon Mode / ngày Daily) có TỐI ĐA 3 Nhiệm vụ.
##   - Hoàn thành 1 Nhiệm vụ = 1 Sao. Sao KHÔNG tính theo thời gian còn lại.
##   - Màn chưa chọn nhiệm vụ (màn cũ) -> dùng 3 nhiệm vụ mặc định:
##        no_wall · steps_max (N = max_steps) · time_max (T = N × 3, kẹp 30..240s)
##
## 17 loại nhiệm vụ: xem MissionTypes (id · nhãn · loại tham số). Riêng chế độ có thể khai báo
## bộ 3 nhiệm vụ MẶC ĐỊNH của mình qua `BaseGameMode.default_missions()` (VD Wall Builder:
## no_wrong_submit · time_max · no_hint — §5.13).
## Nhiệm vụ do LevelData khai báo qua `mission_types` + `mission_params` (mảng song song).
##
## HUD: panel "NHIỆM VỤ" nằm trong HUD của chế độ (node Mission của
## nodes/hud/level_mode.tscn) — GameScene gắn node đó vào `card` mỗi lần đổi chế độ.
## Popup thua/kết quả lấy dữ liệu qua rows() (danh sách nhiệm vụ + trạng thái) và stars().
## ============================================================================

signal updated

const SECONDS_PER_STEP := 3.0
const MIN_TIME_LIMIT := 30.0
const MAX_TIME_LIMIT := 240.0

## Thẻ NHIỆM VỤ trên HUD — `GameScene._bind_hud_nodes()` gán theo HUD của chế độ đang chơi.
## Controller CHỈ đưa TRẠNG THÁI vào `MissionCard.refresh()`; thẻ tự lấy node con + chọn art/màu.
@export var card: MissionCard = null

## Ngưỡng mặc định của màn/tầng đang chơi
var step_limit := 0
var time_limit := 0.0
## Chế độ đang chơi — để lấy BỘ NHIỆM VỤ MẶC ĐỊNH riêng của chế độ (xem default_missions)
var _mode: BaseGameMode = null

## Nhiệm vụ của màn hiện tại: [{ type, param }]
var _entries: Array[Dictionary] = []
## Trạng thái hiện tại: [{ type, title, done, status, on_track }]
var _rows: Array[Dictionary] = []
## Khoá trạng thái lần vẽ trước (tránh format chuỗi lại mỗi frame)
var _last_key := ""
## Số ô thuộc board (để tính % độ dài đường đi / đi hết ô)
var _board_cells := 0

signal mission_update()

func _ready() -> void:
	setup_for_floor(0)
	var ctx := MissionContext.new()
	ctx.set_values(null, null, null, [], 0.0, false)
	refresh(ctx)


## Gọi khi bắt đầu màn/tầng. `level_data = null` -> dùng 3 nhiệm vụ mặc định.
func setup_for_floor(design_steps: int, level_data: LevelData = null,
		mode: BaseGameMode = null) -> void:
	step_limit = maxi(design_steps, 1)
	time_limit = clampf(float(step_limit) * SECONDS_PER_STEP, MIN_TIME_LIMIT, MAX_TIME_LIMIT)
	_mode = mode
	_entries = _resolve_entries(level_data)
	_board_cells = 0
	_build_rows()
	_last_key = ""
	_refresh_hud()


## Cập nhật trạng thái nhiệm vụ theo số liệu ván đang chơi.
## `ctx.final = true` khi màn/tầng đã kết thúc -> chốt ĐẠT/CHƯA ĐẠT để tính Sao cho popup.
func refresh(ctx: MissionContext) -> void:
	if ctx == null or ctx.state == null:
		return
	if _entries.is_empty():
		_entries = _resolve_entries(null)
	if _rows.size() != _entries.size():
		_build_rows()

	if _board_cells <= 0:
		_board_cells = _count_active_cells(ctx.maze)

	var metrics := _collect_metrics(ctx)
	# Khoá trạng thái: chỉ tính lại khi số liệu đổi (refresh được gọi mỗi frame)
	var key := "%d|%d|%d|%d|%d|%d|%d|%d|%d|%s|%s" % [
		ctx.state.floor_wall_hits,
		ctx.state.floor_moves,
		int(metrics["visited"]),
		int(metrics["revisits"]),
		int(metrics["sum"]),
		int(metrics["numbered_on_path"]),
		int(metrics["submit_misses"]),
		ctx.state.hints_used,
		ctx.state.teleports_used,
		str(int(ctx.elapsed)),
		str(ctx.final),
	]
	if key != _last_key:
		_last_key = key
		for i in _entries.size():
			var verdict := _evaluate(_entries[i], ctx, metrics, ctx.final)
			_rows[i]["done"] = verdict["done"]
			_rows[i]["status"] = verdict["status"]
			_rows[i]["on_track"] = verdict["on_track"]
		_refresh_hud()
		updated.emit()


## Danh sách nhiệm vụ + trạng thái: [{ type, title, done, status, on_track }, ...]
func rows() -> Array[Dictionary]:
	return _rows


## Số Sao = số nhiệm vụ đã hoàn thành
func stars() -> int:
	var total := 0
	for row in _rows:
		if bool(row.get("done", false)):
			total += 1
	return total


## Tổng số nhiệm vụ của màn (tối đa 3)
func mission_count() -> int:
	return _rows.size()


func all_done() -> bool:
	return stars() == _rows.size() and not _rows.is_empty()


# ---------------------------------------------------------------------------
# Dựng danh sách nhiệm vụ
# ---------------------------------------------------------------------------
func _resolve_entries(level_data: LevelData) -> Array[Dictionary]:
	var out: Array[Dictionary] = []
	if level_data != null:
		var types := level_data.mission_types
		var params := level_data.mission_params
		for i in mini(types.size(), MissionTypes.MAX_PER_LEVEL):
			var type_id := str(types[i])
			if not MissionTypes.is_valid(type_id):
				push_warning("MissionController: bo qua loai thu thach la '%s'" % type_id)
				continue
			var param := int(params[i]) if i < params.size() else 0
			if MissionTypes.has_param(type_id) and param <= 0:
				param = _default_param(type_id)
			out.append({"type": type_id, "param": param})
	if out.is_empty():
		out = _mode_defaults()
	if out.is_empty():
		for entry in MissionTypes.defaults_for(step_limit, time_limit):
			out.append(entry)
	return out


## Bộ nhiệm vụ mặc định RIÊNG của chế độ (VD Wall Builder: no_wrong_submit · time_max · no_hint).
## Rỗng = chế độ không khai báo gì -> MissionController dùng bộ chung.
func _mode_defaults() -> Array[Dictionary]:
	var out: Array[Dictionary] = []
	if _mode == null:
		return out
	for type_id in _mode.default_missions():
		if out.size() >= MissionTypes.MAX_PER_LEVEL:
			break
		if not MissionTypes.is_valid(type_id):
			continue
		var param := 0
		if MissionTypes.has_param(type_id):
			param = _default_param(type_id)
		out.append({"type": type_id, "param": param})
	return out


func _default_param(type_id: String) -> int:
	match MissionTypes.param_kind(type_id):
		MissionTypes.PARAM_STEPS:
			return step_limit
		MissionTypes.PARAM_SECONDS:
			return int(round(time_limit))
		MissionTypes.PARAM_PERCENT:
			return 50
		MissionTypes.PARAM_SUM:
			return 20
		_:
			return 0


func _build_rows() -> void:
	_rows = []
	for entry in _entries:
		_rows.append({
			"type": str(entry.get("type", "")),
			"title": _title_for(entry),
			"done": false,
			"status": tr("STR_MISSION_NOT_DONE"),
			"on_track": true,
		})


## Nhãn hiển thị của nhiệm vụ (đã điền tham số nếu có)
func _title_for(entry: Dictionary) -> String:
	var type_id := str(entry.get("type", ""))
	var key := MissionTypes.label_key(type_id)
	if key.is_empty():
		return type_id
	var text := tr(key)
	if MissionTypes.has_param(type_id):
		return text.format([int(entry.get("param", 0))])
	return text


# ---------------------------------------------------------------------------
# Số liệu của đường đi hiện tại
# ---------------------------------------------------------------------------
func _collect_metrics(ctx: MissionContext) -> Dictionary:
	var visited := {}
	var revisits := 0
	var sum := 0
	var start := ctx.maze.get_start() if ctx.maze != null else Vector2i(-1, -1)
	var end := ctx.maze.get_end() if ctx.maze != null else Vector2i(-1, -1)

	for pos in ctx.path:
		if visited.has(pos):
			revisits += 1
		else:
			visited[pos] = true
		if ctx.maze == null or pos == start or pos == end:
			continue
		var number := _cell_number(pos, ctx)
		if number >= 0:
			sum += number

	# Đếm số ô có số trên toàn board (để kiểm tra "đi qua hết mọi ô có số")
	var board_numbered := 0
	if ctx.maze != null:
		for y in ctx.maze.height:
			for x in ctx.maze.width:
				var pos := Vector2i(x, y)
				if not ctx.maze.is_cell_active(pos) or pos == start or pos == end:
					continue
				if _cell_number(pos, ctx) >= 0:
					board_numbered += 1

	# Ô "có số" mà người chơi đã đi
	var numbered_on_path := 0
	for pos in visited.keys():
		if pos == start or pos == end:
			continue
		if _cell_number(pos, ctx) >= 0:
			numbered_on_path += 1

	return {
		"visited": visited.size(),
		"revisits": revisits,
		"cells": visited,               # Dictionary<Vector2i, bool>
		"sum": sum,
		"numbered_on_path": numbered_on_path,
		"board_numbered": board_numbered,
		"board_cells": _board_cells,
		"submit_misses": _submit_miss_count(ctx),
	}


## Số lần GỬI SAI (Wall Builder) — chế độ khác luôn trả 0
func _submit_miss_count(ctx: MissionContext) -> int:
	return ctx.mode.submit_miss_count() if ctx.mode != null else 0


## Số hiển thị trên ô (-1 = ô không có số; S/F trả về "S"/"F" nên cũng là -1)
func _cell_number(pos: Vector2i, ctx: MissionContext) -> int:
	if ctx.mode == null or ctx.maze == null or not ctx.maze.is_in_bounds(pos):
		return -1
	var text := ctx.mode.get_cell_text(pos, ctx.maze)
	if text.is_empty() or not text.is_valid_int():
		return -1
	return int(text)


func _count_active_cells(maze: MazeData) -> int:
	if maze == null:
		return 0
	if maze.is_full_rect():
		return maze.width * maze.height
	var total := 0
	for y in maze.height:
		for x in maze.width:
			if maze.is_cell_active(Vector2i(x, y)):
				total += 1
	return total


# ---------------------------------------------------------------------------
# Chấm điểm từng loại nhiệm vụ
# ---------------------------------------------------------------------------
func _evaluate(entry: Dictionary, ctx: MissionContext, m: Dictionary, is_final: bool) -> Dictionary:
	var type_id := str(entry.get("type", ""))
	var param := int(entry.get("param", 0))
	var state := ctx.state

	match type_id:
		MissionTypes.NO_WALL:
			var hits := state.floor_wall_hits
			var ok := hits == 0
			return _verdict(ok, _pass_fail(ok))

		MissionTypes.STEPS_MAX:
			var moves := state.floor_moves
			var ok := moves <= param
			if is_final:
				return _verdict(ok, _pass_fail(ok))
			return _pending(tr("STR_MISSION_STEPS_PROGRESS").format([moves, param]), ok)

		MissionTypes.TIME_MAX:
			var left := float(param) - ctx.elapsed
			var ok := left >= 0.0
			if is_final:
				return _verdict(ok, _pass_fail(ok))
			var text := tr("STR_MISSION_TIME_LEFT").format([int(ceil(left))]) if ok \
				else tr("STR_MISSION_TIME_OVER").format([int(ceil(-left))])
			return _pending(text, ok)

		MissionTypes.ONLY_NUMBERED:
			var bad := _offending_cells(ctx, m, false)
			if bad > 0:
				return _verdict(false, tr("STR_MISSION_ST_VIOLATED"))
			return _verdict(true, tr("STR_MISSION_ST_NUMBERED_OK"))

		MissionTypes.AVOID_NUMBERED:
			var bad := _offending_cells(ctx, m, true)
			if bad > 0:
				return _verdict(false, tr("STR_MISSION_ST_VIOLATED"))
			return _verdict(true, tr("STR_MISSION_ST_OK"))

		MissionTypes.NO_REVISIT:
			var revisits := int(m["revisits"])
			if revisits > 0:
				return _verdict(false, tr("STR_MISSION_ST_REVISITED").format([revisits]))
			return _verdict(true, tr("STR_MISSION_ST_OK"))

		MissionTypes.VISIT_ALL:
			var visited := int(m["visited"])
			var cells := maxi(int(m["board_cells"]), 1)
			var ok := visited >= cells
			if ok:
				return _verdict(true, _pass_fail(true))
			if is_final:
				return _verdict(false, _pass_fail(false))
			return _pending(tr("STR_MISSION_ST_VISIT_ALL").format([visited, cells]), true)

		MissionTypes.VISIT_ALL_NUMBERED:
			var done_cells := int(m["numbered_on_path"])
			var need := int(m["board_numbered"])
			var ok := need == 0 or done_cells >= need
			if ok:
				return _verdict(true, _pass_fail(true))
			if is_final:
				return _verdict(false, _pass_fail(false))
			return _pending(tr("STR_MISSION_ST_VISIT_ALL").format([done_cells, need]), true)

		MissionTypes.LEN_MIN_PERCENT:
			return _percent_verdict(int(m["visited"]), int(m["board_cells"]), param, true, is_final)

		MissionTypes.LEN_MAX_PERCENT:
			return _percent_verdict(int(m["visited"]), int(m["board_cells"]), param, false, is_final)

		MissionTypes.SUM_LT:
			return _sum_verdict(int(m["sum"]), param, "<", is_final)
		MissionTypes.SUM_LE:
			return _sum_verdict(int(m["sum"]), param, "<=", is_final)
		MissionTypes.SUM_GT:
			return _sum_verdict(int(m["sum"]), param, ">", is_final)
		MissionTypes.SUM_GE:
			return _sum_verdict(int(m["sum"]), param, ">=", is_final)

		MissionTypes.NO_HINT:
			var used := state.hints_used
			var ok := used == 0
			return _verdict(ok, _pass_fail(ok) if ok else tr("STR_MISSION_ST_HINT_USED").format([used]))

		MissionTypes.NO_TELEPORT:
			var used := state.teleports_used
			var ok := used == 0
			return _verdict(ok, _pass_fail(ok) if ok else tr("STR_MISSION_ST_TELEPORT_USED").format([used]))

		MissionTypes.NO_WRONG_SUBMIT:
			# Wall Builder: GỬI ĐÚNG NGAY Ở LẦN GỬI ĐẦU TIÊN (không được nộp sai lần nào)
			var misses := int(m["submit_misses"])
			if misses > 0:
				return _verdict(false, tr("STR_MISSION_ST_SUBMIT_MISSED").format([misses]))
			if is_final:
				return _verdict(true, _pass_fail(true))
			return _pending(tr("STR_MISSION_ST_OK"), true)

		_:
			return _verdict(false, tr("STR_MISSION_NOT_DONE"))


## Đếm số ô đã đi VI PHẠM: `forbid_numbered = false` -> chỉ được đi ô có số;
## `true` -> không được đi ô có số.
func _offending_cells(ctx: MissionContext, m: Dictionary, forbid_numbered: bool) -> int:
	var cells: Dictionary = m["cells"]
	var start := ctx.maze.get_start() if ctx.maze != null else Vector2i(-1, -1)
	var end := ctx.maze.get_end() if ctx.maze != null else Vector2i(-1, -1)
	var bad := 0
	for pos in cells.keys():
		if pos == start or pos == end:
			continue
		var has_number := _cell_number(pos, ctx) >= 0
		if forbid_numbered and has_number:
			bad += 1
		elif not forbid_numbered and not has_number:
			bad += 1
	return bad


func _percent_verdict(visited: int, cells: int, percent: int, need_min: bool, is_final: bool) -> Dictionary:
	var total := maxi(cells, 1)
	var got := int(round(100.0 * float(visited) / float(total)))
	var ok := got >= percent if need_min else got <= percent
	if is_final:
		return _verdict(ok, _pass_fail(ok))
	var text := tr("STR_MISSION_ST_VISITED_PCT").format([got])
	return _pending(text, ok)


func _sum_verdict(current: int, target: int, op: String, is_final: bool) -> Dictionary:
	var ok := false
	match op:
		"<":
			ok = current < target
		"<=":
			ok = current <= target
		">":
			ok = current > target
		_:
			ok = current >= target
	if is_final:
		return _verdict(ok, _pass_fail(ok))
	return _pending(tr("STR_MISSION_ST_PATH_SUM").format([current]), ok)


# ---------------------------------------------------------------------------
# Nội bộ
# ---------------------------------------------------------------------------
func _pass_fail(ok: bool) -> String:
	return tr("STR_MISSION_DONE") if ok else tr("STR_MISSION_NOT_DONE")


## Kết quả CHỐT (cuối màn/tầng): có đạt hay không — chưa đạt thì không còn cơ hội nữa
func _verdict(done: bool, status: String) -> Dictionary:
	return {"done": done, "status": status, "on_track": true}


## Kết quả TẠM (đang chơi): chưa đạt · `on_track` = còn khả năng đạt (xem MissionCard)
func _pending(status: String, on_track: bool) -> Dictionary:
	return {"done": false, "status": status, "on_track": on_track}


## Vẽ trạng thái các nhiệm vụ lên thẻ HUD "NHIỆM VỤ" (mockup matchup_level.svg).
## Controller chỉ đưa TRẠNG THÁI (đạt · còn cơ hội) — thẻ `MissionCard` tự lấy node con,
## tự chọn art/màu
func _refresh_hud() -> void:
	if card == null:
		return
	card.refresh(_rows, stars(), maxi(_rows.size(), 1),
		tr("STR_MISSION_DONE_COUNT").format([stars()]))
