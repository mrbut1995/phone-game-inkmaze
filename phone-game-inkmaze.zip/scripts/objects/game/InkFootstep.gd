class_name InkFootstep
extends Control
## ============================================================================
## Vệt mực "bước chân" khi nhân vật đi qua một ô (nodes/game/ink_footstep.tscn)
##
## Là SCENE riêng: cỡ 36×36 · con "Mark" bám kín · alpha mờ 0.45.
## Hiệu ứng lan to + mờ dần (và tự xoá) khai trong `ink_footstep.tscn` (AnimationPlayer autoplay).
## Bàn chỉ việc: `footstep.setup(tâm_ô, texture_ngòi_bút, màu_mực)`.
##
## MỌI tham số (node · cỡ · alpha) chỉnh TRONG `ink_footstep.tscn` — script chỉ `@export`.
## ============================================================================

## Scene contract
## Exports:  SIZE, ALPHA, mark
## Emits:    (none)
## Handlers wired in scene: (none)
## Subscribes in code (EventBus/Model): (none)

@export var SIZE := Vector2(18, 18)
@export var ALPHA := 0.45

## Node binding: khai `node_paths` + NodePath trong `ink_footstep.tscn`
@export var mark: TextureRect = null


## Đặt vệt mực tại TÂM ô `pos` với texture + màu mực của ngòi bút đang dùng
func setup(pos: Vector2, cursor_tex: Texture2D, ink: Color) -> void:
	position = pos - SIZE * 0.5
	size = SIZE
	pivot_offset = SIZE * 0.5
	if cursor_tex != null:
		mark.texture = cursor_tex
	mark.modulate = Color(ink.r, ink.g, ink.b, ALPHA)
