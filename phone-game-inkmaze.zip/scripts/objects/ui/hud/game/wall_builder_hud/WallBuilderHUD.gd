class_name WallBuilderHUD
extends BaseHUD
## ============================================================================
## HUD Wall Builder.
##
## 2026-09-27 — theo yêu cầu "chỉ hiện thứ cần thiết": HUD này CHỈ hiện **THỜI GIAN**.
## Không thuộc HUD: bảng "TƯỜNG ĐÃ VẼ" (số đoạn · lượt GỬI · chip trạng thái · thanh tiến độ) — số tường
## người chơi đọc trực tiếp trên TỪNG Ô của bàn cờ (ô đủ tường sáng nền xanh), lượt GỬI còn lại
## hiện ở popup kết quả khi GỬI sai.
## ============================================================================

## Scene contract
## Exports:  (none)
## Emits:    (none)
## Handlers wired in scene: (none)
## Subscribes in code (EventBus/Model): (none)
