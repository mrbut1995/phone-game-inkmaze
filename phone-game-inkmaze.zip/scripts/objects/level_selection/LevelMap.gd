class_name LevelMap
extends Node2D
## ============================================================================
## LevelMap — Bản đồ road map dọc của màn Chọn màn
##
## Bố cục: các nút màn xếp kiểu RẮN (snake) từ dưới lên (màn 1 ở dưới cùng, hàng chẵn đi
## trái→phải, hàng lẻ phải→trái), nối nhau bằng MỘT đường `LevelMapPath` có cung quay đầu ở
## mép. Bản DỌC 3 cột · bản NGANG 5 cột (số đo bản ngang tính theo khung thiết kế 960×540 rồi
## nhân `design_unit()`). Cuộn bản đồ bằng cách dịch node `Tracks` (KHÔNG dùng Camera2D).
##
## Màn BONUS (cuối chương, `bonus_ids`) vẽ bằng nút màu cam + băng "BONUS"; cờ đích cắm ở màn
## CHÍNH cuối cùng. (Kiểu zigzag cũ chỉ còn khi đặt cột = 0.)
##
## Quy ước của project (CẤU HÌNH TĨNH nằm trong `level_map.tscn`):
##   · `Tracks` — node dịch chuyển khi cuộn (bind `@export`)
##   · `Tracks/Items` — nơi sinh các nút màn + đường nối (script chỉ dọn/nhân bản ở đây)
##   · `Tracks/Goal` — cờ đích ở đầu bản đồ (animation "wave" autoplay trong scene)
##   · `Tracks/Marker` — mũi chỉ "màn tiếp theo" (animation "bob" autoplay trong scene)
## Script chỉ CANH vị trí các node có sẵn; duy nhất nút màn/đường nối được sinh theo
## dữ liệu chương (số màn thay đổi) nên phải instantiate trong `Items`.
##
## Vị trí/cỡ nút tự thích ứng khung `MapArea` (cha): màn NGANG thì nút to hơn, khoảng
## cách và zigzag rộng hơn. Cuộn xong phát `scrolled` để nền giấy parallax trượt theo.
## ============================================================================

## Cạnh art nút màn ở cỡ 1.0 (px)
## Scene contract
## Exports:  node_scene, path_scene, gate_scene, tracks, items, marker, goal, anim_enabled
## Emits:    level_selected, gate_pressed, scrolled
## Handlers wired in scene: (none)
## Subscribes in code (EventBus/Model): area.resized, viewport.size_changed, node.pressed, gate.pressed

const ART_SIZE := 112.0  # keep-code: hằng dùng cho hiệu ứng/dữ liệu runtime (không phải bố cục tĩnh)

signal level_selected(level_id: int)
## Bấm CỔNG chương (chế độ ĐƯỜNG LIỀN): `chapter_id` = chương PHÍA TRÊN cổng
signal gate_pressed(chapter_id: int)
## Độ dịch cuộn THẬT của bản đồ (px) so với GIỮA khoảng cuộn — `Background` dùng để trượt
## parallax: nền chạy theo đúng nhịp ngón tay (tỉ lệ cố định), không phụ thuộc chương
## dài/ngắn như khi quy về tiến độ [-1..1].
signal scrolled(delta_y: float)

## ============================================================================
## CẤU HÌNH — chỉnh trực tiếp trong Inspector (mỗi scene override riêng được)
## ============================================================================
@export_group("Scene con")
## Scene nút màn + scene đường nối (đổi art/logic không cần sửa code)
@export var node_scene: PackedScene = preload("res://scenes/objects/level_selection/level_node.tscn")
@export var path_scene: PackedScene = preload("res://scenes/objects/level_selection/level_path.tscn")
## Scene CỔNG chương (chỉ dùng khi dựng đường liền nhiều chương — `build(..., gates)`)
@export var gate_scene: PackedScene = preload("res://scenes/objects/main/chapter_gate.tscn")

@export_group("Bố cục")
## Số CỘT của bản đồ kiểu RẮN (snake): hàng 0 ở ĐÁY đi trái→phải, hàng 1 đi phải→trái…
## `0` = giữ kiểu zigzag cũ (2 cột lệch nhau).
@export_range(0, 8, 1) var columns := 3
@export_range(0, 8, 1) var columns_landscape := 5
## Cỡ nút TỐI ĐA (1.0 = art 112 px ⇒ mặt nút ≈ 88 px). Cỡ THẬT = min(giá trị này, cỡ vừa khít bề rộng khung bản đồ)
## nên nút luôn to nhất có thể mà không lòi ra ngoài khung (bản ngang: số đo thiết kế × `design_unit()`).
@export_range(0.2, 2.5, 0.01) var node_scale_portrait := 1.0
@export_range(0.2, 2.5, 0.01) var node_scale_landscape := 1.0
## Khoảng cách tâm 2 nút CÙNG HÀNG / giữa 2 HÀNG, đo theo bề rộng art nút (112 px × cỡ nút).
## 1.38 ⇒ hai nút cách nhau ~38% bề rộng nút (đủ chỗ cho đường nối, ngón tay không chạm nhầm).
@export_range(1.0, 2.5, 0.01) var column_gap_ratio := 1.38
@export_range(1.0, 2.5, 0.01) var row_gap_ratio_portrait := 1.6
@export_range(1.0, 2.5, 0.01) var row_gap_ratio_landscape := 1.6
## Độ phình cung quay đầu ở mép (đo ở cỡ nút 1.0, nhân với cỡ nút) và độ dịch cả cụm cột sang PHẢI
@export_range(0.0, 200.0, 1.0) var turn_bulge := 64.0
@export_range(0.0, 200.0, 1.0) var turn_bulge_landscape := 100.0
@export_range(-200.0, 200.0, 1.0) var snake_center_shift := 0.0
@export_range(-200.0, 200.0, 1.0) var snake_center_shift_landscape := 0.0
## Khoảng cách tâm 2 nút theo trục Y (px) và độ lệch zigzag quanh tâm — theo hướng màn hình
@export_range(80.0, 400.0, 1.0) var spacing_portrait := 158.0
@export_range(100.0, 600.0, 1.0) var spacing_landscape := 200.0
@export_range(0.0, 300.0, 1.0) var zigzag_portrait := 74.0
@export_range(0.0, 800.0, 1.0) var zigzag_landscape := 320.0
## Độ uốn ngang của đường nối tại điểm giữa mỗi đoạn (dáng chữ S như mockup):
## lấy theo nhịp dọc SPACING × tỉ lệ này, nhưng KẸP lại để không tràn khỏi khung.
## Dùng khi 2 nút liền nhau lệch chủ yếu theo trục DỌC (bản dọc: nút xếp gần như thẳng cột
## ⇒ cần uốn NGANG mới ra dáng chữ S).
@export_range(0.0, 2.0, 0.05) var sway_spacing_ratio := 0.6
## Tỉ lệ uốn khi 2 nút liền nhau lệch chủ yếu theo trục NGANG (bản ngang: zigzag đã tạo sẵn
## dáng uốn lượn, uốn VUÔNG GÓC thêm làm tiếp tuyến Catmull-Rom quá lớn ⇒ đường TỰ CẮT
## thành vòng — đã gặp thật). Đo ở canvas 1635×920 (nút cách nhau 640×200): tỉ lệ ≤ 0,30
## (uốn ≤ 60 px) không tự cắt; ≥ 0,45 (uốn ≥ 90 px) tự cắt 3 chỗ ⇒ chọn 0,30.
@export_range(0.0, 1.0, 0.05) var sway_flat_ratio := 0.3
@export_range(0.0, 200.0, 1.0) var sway_edge_margin := 60.0
@export_range(0.0, 120.0, 1.0) var sway_min := 28.0
## Nửa bề rộng art nút màn (nút 112 px ở bản dọc) — dùng để KẸP zigzag cho nút
## không lòi ra ngoài khung bản đồ ở màn hẹp
@export_range(0.0, 200.0, 1.0) var node_half_width := 56.0
## Tâm MẶT nút lệch lên so với tâm art (nút có gờ đáy ~6px ở dưới ⇒ mặt nút nằm cao hơn ~3px).
## Đường nối đi qua tâm MẶT nút cho khớp mắt nhìn (nhân theo tỉ lệ nút ở màn ngang).
@export_range(-20.0, 20.0, 0.5) var node_face_center_y := -2.0

@export_group("Chừa chỗ")
## Chừa thêm ở ĐÁY khung bản đồ (px) để hàng nút đầu tiên không bị nút Dungeon nổi / rương che
@export_range(0.0, 300.0, 1.0) var bottom_reserve := 0.0

@export_group("Cờ đích / mũi chỉ")
## Mặt nút (khối giấy) cao 88 trên art 112 ⇒ mép trên mặt nút cách TÂM art 46 (ở scale 1)
@export_range(0.0, 120.0, 1.0) var node_face_top := 46.0
## Cờ đích `lv_flag` hiển thị ~59×77 (art 2x, scale 0.74 trong `level_map.tscn`): nửa cao 38,5;
## chồng nhẹ xuống mép nút; cột cờ nằm lệch TRÁI tâm art ~15px nên canh bù để cột trùng trục giữa nút
@export_range(0.0, 120.0, 1.0) var flag_half_height := 38.5
@export_range(0.0, 80.0, 1.0) var flag_overlap := 4.0
@export_range(0.0, 60.0, 1.0) var flag_pole_offset := 15.0
## Khoảng cách từ mép trên mặt nút tới TÂM bút chì chỉ `lv_pencil` (nửa cao ~41 + hở 6)
@export_range(0.0, 120.0, 1.0) var marker_face_gap := 48.0

@export_group("Cuộn / kéo")
## Thời gian auto-scroll đến màn đang chơi (giây)
@export_range(0.05, 2.0, 0.05) var scroll_to_duration := 0.5
## Quán tính kéo: hệ số giảm tốc mỗi frame + tốc độ tối thiểu để còn trượt (px/frame)
@export_range(0.5, 0.999, 0.001) var drag_friction := 0.88
@export_range(0.0, 20.0, 0.1) var drag_min_speed := 1.5
## Vị trí (theo chiều cao khung, 0 = đỉnh · 1 = đáy) mà màn đang chơi được đưa tới khi cuộn.
## 0.6 = hơi thấp hơn giữa khung: đường đi leo LÊN nên phần phía trên (các màn sắp chơi) được thấy nhiều hơn.
@export_range(0.3, 0.8, 0.01) var focus_ratio := 0.6
## Bước cuộn mỗi nấc lăn chuột (px)
@export_range(10.0, 300.0, 1.0) var wheel_step := 70.0

## Node con — bind bằng `@export` trong `level_map.tscn`
@export var tracks: Node2D = null
@export var items: Node2D = null
@export var marker: Node2D = null
@export var goal: Node2D = null

## Dữ liệu từ levels.gd
var _level_ids: Array[int] = []
var _stars: Dictionary = {}       # level_id -> int(sao)
var _unlocked := 1                # level_id cao nhất đã unlock
var _current_id := 1              # màn tiếp theo cần chơi
var _bonus_ids: Array[int] = []   # các màn BONUS (cuối chương)

var _nodes: Dictionary = {}       # level_id -> LevelMapNode
var _gates: Dictionary = {}       # gate_id (ÂM = -chapter_id phía trên) -> {chapter, own, need, unlocked}
var _gate_nodes: Dictionary = {}  # gate_id -> ChapterGateNode
var _pending_reveal_gate := 0     # !=0: lần dựng kế tiếp chạy hiệu ứng "mở cổng → sang chương mới"
var _truncated_at_gate := false   # true = đường CẮT ở cổng khoá (không dựng/không cuộn được qua cổng)
var _ordered := false             # true = giữ NGUYÊN thứ tự `level_ids` (đường liền, có cổng xen kẽ)
var _min_scroll_y := 0.0
var _max_scroll_y := 0.0

# Đường nối hiện tại + animation hoàn thành màn
var _road: LevelMapPath = null
var _road_point_of: Dictionary = {}   # level_id / gate_id -> chỉ số ĐIỂM của nút trên đường nối
var _sorted_ids: Array[int] = []
var _busy := false                    # true = đang chạy animation hoàn thành màn (chặn chọn màn)

# Kéo / cuộn
var _drag_active := false
var _drag_start_y := 0.0
var _tracks_start_y := 0.0
var _velocity_y := 0.0
var _scroll_tween: Tween = null  # EXCEPTION(R4-tween): endpoints tính lúc chạy (tween dựng bằng code — docs/refactor/tween_backlog.md)

## [TAP] Bản đồ TỰ bắt cú chạm vào nút màn (không phụ thuộc `_unhandled_input` của nút): mọi Control
## STOP phủ lên bản đồ (khung Main, layout...) đều làm nút Node2D không nhận được cú bấm.
## `tap_guard` (Callable → bool): trả false khi KHÔNG được chọn màn (vd. khung chương khoá đang mở).
var tap_guard: Callable = Callable()
## Control nổi đè lên bản đồ (vd. cột nút event) — chạm trúng vùng của chúng KHÔNG chọn màn bên dưới.
var blockers: Array[Control] = []
const TAP_MAX_MOVE := 14.0
var _tap_start := Vector2.ZERO
var _tap_active := false
var _last_emit_frame := -1
var _last_emit_id := 0

var _last_area_width := 0.0
var _last_unit := 1.0
var _last_area_height := 0.0
var _last_wide := false


func _ready() -> void:
	set_process(false)   # chỉ bật khi đang có quán tính kéo
	_last_area_width = _area_size().x
	_last_area_height = _area_size().y
	_last_unit = design_unit()
	_last_wide = is_wide()
	# Khung bản đồ đổi cỡ (layout) → dựng lại theo hướng mới; viewport là dự phòng cho
	# trường hợp map không nằm trong Control (test / dùng lẻ).
	var area := _map_area()
	if area != null:
		area.resized.connect(_on_viewport_size_changed)
	var viewport := get_viewport()
	if viewport != null:
		viewport.size_changed.connect(_on_viewport_size_changed)


func _on_viewport_size_changed() -> void:
	var width := _area_size().x
	var height := _area_size().y
	var unit := design_unit()
	var wide := is_wide()
	# Chỉ dựng lại khi bề rộng khung / độ phóng / hướng THẬT SỰ đổi (tránh gọi trùng lúc khởi động)
	if absf(width - _last_area_width) > 2.0 or absf(height - _last_area_height) > 2.0 or absf(unit - _last_unit) > 0.01 or wide != _last_wide:
		_last_area_width = width
		_last_area_height = height
		_last_unit = unit
		_last_wide = wide
		if not _level_ids.is_empty():
			_rebuild()


# ---------------------------------------------------------------------------
# Public API (gọi từ levels.gd / test)
# ---------------------------------------------------------------------------

## Dựng toàn bộ bản đồ từ dữ liệu chương hiện tại (`bonus_ids` = các màn BONUS trong `level_ids`)
## `gates` (tuỳ chọn) bật chế độ ĐƯỜNG LIỀN: `level_ids` đã SẮP SẴN thứ tự, xen các mã âm (gate_id)
## đại diện cổng; `gates[gate_id] = {chapter, own, need, unlocked}`.
func build(level_ids: Array[int], stars: Dictionary, unlocked: int, current_id: int,
		bonus_ids: Array[int] = [], gates: Dictionary = {}) -> void:
	_gates = gates
	_ordered = not gates.is_empty()
	_level_ids = level_ids
	_stars = stars
	_unlocked = unlocked
	_current_id = current_id
	_bonus_ids = bonus_ids
	_rebuild()


## Cuộn đến nút của `level_id` (đưa nút về giữa khung bản đồ)
func scroll_to(level_id: int, animate := true, duration := -1.0) -> void:
	var node_y := _node_y(level_id)
	if is_nan(node_y):
		return
	var target_y := clampf(_focus_y() - node_y, _min_scroll_y, _max_scroll_y)
	_stop_scroll_tween()
	if not animate:
		_set_scroll_y(target_y)
		return
	_scroll_tween = create_tween()  # EXCEPTION(R4-tween): endpoints tính lúc chạy (tween dựng bằng code — docs/refactor/tween_backlog.md)
	_scroll_tween.set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN_OUT)  # EXCEPTION(R4-tween): endpoints tính lúc chạy (tween dựng bằng code — docs/refactor/tween_backlog.md)
	_scroll_tween.tween_method(_set_scroll_y, scroll_offset_y(), target_y, scroll_to_duration if duration <= 0.0 else duration)


## Toạ độ Y (trong `Tracks`) của nút màn / cổng; NAN nếu không có
func _node_y(id: int) -> float:
	if id < 0:
		var gate: Node2D = _gate_nodes.get(id, null)
		return gate.position.y if gate != null and is_instance_valid(gate) else NAN
	var node := node_for(id)
	return node.position.y if node != null else NAN


## Mã nút (màn dương / cổng âm) đang GẦN đường tiêu điểm nhất — để header chương biết đang xem chương nào
func focus_level_id() -> int:
	var best_id := 0
	var best_dist := INF
	var focus := _focus_y() - scroll_offset_y()
	for id in _nodes.keys():
		var d := absf(_node_y(int(id)) - focus)
		if d < best_dist:
			best_dist = d
			best_id = int(id)
	for id in _gate_nodes.keys():
		var d2 := absf(_node_y(int(id)) - focus)
		if d2 < best_dist:
			best_dist = d2
			best_id = int(id)
	return best_id


## Nút của 1 màn (null nếu màn không thuộc chương đang xem)
func node_for(level_id: int) -> LevelMapNode:
	var node: LevelMapNode = _nodes.get(level_id, null)
	return node if node != null and is_instance_valid(node) else null


func node_count() -> int:
	return _nodes.size()


## Vị trí cuộn hiện tại của `Tracks` (px, dương = bản đồ trôi xuống)
func scroll_offset_y() -> float:
	return tracks.position.y if tracks != null else 0.0


## Độ cuộn so với GIỮA khoảng cuộn (px · dương = bản đồ trôi xuống).
## Nền parallax dùng giá trị này nhân với hệ số riêng của từng lớp ⇒ tốc độ nền luôn
## tỉ lệ CỐ ĐỊNH với tốc độ tay kéo (không bị "chậm dần/kịch trần" như cách chuẩn hoá theo
## độ dài chương).
func scroll_delta_y() -> float:
	if _max_scroll_y <= _min_scroll_y:
		return 0.0
	return scroll_offset_y() - (_max_scroll_y + _min_scroll_y) * 0.5


## Tiến độ cuộn chuẩn hoá [-1..1]: -1 = đáy (màn đầu), +1 = đỉnh (màn cuối), 0 = giữa
func scroll_progress() -> float:
	var half_span := (_max_scroll_y - _min_scroll_y) * 0.5
	if half_span <= 0.0:
		return 0.0
	return clampf(scroll_delta_y() / half_span, -1.0, 1.0)


# ---------------------------------------------------------------------------
# Dựng bản đồ
# ---------------------------------------------------------------------------
func _rebuild() -> void:
	_clear_items()
	if _level_ids.is_empty():
		_set_decor_visible(false)
		return

	var area := _area_size()
	var wide := is_wide()
	var spacing := spacing_landscape if wide else spacing_portrait
	var zigzag := _zigzag()
	var node_scale := _node_scale()
	var center_x := area.x * 0.5
	var cols := effective_columns()

	# Sắp xếp tăng dần: màn nhỏ nhất ở dưới cùng (y = 0), các màn sau leo dần lên (y âm)
	var sorted_ids := _level_ids.duplicate()
	if not _ordered:
		sorted_ids.sort()
	# Chương còn khoá ⇒ đường DỪNG ở cổng: không dựng màn phía sau, không cuộn lên được tới đó
	_truncated_at_gate = false
	if _ordered:
		for index in sorted_ids.size():
			var id: int = sorted_ids[index]
			if id < 0 and not bool((_gates.get(id, {}) as Dictionary).get("unlocked", false)):
				sorted_ids = sorted_ids.slice(0, index + 1)
				_truncated_at_gate = true
				break
	_sorted_ids = sorted_ids
	var positions: Array[Vector2] = []
	if cols >= 2:
		positions = _snake_positions(sorted_ids.size(), center_x)
	else:
		for index in sorted_ids.size():
			var direction := 1.0 if index % 2 == 0 else -1.0
			positions.append(Vector2(center_x + direction * zigzag, -float(index) * spacing))

	if cols >= 2:
		_build_snake_paths(sorted_ids, positions, cols)
	else:
		_build_paths(sorted_ids, positions)
	_build_nodes(sorted_ids, positions, node_scale)

	# Giới hạn cuộn lấy theo VỊ TRÍ THẬT (đúng cho cả zigzag lẫn nhiều hàng kiểu rắn)
	var min_y := 0.0
	for point in positions:
		min_y = minf(min_y, point.y)
	_update_scroll_range(min_y, node_scale)
	_set_scroll_y(_focus_y() - _current_position_y(positions, sorted_ids))
	var revealing := false
	if _pending_reveal_gate != 0:
		revealing = _begin_reveal(sorted_ids)
	if not revealing:
		call_deferred("_initial_scroll")
	if not _anim_steps.is_empty():   # bản đồ dựng lại khi hàng đợi còn: về trạng thái TRƯỚC rồi chạy lại
		_apply_anim_prestate()
		_schedule_anim()


## Cuộn ban đầu: tới màn đang chơi — hoặc màn đầu tiên của chuỗi animation đang chờ
func _initial_scroll() -> void:
	var first := _first_step_id()
	scroll_to(first if first != 0 else _current_id, true)


## Khoảng cuộn sao cho bản đồ LẤP ĐẦY khung: kéo hết xuống thì hàng 1 nằm sát đáy khung, kéo hết lên thì
## đỉnh (cờ đích) nằm sát đỉnh khung ⇒ không còn khoảng trống thừa ở đầu/cuối. Bản đồ NGẮN hơn khung được canh giữa.
func _update_scroll_range(min_y: float, node_scale: float) -> void:
	var area_h := _area_size().y
	var top_ext := (node_face_top + flag_half_height * 2.0 + 6.0) * node_scale
	if _truncated_at_gate:   # đỉnh bản đồ là CỔNG: chỉ chừa chỗ cho cổng, không để trống kiểu cờ đích
		top_ext = (node_face_top + 18.0) * node_scale
	var bottom_ext := (ART_SIZE * 0.5 + 34.0) * node_scale   # nửa nút + viên thuốc sao dưới nút
	bottom_ext += bottom_reserve
	var to_top := top_ext - min_y          # `tracks.y` khi kéo hết lên đỉnh
	var to_bottom := area_h - bottom_ext   # `tracks.y` khi kéo hết xuống đáy
	if to_bottom >= to_top:
		var centered := area_h * 0.5 - (min_y - top_ext + bottom_ext) * 0.5
		_min_scroll_y = centered
		_max_scroll_y = centered
	else:
		_min_scroll_y = to_bottom
		_max_scroll_y = to_top


## Số cột THẬT SỰ dùng: bản dọc `columns`, bản ngang `columns_landscape` (< 2 ⇒ zigzag cũ)
func effective_columns() -> int:
	return maxi(columns_landscape if is_wide() else columns, 0)


## Độ phóng của khung thiết kế bản NGANG (960×540 ⇒ canvas, kiểu "contain"); bản dọc = 1
func design_unit() -> float:
	if not is_wide():
		return 1.0
	var canvas := get_viewport_rect().size
	if canvas.x <= 0.0 or canvas.y <= 0.0:
		return 1.0
	return maxf(minf(canvas.x / 960.0, canvas.y / 540.0), 0.1)


## Tỉ lệ của nút màn trên bản đồ: to nhất có thể (tối đa `node_scale_*`) nhưng cả cụm cột + cung quay đầu
## phải lọt trong bề rộng khung bản đồ. Bản ngang đã nhân sẵn `design_unit()`.
func _node_scale() -> float:
	var wide := is_wide()
	var cap := node_scale_landscape * design_unit() if wide else node_scale_portrait
	var cols := effective_columns()
	if cols < 2:
		return cap
	var half := float(cols - 1) * 0.5
	var bulge := turn_bulge_landscape if wide else turn_bulge
	var shift := absf(snake_center_shift_landscape if wide else snake_center_shift)
	var half_span := half * column_gap_ratio * ART_SIZE + bulge   # nửa bề rộng cụm ở cỡ 1.0
	var room := _area_size().x * 0.5 - shift - 10.0
	if room <= 0.0 or half_span <= 0.0:
		return cap
	return clampf(room / half_span, 0.3, cap)


## Vị trí các nút kiểu RẮN: hàng 0 ở ĐÁY đi trái→phải, hàng 1 đi phải→trái…
## (màn 1-2-3 dưới, 4-5-6 giữa, 7-8-9 trên như mockup `level_final`).
func _snake_positions(count: int, center_x: float) -> Array[Vector2]:
	var out: Array[Vector2] = []
	var cols := maxi(effective_columns(), 2)
	var half := float(cols - 1) * 0.5
	var unit := design_unit()
	var wide := is_wide()
	var art := ART_SIZE * _node_scale()
	var col_spacing := column_gap_ratio * art
	var row_gap := (row_gap_ratio_landscape if wide else row_gap_ratio_portrait) * art
	var shift := (snake_center_shift_landscape * unit) if wide else snake_center_shift
	for index in count:
		var row := floori(float(index) / float(cols))
		var col := index % cols
		# Hàng lẻ chạy ngược để nét nối liền mạch (snake)
		var x_index := col if row % 2 == 0 else cols - 1 - col
		out.append(Vector2(
			center_x + shift + (float(x_index) - half) * col_spacing,
			-float(row) * row_gap))
	return out


## Đường nối kiểu RẮN: trong cùng hàng nối thẳng, giữa 2 hàng nối bằng cung vòng ra MÉP
## (điểm uốn nằm ngoài cột biên) nên nhìn như sợi dây quấn quanh mép bản đồ.
func _build_snake_paths(sorted_ids: Array[int], positions: Array[Vector2], cols: int) -> void:
	if items == null or sorted_ids.size() < 2:
		return
	var node_scale := _node_scale()
	var points := _snake_path_points(positions, cols, node_scale)
	var states: Array[int] = []
	for segment in range(points.size() - 1):
		var id_index := _snake_state_index(segment, cols, sorted_ids.size())
		states.append(int(_path_state_for(sorted_ids[id_index])))
	var road := path_scene.instantiate() as LevelMapPath
	items.add_child(road)
	_road = road
	road.width_scale = node_scale
	var node_index := 0
	for point_index in points.size():
		if points[point_index].z == 0.0 and node_index < sorted_ids.size():
			_road_point_of[sorted_ids[node_index]] = point_index
			node_index += 1
	var flat_points: Array[Vector2] = []
	for point in points:
		flat_points.append(Vector2(point.x, point.y + node_face_center_y * node_scale))
	road.edge_offset *= node_scale
	road.setup(flat_points, states, 0.0)


## Danh sách điểm cho đường nối kiểu rắn: mỗi nút 1 điểm, chèn thêm ĐIỂM UỐN ở mép khi
## chuyển hàng. Vector3(x, y, z) với `z = 1` đánh dấu điểm uốn (không phải nút màn).
func _snake_path_points(positions: Array[Vector2], cols: int, node_scale: float) -> Array[Vector3]:
	var out: Array[Vector3] = []
	var edge_x := positions[0].x
	var min_x := positions[0].x
	for point in positions:
		edge_x = maxf(edge_x, point.x)
		min_x = minf(min_x, point.x)
	var bulge := (turn_bulge_landscape if is_wide() else turn_bulge) * node_scale
	for index in positions.size():
		if index > 0 and index % cols == 0:
			# Chuyển hàng: cung vòng ra mép (phải nếu hàng trước chạy xuôi, trái nếu chạy ngược)
			var prev := positions[index - 1]
			var next := positions[index]
			var row := floori(float(index) / float(cols))
			var outward := 1.0 if (row - 1) % 2 == 0 else -1.0
			var edge := edge_x if outward > 0.0 else min_x
			out.append(Vector3(edge + outward * bulge, (prev.y + next.y) * 0.5, 1.0))
		out.append(Vector3(positions[index].x, positions[index].y, 0.0))
	return out


## Chỉ số `sorted_ids` của nút ĐỨNG TRƯỚC đoạn nối thứ `segment` trong danh sách điểm
## (điểm uốn thuộc về nút đứng trước nó nên 2 đoạn liền nhau cùng một trạng thái).
func _snake_state_index(segment: int, cols: int, count: int) -> int:
	var elbows := 0
	if segment >= cols:
		elbows = floori(float(segment - cols) / float(cols + 1)) + 1
	return clampi(segment - elbows, 0, count - 1)


## Đường nối nằm DƯỚI các nút (thêm trước): MỘT đường uốn chữ S qua tâm TẤT CẢ các nút
func _build_paths(sorted_ids: Array[int], positions: Array[Vector2]) -> void:
	if items == null or sorted_ids.size() < 2:
		return
	var road := path_scene.instantiate() as LevelMapPath
	items.add_child(road)
	_road = road
	var node_scale := _node_scale()
	road.width_scale = node_scale
	for point_index in sorted_ids.size():
		_road_point_of[sorted_ids[point_index]] = point_index
	# Đường đi qua tâm MẶT nút (cao hơn tâm art vài px) + gờ đáy của đường theo tỉ lệ nút
	var face_points: Array[Vector2] = []
	for point in positions:
		face_points.append(point + Vector2(0.0, node_face_center_y * node_scale))
	road.edge_offset *= node_scale
	var states: Array[int] = []
	for index in range(sorted_ids.size() - 1):
		states.append(int(_path_state_for(sorted_ids[index])))
	road.setup(face_points, states, _road_sway())


## Độ lệch của điểm uốn giữa mỗi đoạn nối: theo nhịp dọc nhưng không vượt mép khung.
## Chọn tỉ lệ theo HƯỚNG của đoạn nối: bản dọc cần uốn ngang (chữ S), bản ngang đã uốn sẵn
## nhờ zigzag nên chỉ uốn rất nhẹ (xem `sway_flat_ratio`).
func _road_sway() -> float:
	var area := _area_size()
	var wide := is_wide()
	var spacing := spacing_landscape if wide else spacing_portrait
	var ratio := sway_flat_ratio if wide else sway_spacing_ratio
	if ratio <= 0.0:
		return 0.0
	var zigzag := _zigzag()
	var room := area.x * 0.5 - zigzag - sway_edge_margin
	return maxf(sway_min, minf(spacing * ratio, room))


## Các nút màn + canh cờ đích / mũi chỉ
func _build_nodes(sorted_ids: Array[int], positions: Array[Vector2], node_scale: float) -> void:
	if items == null:
		return
	for index in sorted_ids.size():
		var level_id := sorted_ids[index]
		if level_id < 0:
			_build_gate(level_id, positions[index], node_scale)
			continue
		var node := node_scene.instantiate() as LevelMapNode
		items.add_child(node)
		node.position = positions[index]
		node.scale = Vector2.ONE * node_scale
		node.setup(level_id, _node_state_for(level_id), int(_stars.get(level_id, 0)),
			_bonus_ids.has(level_id))
		# Nút sinh lúc chạy nên phải nối ở đây (scene không thể khai dây cho node động)
		node.pressed.connect(_on_node_pressed)
		_nodes[level_id] = node

	# Cờ đích cắm ở màn CHÍNH cuối cùng (BONUS nằm sau cờ)
	var last_index := sorted_ids.size() - 1
	while last_index > 0 and _bonus_ids.has(sorted_ids[last_index]):
		last_index -= 1
	var last_position := positions[last_index]
	var last_id: int = sorted_ids[last_index]
	if goal != null and last_id < 0:
		goal.visible = false   # đỉnh là cổng khoá ⇒ chưa có cờ đích  # keep-code: trạng thái theo dữ liệu (runtime)
	elif goal != null:
		goal.visible = true  # keep-code: trạng thái theo dữ liệu (runtime)
		goal.scale = Vector2.ONE * node_scale
		# Cắm cờ vào MÉP TRÊN nút cuối (chồng nhẹ) — cờ nằm trong nút "End Level", không lơ lửng
		var lift := (node_face_top + flag_half_height - flag_overlap) * node_scale
		goal.position = last_position + Vector2(flag_pole_offset * node_scale, -lift)
	var current := node_for(_current_id)
	var show_marker := current != null and _current_id != last_id
	if marker != null:
		marker.visible = show_marker
		if show_marker:
			marker.scale = Vector2.ONE * node_scale
			marker.position = current.position + Vector2(0.0, -(node_face_top + marker_face_gap) * node_scale)


## Dựng 1 cổng chương (đường liền)
func _build_gate(gate_id: int, pos: Vector2, node_scale: float) -> void:
	if gate_scene == null:
		return
	var info: Dictionary = _gates.get(gate_id, {})
	var gate := gate_scene.instantiate() as ChapterGateNode
	items.add_child(gate)
	gate.position = pos
	gate.scale = Vector2.ONE * node_scale
	var state := ChapterGateNode.State.OPEN
	if not bool(info.get("unlocked", false)):
		state = ChapterGateNode.State.READY \
			if int(info.get("own", 0)) >= int(info.get("need", 0)) else ChapterGateNode.State.LOCKED
	gate.setup(int(info.get("chapter", -gate_id)), int(info.get("own", 0)), int(info.get("need", 0)), state)
	gate.pressed.connect(_on_gate_pressed)
	_gate_nodes[gate_id] = gate


# ---------------------------------------------------------------------------
# ANIMATION TIẾN ĐỘ khi quay về bản đồ (sao đóng dấu → vệt dạ quang vẽ dần → mở khoá màn kế)
# ---------------------------------------------------------------------------
## Nhận NHẬT KÝ sự kiện từ GameManager (`take_map_events`) ngay sau `build()` và quyết định phát gì.
##
## QUY TẮC (mỗi sự kiện: clear{id, stars, prev_stars, unlocked_before} · skip{id}):
##  1. `skip` CẮT MẠCH: bỏ mọi màn thắng trước nó (Thắng → Skip → thoát = KHÔNG animation).
##  2. Các màn thắng liên tiếp (Thắng → Continue → Thắng → …) chạy THÀNH CHUỖI từ màn xong đầu tiên đến
##     màn vừa thoát; màn thứ 2 trở đi chạy nhanh hơn; chỉ giữ tối đa `anim_max_steps` màn cuối.
##  3. Màn thắng LẦN ĐẦU (`prev_stars == 0`): đóng dấu sao → vệt dạ quang nối sang màn kế (cả khi màn kế
##     đã xong từ trước — vd. quay lại chơi màn từng bị skip, vệt cam đổi thành vàng) → màn kế vừa được mở
##     khoá (`id kế > unlocked_before`) thì ổ khoá rung rồi bật ra.
##  4. Màn chơi lại được THÊM sao (`prev_stars > 0`): chỉ đóng dấu các sao mới (không nối đường / mở khoá).
##  5. Chơi lại không thêm sao, thua, thoát giữa chừng, màn sự kiện / Daily / Dungeon: không có sự kiện ⇒ không animation.
##  6. Màn kế là CỔNG chương hoặc hết màn: vệt nối tới cổng, không có bước mở khoá.
##  7. Chạm màn hình trong lúc chạy ⇒ BỎ QUA animation, hiện ngay trạng thái cuối. Trong lúc chạy, không chọn được màn.
##  8. Bản đồ bị dựng lại giữa chừng (đổi cỡ khung, đổi ngôn ngữ…) ⇒ hàng đợi được GIỮ và chạy lại sau khi ổn định.
@export_group("Animation tiến độ")
@export var anim_enabled := true
## Chờ bố cục ổn định / hết hiệu ứng chuyển màn rồi mới chạy (giây)
@export_range(0.0, 2.0, 0.05) var anim_start_delay := 0.5
@export_range(1, 10, 1) var anim_max_steps := 5

var _anim_steps: Array[Dictionary] = []
var _anim_token := 0
var _marker_was_visible := false


func queue_progress_animation(events: Array) -> void:
	_anim_steps = _plan_steps(events) if anim_enabled else ([] as Array[Dictionary])
	if _anim_steps.is_empty():
		return
	_apply_anim_prestate()
	_schedule_anim()


func _plan_steps(events: Array) -> Array[Dictionary]:
	var chain: Array[Dictionary] = []
	for event in events:
		var entry: Dictionary = event
		if str(entry.get("type", "")) == "skip":
			chain.clear()
			continue
		var id := int(entry.get("id", 0))
		var merged := false
		for step in chain:
			if int(step["id"]) == id:
				step["stars"] = maxi(int(step["stars"]), int(entry.get("stars", 0)))
				merged = true
				break
		if not merged:
			chain.append(entry.duplicate())
	if chain.size() > anim_max_steps:
		chain = chain.slice(chain.size() - anim_max_steps)
	# Chỉ giữ các màn có nút trên bản đồ đang xem
	var out: Array[Dictionary] = []
	for step in chain:
		if node_for(int(step["id"])) != null and _road_point_of.has(int(step["id"])):
			out.append(step)
	return out


func _next_id_of(id: int) -> int:
	var index := _sorted_ids.find(id)
	return _sorted_ids[index + 1] if index >= 0 and index + 1 < _sorted_ids.size() else 0


## Các màn VỪA được mở khoá bởi chuỗi (màn kế của một lần thắng đầu tiên, vượt `unlocked_before`)
func _unlock_ids() -> Array[int]:
	var ids: Array[int] = []
	for step in _anim_steps:
		if int(step.get("prev_stars", 0)) > 0:
			continue
		var next_id := _next_id_of(int(step["id"]))
		if next_id > 0 and next_id > int(step.get("unlocked_before", next_id)) \
				and next_id <= _unlocked and node_for(next_id) != null and not ids.has(next_id):
			ids.append(next_id)
	return ids


func _first_step_id() -> int:
	return int(_anim_steps[0]["id"]) if not _anim_steps.is_empty() else 0


## Đưa bản đồ về trạng thái TRƯỚC (bản đồ vừa dựng ở trạng thái cuối): sao cũ, đường chưa nối, màn kế còn khoá
func _apply_anim_prestate() -> void:
	_busy = true
	var unlock_ids := _unlock_ids()
	for step in _anim_steps:
		var id := int(step["id"])
		var node := node_for(id)
		if node == null:
			continue
		node.prepare_complete(int(step.get("prev_stars", 0)))
		if int(step.get("prev_stars", 0)) > 0 or _road == null:
			continue
		var from_point: int = _road_point_of.get(id, -1)
		var to_point: int = _road_point_of.get(_next_id_of(id), -1)
		if from_point >= 0 and to_point > from_point:
			_road.hide_range(from_point, to_point)
	for id in unlock_ids:
		node_for(id).show_locked_preview()
	if marker != null:
		_marker_was_visible = marker.visible
		marker.visible = false


func _schedule_anim() -> void:
	if _anim_steps.is_empty():
		return
	_anim_token += 1
	var token := _anim_token
	await get_tree().create_timer(anim_start_delay).timeout  # EXCEPTION(R4-tween): endpoints tính lúc chạy (tween dựng bằng code — docs/refactor/tween_backlog.md)
	# Chưa hiện ra (đang ở tab khác / chuyển màn) thì đợi thêm tối đa ~3 giây
	var waited := 0.0
	while is_inside_tree() and not is_visible_in_tree() and waited < 3.0 and token == _anim_token:
		await get_tree().create_timer(0.2).timeout  # EXCEPTION(R4-tween): endpoints tính lúc chạy (tween dựng bằng code — docs/refactor/tween_backlog.md)
		waited += 0.2
	if token != _anim_token or _anim_steps.is_empty() or not is_inside_tree():
		return
	if not is_visible_in_tree():
		_abort_anim()
		return
	_run_anim()


func _run_anim() -> void:
	var unlock_ids := _unlock_ids()
	var steps := _anim_steps
	for i in steps.size():
		var step := steps[i]
		var id := int(step["id"])
		var node := node_for(id)
		if not _busy or node == null or not is_instance_valid(node):
			return
		var speed := 1.0 if i == 0 else 1.6
		scroll_to(id, true)
		await get_tree().create_timer((scroll_to_duration + 0.1) / speed).timeout  # EXCEPTION(R4-tween): endpoints tính lúc chạy (tween dựng bằng code — docs/refactor/tween_backlog.md)
		if not _busy or not is_instance_valid(node):
			return
		await node.play_complete(int(step["stars"]), int(step.get("prev_stars", 0)), speed)
		if not _busy:
			return
		if int(step.get("prev_stars", 0)) > 0:
			continue   # chỉ thêm sao: không nối đường / mở khoá
		var next_id := _next_id_of(id)
		var from_point: int = _road_point_of.get(id, -1)
		var to_point: int = _road_point_of.get(next_id, -1)
		if _road != null and from_point >= 0 and to_point > from_point:
			var reveal := _road.play_reveal_range(from_point, to_point, 0.75 / speed)
			if next_id != 0:
				scroll_to(next_id, true)
			if reveal != null:
				await reveal.finished
			if not _busy:
				return
		if unlock_ids.has(next_id):
			var next_node := node_for(next_id)
			if next_node == null or not is_instance_valid(next_node):
				return
			var stamped_later := false
			for j in range(i + 1, steps.size()):
				if int(steps[j]["id"]) == next_id:
					stamped_later = true
			await next_node.play_unlock(stamped_later)
			if not _busy:
				return
	_finish_anim()


func _finish_anim() -> void:
	_anim_steps = []
	if marker != null and _marker_was_visible:
		marker.visible = true
	_busy = false


## Bỏ qua animation: dựng lại bản đồ ở trạng thái cuối ngay lập tức
func _abort_anim() -> void:
	_anim_steps = []
	_anim_token += 1
	_rebuild()


func _is_press_event(event: InputEvent) -> bool:
	if event is InputEventScreenTouch:
		return (event as InputEventScreenTouch).pressed
	if event is InputEventMouseButton:
		var button := event as InputEventMouseButton
		return button.pressed and button.button_index == MOUSE_BUTTON_LEFT
	return false


# ---------------------------------------------------------------------------
# Mở cổng → sang chương mới
# ---------------------------------------------------------------------------
## Bước 1: chạy animation mở cổng `gate_id` TRÊN bản đồ hiện tại; trả về khi cửa mở xong
func play_gate_open(gate_id: int) -> void:
	var gate: ChapterGateNode = _gate_nodes.get(gate_id, null)
	if gate == null or not is_instance_valid(gate):
		return
	var gate_target := clampf(_focus_y() - _node_y(gate_id), _min_scroll_y, _max_scroll_y)
	if absf(gate_target - scroll_offset_y()) > 1.0:   # cổng đã ở tiêu điểm thì mở ngay, khỏi chờ cuộn
		scroll_to(gate_id, true)
		if _scroll_tween != null and _scroll_tween.is_valid():
			await _scroll_tween.finished
	gate.play_open()
	await gate.opened


## Cổng `gate_id` bị từ chối (chưa đủ Sao): cổng lắc + nháy đỏ, KHÔNG mở popup
func reject_gate(gate_id: int) -> void:
	var gate: ChapterGateNode = _gate_nodes.get(gate_id, null)
	if gate != null and is_instance_valid(gate):
		gate.play_reject()


## Bước 2 (gọi TRƯỚC `build`): lần dựng kế tiếp sẽ giữ cổng ở tiêu điểm, ẨN các nút + đường nối phía sau cổng,
## rồi CUỘN LÊN dần: từng đoạn đường được vẽ nối sang nút kế → nút bật ra → cuộn tiếp (xem `_run_reveal`)
func prepare_reveal(gate_id: int) -> void:
	_pending_reveal_gate = gate_id


@export_group("Animation mở chương mới")
## Thời gian tối đa cho mỗi nút (giây); chương dài thì tự nhanh hơn để tổng không quá `reveal_max_total`
@export_range(0.05, 0.8, 0.01) var reveal_step_sec := 0.26
@export_range(0.5, 8.0, 0.1) var reveal_max_total := 3.4
@export_range(0.0, 1.0, 0.05) var reveal_start_delay := 0.2
@export_range(0.1, 0.8, 0.01) var reveal_pop_sec := 0.32
## Chỉ diễn từng nút cho tối đa chừng này nút đầu chương; phần còn lại (ngoài tầm nhìn) hiện luôn
@export_range(1, 40, 1) var reveal_max_nodes := 12
## Khi nút mới nằm cao hơn mức này (tỉ lệ chiều cao khung, 0 = đỉnh) thì bản đồ cuộn lên để đón nó
@export_range(0.05, 0.6, 0.01) var reveal_camera_top := 0.3

var _reveal_active := false
var _reveal_token := 0
var _reveal_gate_id := 0
var _reveal_list: Array[Dictionary] = []   # {id, node, scale: Vector2, instant: bool}
var _reveal_tweens: Array[Tween] = []  # EXCEPTION(R4-tween): endpoints tính lúc chạy (tween dựng bằng code — docs/refactor/tween_backlog.md)
var _reveal_goal_was_visible := false
var _reveal_marker_was_visible := false


## Trả về true nếu đã nhận quyền điều khiển cuộn (khi đó `_rebuild` không tự cuộn tới màn đang chơi)
func _begin_reveal(sorted_ids: Array) -> bool:
	var gate_id := _pending_reveal_gate
	_pending_reveal_gate = 0
	var gate_index := sorted_ids.find(gate_id)
	if gate_index < 0 or gate_index >= sorted_ids.size() - 1:
		return false
	_set_scroll_y(_focus_y() - _node_y(gate_id))   # bắt đầu ngay tại cổng (đã mở)
	_reveal_gate_id = gate_id
	_reveal_list.clear()
	for index in range(gate_index + 1, sorted_ids.size()):
		var id: int = sorted_ids[index]
		var node: Node2D = _gate_nodes.get(id, null) if id < 0 else _nodes.get(id, null)
		if node == null:
			continue
		var instant := _reveal_list.size() >= reveal_max_nodes
		_reveal_list.append({"id": id, "node": node, "scale": node.scale, "instant": instant})
		if not instant:
			node.modulate.a = 0.0
			node.scale = node.scale * 0.4
	if _reveal_list.is_empty():
		return false
	var from_point: int = _road_point_of.get(gate_id, -1)
	if _road != null and from_point >= 0:
		var first_instant := -1
		for entry in _reveal_list:
			if bool(entry["instant"]):
				first_instant = _road_point_of.get(int(entry["id"]), -1)
				break
		# Ẩn đường nối từ cổng tới hết phần sẽ diễn; phần "hiện luôn" giữ nguyên
		_road.hide_range(from_point, first_instant if first_instant >= 0 else 1000000)
	_reveal_goal_was_visible = goal != null and goal.visible
	_reveal_marker_was_visible = marker != null and marker.visible
	if goal != null:
		goal.visible = false
	if marker != null:
		marker.visible = false
	_busy = true
	_reveal_active = true
	_reveal_token += 1
	_run_reveal(_reveal_token)
	return true


func _run_reveal(token: int) -> void:
	await get_tree().create_timer(reveal_start_delay).timeout  # EXCEPTION(R4-tween): endpoints tính lúc chạy (tween dựng bằng code — docs/refactor/tween_backlog.md)
	if token != _reveal_token:
		return
	var shown: Array[Dictionary] = []
	for entry in _reveal_list:
		if not bool(entry["instant"]):
			shown.append(entry)
	var step := clampf(reveal_max_total / float(maxi(shown.size(), 1)), 0.09, reveal_step_sec)
	var prev_id := _reveal_gate_id
	# MỘT cú cuộn duy nhất, êm, kéo dài suốt lúc các nút lần lượt hiện (không giật cục từng nút):
	# đích = vị trí để nút CUỐI cùng được diễn nằm ở mức `reveal_camera_top` của khung
	if not shown.is_empty():
		var camera_target := clampf(maxf(scroll_offset_y(), area_top_offset(int(shown[shown.size() - 1]["id"]))),
			_min_scroll_y, _max_scroll_y)
		if camera_target > scroll_offset_y() + 0.5:
			_stop_scroll_tween()
			_scroll_tween = create_tween()  # EXCEPTION(R4-tween): endpoints tính lúc chạy (tween dựng bằng code — docs/refactor/tween_backlog.md)
			_scroll_tween.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)  # EXCEPTION(R4-tween): endpoints tính lúc chạy (tween dựng bằng code — docs/refactor/tween_backlog.md)
			_scroll_tween.tween_method(_set_scroll_y, scroll_offset_y(), camera_target,
				step * float(shown.size()) + reveal_pop_sec * 0.5)
	for entry in shown:
		if token != _reveal_token:
			return
		var id: int = entry["id"]
		var node: Node2D = entry["node"]
		if not is_instance_valid(node):
			continue
		# 2) Vệt dạ quang vẽ nối từ nút trước sang nút này
		var from_point: int = _road_point_of.get(prev_id, -1)
		var to_point: int = _road_point_of.get(id, -1)
		var draw_time := step * 0.7
		if _road != null and from_point >= 0 and to_point > from_point:
			var road_tween := _road.play_reveal_range(from_point, to_point, draw_time)
			if road_tween != null:
				_reveal_tweens.append(road_tween)
		await get_tree().create_timer(draw_time).timeout  # EXCEPTION(R4-tween): endpoints tính lúc chạy (tween dựng bằng code — docs/refactor/tween_backlog.md)
		if token != _reveal_token:
			return
		# 3) Nút bật ra khi vệt chạm tới
		if is_instance_valid(node):
			var pop := create_tween()  # EXCEPTION(R4-tween): endpoints tính lúc chạy (tween dựng bằng code — docs/refactor/tween_backlog.md)
			pop.set_parallel(true)
			pop.tween_property(node, "modulate:a", 1.0, 0.14)
			pop.tween_property(node, "scale", entry["scale"], reveal_pop_sec) \
				.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)  # EXCEPTION(R4-tween): endpoints tính lúc chạy (tween dựng bằng code — docs/refactor/tween_backlog.md)
			_reveal_tweens.append(pop)
		prev_id = id
		await get_tree().create_timer(maxf(step - draw_time, 0.01)).timeout  # EXCEPTION(R4-tween): endpoints tính lúc chạy (tween dựng bằng code — docs/refactor/tween_backlog.md)
	if token != _reveal_token:
		return
	await get_tree().create_timer(reveal_pop_sec * 0.8).timeout  # EXCEPTION(R4-tween): endpoints tính lúc chạy (tween dựng bằng code — docs/refactor/tween_backlog.md)
	if token != _reveal_token:
		return
	_finish_reveal(false)


## Offset cuộn để nút `id` nằm ở mức `reveal_camera_top` của khung (chỉ dùng khi nút cao hơn mức đó)
func area_top_offset(id: int) -> float:
	return _area_size().y * reveal_camera_top - _node_y(id)


## Kết thúc mở chương: hiện đủ mọi nút + đường, trả cờ/mũi chỉ, cuộn về màn đang chơi
func _finish_reveal(skipped: bool) -> void:
	if not _reveal_active:
		return
	_reveal_active = false
	_reveal_token += 1
	for tween in _reveal_tweens:
		if tween != null and tween.is_valid():
			tween.kill()
	_reveal_tweens.clear()
	_stop_scroll_tween()
	for entry in _reveal_list:
		var node: Node2D = entry["node"]
		if is_instance_valid(node):
			node.modulate.a = 1.0
			node.scale = entry["scale"]
	if _road != null:
		var from_point: int = _road_point_of.get(_reveal_gate_id, -1)
		if from_point >= 0:
			_road.show_range(from_point, 1000000)
	if goal != null:
		goal.visible = _reveal_goal_was_visible
	if marker != null:
		marker.visible = _reveal_marker_was_visible
	_reveal_list.clear()
	_busy = false
	var target_id := _current_id if node_for(_current_id) != null else 0
	if target_id != 0:
		var screen_y := _node_y(target_id) + scroll_offset_y()
		var h := _area_size().y
		if skipped:
			scroll_to(target_id, false)
		elif screen_y < h * 0.12 or screen_y > h * 0.9:   # màn đang chơi đã nằm trong tầm nhìn thì khỏi cuộn lại
			scroll_to(target_id, true, 0.9)


func _set_decor_visible(visible_now: bool) -> void:
	if marker != null:
		marker.visible = visible_now
	if goal != null:
		goal.visible = visible_now


func _current_position_y(positions: Array[Vector2], sorted_ids: Array[int]) -> float:
	var index := sorted_ids.find(_current_id)
	if index < 0:
		return 0.0
	return positions[index].y


func _clear_items() -> void:
	_busy = false
	_reveal_active = false
	_reveal_token += 1
	_reveal_list.clear()
	_reveal_tweens.clear()
	_road = null
	_road_point_of.clear()
	_nodes.clear()
	_gate_nodes.clear()
	if items == null:
		return
	for child in items.get_children():
		items.remove_child(child)
		child.queue_free()


## Trạng thái của NÚT màn
func _node_state_for(level_id: int) -> LevelMapNode.State:
	if level_id > _unlocked:
		return LevelMapNode.State.LOCKED
	if int(_stars.get(level_id, 0)) > 0:
		return LevelMapNode.State.DONE
	if level_id == _current_id:
		return LevelMapNode.State.CURRENT
	if level_id < _current_id:
		return LevelMapNode.State.SKIPPED
	return LevelMapNode.State.NORMAL


## Trạng thái của ĐOẠN NỐI sau màn `level_id`
func _path_state_for(level_id: int) -> LevelMapPath.PathState:
	if level_id < 0:   # đoạn nối SAU cổng
		return LevelMapPath.PathState.COMPLETE if bool(
			(_gates.get(level_id, {}) as Dictionary).get("unlocked", false)) else LevelMapPath.PathState.LOCKED
	if level_id > _unlocked:
		return LevelMapPath.PathState.LOCKED
	if int(_stars.get(level_id, 0)) > 0:
		return LevelMapPath.PathState.COMPLETE
	if level_id < _current_id:
		return LevelMapPath.PathState.SKIPPED
	return LevelMapPath.PathState.UPCOMING


# ---------------------------------------------------------------------------
# Khung bản đồ (cha = `MapArea` trong scenes/levels.tscn)
# ---------------------------------------------------------------------------
func _map_area() -> Control:
	return get_parent() as Control


func _area_size() -> Vector2:
	var area := _map_area()
	return area.size if area != null else get_viewport_rect().size


func _focus_y() -> float:
	return _area_size().y * focus_ratio


## Có phải màn NGANG (canvas rộng hơn cao) — quyết định cỡ nút / khoảng cách.
## LẤY THEO CANVAS (không theo khung `MapArea`): khung này chỉ cao ~62% canvas và nằm trong
## CỘT NỘI DUNG canh giữa (xem `scripts/ui/screens/base.gd`), nên với màn DỌC rộng (3:4, cửa sổ
## lớn…) khung vẫn "rộng hơn cao" ⇒ bản đồ có thể lỡ dùng thông số NGANG: zigzag 320 làm
## nút lòi ra ngoài khung + đổi cả trục uốn của đường nối ⇒ đường nối vẽ sai (đã gặp thật).
## Dùng canvas cho khớp cách `BaseUI` quyết định hướng layout.
func is_wide() -> bool:
	var canvas := get_viewport_rect().size
	if canvas.x > 0.0 and canvas.y > 0.0:
		return canvas.x > canvas.y
	var area := _area_size()
	return area.x > area.y


## Độ lệch zigzag đang dùng, KẸP để art nút không lòi ra ngoài khung bản đồ
func _zigzag() -> float:
	var area := _area_size()
	var wide := is_wide()
	var scale := _node_scale()
	var wanted := zigzag_landscape if wide else zigzag_portrait
	var room := maxf(0.0, area.x * 0.5 - node_half_width * scale - sway_edge_margin)
	return clampf(wanted, 0.0, room)


## Đặt vị trí cuộn (đã kẹp giới hạn) rồi phát độ dịch cho nền parallax
func _set_scroll_y(value: float) -> void:
	if tracks == null:
		return
	var clamped := clampf(value, _min_scroll_y, _max_scroll_y)
	if tracks.position.y != clamped:
		tracks.position.y = clamped
	scrolled.emit(scroll_delta_y())


# ---------------------------------------------------------------------------
# Kéo / cuộn (dọc, thân thiện cảm ứng)
# ---------------------------------------------------------------------------
func _input(event: InputEvent) -> void:
	if _busy and _reveal_active and _is_press_event(event):
		get_viewport().set_input_as_handled()
		_finish_reveal(true)   # chạm ⇒ bỏ qua animation mở chương, hiện ngay trạng thái cuối
		return
	if _busy and not _anim_steps.is_empty() and _is_press_event(event):
		get_viewport().set_input_as_handled()
		_abort_anim()
		return
	# Popup đang mở (Hồ sơ, Cài đặt…) ⇒ chạm/kéo thuộc về popup, KHÔNG được chọn màn / cuộn bản đồ phía dưới
	if Popups.has_open():
		_tap_active = false
		if _drag_active:
			_end_drag()
		return
	_track_tap(event)
	if event is InputEventScreenTouch and event.index == 0:
		if event.pressed:
			if _inside_area(event.position):
				_begin_drag(event.position)
		else:
			_end_drag()
	elif event is InputEventScreenDrag and event.index == 0:
		_update_drag(event.position, event.relative)
	elif event is InputEventMouseButton:
		var button := event as InputEventMouseButton
		if button.button_index == MOUSE_BUTTON_LEFT:
			if button.pressed:
				if _inside_area(button.position):
					_begin_drag(button.position)
			else:
				_end_drag()
		elif button.pressed and button.button_index == MOUSE_BUTTON_WHEEL_UP and _inside_area(button.position):
			_set_scroll_y(scroll_offset_y() + wheel_step)
		elif button.pressed and button.button_index == MOUSE_BUTTON_WHEEL_DOWN and _inside_area(button.position):
			_set_scroll_y(scroll_offset_y() - wheel_step)
	elif event is InputEventMouseMotion and (event.button_mask & MOUSE_BUTTON_MASK_LEFT) != 0:
		_update_drag(event.position, event.relative)


## Chỉ nhận kéo khi bắt đầu TRONG khung bản đồ (không giành input của header/nút)
func _inside_area(pos: Vector2) -> bool:
	var area := _map_area()
	# [MERGE] Main có 2 LevelMap (1 mỗi bố cục Portrait/Landscape) ⇒ bản đang ẨN không được nhận kéo
	if area != null and not area.is_visible_in_tree():
		return false
	return area == null or area.get_global_rect().has_point(pos)


func _begin_drag(pos: Vector2) -> void:
	_stop_scroll_tween()
	_drag_active = true
	_drag_start_y = pos.y
	_tracks_start_y = scroll_offset_y()
	_velocity_y = 0.0


func _update_drag(pos: Vector2, relative: Vector2) -> void:
	if not _drag_active:
		return
	_set_scroll_y(_tracks_start_y + (pos.y - _drag_start_y))
	_velocity_y = relative.y


func _end_drag() -> void:
	_drag_active = false
	set_process(absf(_velocity_y) >= drag_min_speed)


func _process(_delta: float) -> void:
	if _drag_active or absf(_velocity_y) < drag_min_speed:
		_velocity_y = 0.0
		set_process(false)
		return
	_set_scroll_y(scroll_offset_y() + _velocity_y)
	_velocity_y *= drag_friction


func _stop_scroll_tween() -> void:
	if _scroll_tween != null and _scroll_tween.is_valid():
		_scroll_tween.kill()
	_scroll_tween = null


# ---------------------------------------------------------------------------
# Events
# ---------------------------------------------------------------------------
func _on_node_pressed(level_id: int) -> void:
	if _busy:
		return
	_emit_selected(level_id)


## Phát `level_selected` đúng 1 lần cho mỗi cú bấm (nút tự bắt + bản đồ tự bắt có thể cùng báo)
func _emit_selected(level_id: int) -> void:
	if _busy:
		return
	var frame := Engine.get_process_frames()
	if level_id == _last_emit_id and absf(float(frame - _last_emit_frame)) <= 2.0:
		return
	_last_emit_id = level_id
	_last_emit_frame = frame
	level_selected.emit(level_id)


## Theo dõi "chạm": nhấn rồi thả gần như tại chỗ (không kéo) trên MỘT nút màn đang mở ⇒ chọn màn đó
func _track_tap(event: InputEvent) -> void:
	var pos := Vector2.ZERO
	var is_press := false
	var is_release := false
	if event is InputEventMouseButton and (event as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT:
		pos = (event as InputEventMouseButton).position
		is_press = (event as InputEventMouseButton).pressed
		is_release = not is_press
	elif event is InputEventScreenTouch and (event as InputEventScreenTouch).index == 0:
		pos = (event as InputEventScreenTouch).position
		is_press = (event as InputEventScreenTouch).pressed
		is_release = not is_press
	else:
		return
	if is_press:
		_tap_active = _inside_area(pos)
		_tap_start = pos
		return
	if not is_release or not _tap_active:
		return
	_tap_active = false
	if pos.distance_to(_tap_start) > TAP_MAX_MOVE or not _inside_area(pos):
		return
	if tap_guard.is_valid() and not bool(tap_guard.call()):
		return
	for blocker in blockers:
		if is_instance_valid(blocker) and blocker.is_visible_in_tree() and blocker.get_global_rect().has_point(pos):
			return
	var hit := _node_at(pos)
	if hit != null:
		_emit_selected(hit.level_id)


## Nút màn (đang mở) nằm dưới điểm `pos` (toạ độ viewport); null nếu không có
func _node_at(pos: Vector2) -> LevelMapNode:
	var best: LevelMapNode = null
	var best_dist := INF
	for id in _nodes.keys():
		var node := _nodes[id] as LevelMapNode
		if node == null or not is_instance_valid(node) or node.button == null or node.button.disabled:
			continue
		var tex := node.button.texture_normal
		if tex == null:
			continue
		var local := node.button.get_global_transform().affine_inverse() * pos
		var half := tex.get_size() * 0.5
		if absf(local.x) <= half.x and absf(local.y) <= half.y:
			var d := local.length()
			if d < best_dist:
				best_dist = d
				best = node
	return best


func _on_gate_pressed(chapter_id: int) -> void:
	gate_pressed.emit(chapter_id)
