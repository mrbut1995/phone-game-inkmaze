class_name LevelSection
extends Control
const LocalizationManagerScript := preload("res://scripts/autoload/LocalizationManager.gd")
const SaveManagerScript := preload("res://scripts/autoload/SaveManager.gd")
## ============================================================================
## Component: LevelSection — KHỐI BẢN ĐỒ MÀN CHƠI nhúng trong màn Main (nodes/main/level_section.tscn).
##
## Đây là phần LOGIC của màn Levels cũ (scripts/ui/screens/levels.gd) được tách thành component để
## Main hiển thị thẳng bản đồ (màn Levels bị gỡ). Mỗi bố cục (Portrait / Landscape) của Main có
## MỘT LevelSection riêng; bản đang ẩn không dựng bản đồ (xem `_dirty`).
##
## Gồm: `MapArea` (clip) + `LevelMap` · `ChapterChip` (‹ CHƯƠNG n ›) · `ChapterChestWidget` (rương mốc)
## · `DungeonPill` (nút Dungeon nổi). Khung "chương đang khoá" (`ChapterLockSheet`) nằm trong
## bố cục Main (phủ cả màn) và được bind qua `lock_sheet`.
##
## Quy ước: node UI bind bằng `@export`; dây signal nội bộ khai bằng `[connection]` trong
## nodes/main/level_section.tscn; script chỉ lo DỮ LIỆU (GameManager / LevelManager API như levels.gd).
## ============================================================================

## Kéo bản đồ ⇒ Main chuyển cho nền giấy parallax trượt theo
## Scene contract
## Exports:  map, chapter_chip, chest, dungeon_pill, lock_sheet, continuous
## Emits:    scrolled, chest_claimed
## Handlers wired in scene: _on_chest_claim_requested, _on_gate_pressed, _on_level_selected, _on_map_scrolled
## Subscribes in code (EventBus/Model): visibility_changed, loc, save, lock_sheet.unlock_requested

signal scrolled(delta_y: float)
## Vừa nhận rương ⇒ Main cập nhật ví Xu / tổng Sao
signal chest_claimed

@export var map: LevelMap = null
@export var chapter_chip: ChapterChip = null
@export var chest: ChapterChestWidget = null
@export var dungeon_pill: DungeonPill = null
## Khung chương khoá (NodePath ghi đè trong bố cục Main)
@export var lock_sheet: ChapterLockSheet = null
## ĐƯỜNG LIỀN: nối mọi chương thành MỘT đường, giữa 2 chương có CỔNG yêu cầu đủ Sao (xem `_line_ids`).
## Tắt ⇒ hành vi cũ (mỗi lần một chương, đổi chương bằng chip ‹ ›).
@export var continuous := true

var _level_ids: Array[int] = []
var _level_data: Dictionary = {}   # level_id -> LevelData
var _dirty := true
var _line_ids: Array[int] = []        # đường liền: mã màn (dương) xen mã cổng (ÂM = -chương phía trên)
var _gate_info: Dictionary = {}       # gate_id -> {chapter, from, own, need, unlocked}
var _unlocking := false               # đang chạy hiệu ứng mở cổng (chặn bấm trùng)
var _view_chapter := 0                # chương đang nằm ở tiêu điểm (chỉ đường liền)


func _ready() -> void:
	_wire_lock_sheet()
	if map != null:
		map.tap_guard = func() -> bool: return not is_sheet_open()
	_connect_locale_signal()
	_connect_save_signal()
	visibility_changed.connect(_on_visibility_changed)
	refresh()


## Dựng lại bản đồ + chip chương + rương (gọi khi màn active lại, đổi hướng, đổi ngôn ngữ).
## Bố cục ĐANG ẨN thì chỉ đánh dấu `_dirty` (LevelMap cần khung có cỡ thật để dựng).
func refresh() -> void:
	if not is_visible_in_tree():
		_dirty = true
		return
	_dirty = false
	_wire_lock_sheet()
	_build_map()
	_refresh_chapter_chip()
	_refresh_chest()


## Chỉ làm mới SỐ LIỆU (Sao/rương) — không dựng lại bản đồ, không cuộn lại
func refresh_progress() -> void:
	if not is_visible_in_tree():
		_dirty = true
		return
	_refresh_chapter_chip()
	_refresh_chest()


func _on_visibility_changed() -> void:
	if is_visible_in_tree() and _dirty:
		# Chờ 1 frame để khung đã có cỡ thật rồi mới dựng
		await get_tree().process_frame
		if is_inside_tree():
			refresh()


func _connect_locale_signal() -> void:
	var loc: Node = Svc.loc() as LocalizationManagerScript
	if loc != null and loc.has_signal("locale_changed") \
			and not loc.locale_changed.is_connected(_on_locale_changed):  # keep-code: signal của AUTOLOAD / node sinh lúc chạy — không phải node tĩnh
		loc.locale_changed.connect(_on_locale_changed)  # EXCEPTION(R3-keep): signal của AUTOLOAD / node sinh lúc chạy — không phải node tĩnh


func _on_locale_changed(_locale: String) -> void:
	refresh_progress()


## Tiến trình (Sao/chương mở) nạp XONG sau khi màn Main đã mở ⇒ phải dựng lại bản đồ, nếu không
## bản đồ hiện sai trạng thái (vd. "màn nên chơi tiếp" không phải CURRENT)
func _connect_save_signal() -> void:
	var save: Node = Svc.save() as SaveManagerScript
	if save != null and save.has_signal("data_loaded") \
			and not save.data_loaded.is_connected(_on_save_data_loaded):  # keep-code: signal của AUTOLOAD / node sinh lúc chạy — không phải node tĩnh
		save.data_loaded.connect(_on_save_data_loaded)  # EXCEPTION(R3-keep): signal của AUTOLOAD / node sinh lúc chạy — không phải node tĩnh


func _on_save_data_loaded(_a = null, _b = null) -> void:
	_view_chapter = 0
	refresh()


# ---------------------------------------------------------------------------
# Khung "chương đang khoá"
# ---------------------------------------------------------------------------
func _wire_lock_sheet() -> void:
	if lock_sheet == null:
		return
	# `map.gate_pressed` khai trong nodes/main/level_section.tscn;
	# `lock_sheet` nằm NGOÀI scene này (con của layout) nên nối tại đây sau khi biết layout.
	if not lock_sheet.unlock_requested.is_connected(_on_unlock_chapter_requested):
		lock_sheet.unlock_requested.connect(_on_unlock_chapter_requested)  # EXCEPTION(R3-keep): node của layout (ngoài scene này)


func is_sheet_open() -> bool:
	return lock_sheet != null and lock_sheet.is_open()


func close_sheet() -> void:
	if lock_sheet != null:
		lock_sheet.close_sheet()


func _on_unlock_chapter_requested(chapter_id: int) -> void:
	var gm := _game_manager()
	if gm == null:
		return
	if _unlocking:
		return
	if bool(gm.call("unlock_chapter", chapter_id)):
		Sfx.play(Sfx.ACHIEVEMENT)
		close_sheet()
		gm.call("set_chapter", chapter_id)
		if continuous:
			_unlocking = true
			await _play_unlock_sequence(chapter_id)
			_unlocking = false
		else:
			_rebuild_for_chapter()
	else:
		Sfx.play(Sfx.BTN_CLICK)


# ---------------------------------------------------------------------------
# Bản đồ (port từ levels.gd)
# ---------------------------------------------------------------------------
func _build_map() -> void:
	_load_level_ids()
	if map == null:
		return
	if continuous:
		_build_line()
		map.build(_line_ids, _stars_dict(), _unlocked_level(), chapter_continue_level(),
			_all_bonus_ids(), _gate_info)
		if _view_chapter <= 0:
			_view_chapter = _chapter_of(chapter_continue_level())
	else:
		map.build(_level_ids, _stars_dict(), _unlocked_level(), chapter_continue_level(), bonus_level_ids())
	_play_pending_clear()


## Vừa chơi xong (thắng / skip) ở ván trước ⇒ giao nhật ký sự kiện cho bản đồ; bản đồ tự quyết định có phát
## animation hay không (xem `LevelMap.queue_progress_animation`)
func _play_pending_clear() -> void:
	var gm := _game_manager()
	if map == null or gm == null or not gm.has_method("take_map_events"):
		return
	var events: Array = gm.call("take_map_events")
	if events.is_empty():
		return
	## Chỉ lấy và chạy màn cuối
	map.queue_progress_animation(events.slice(-1))


func _on_map_scrolled(delta_y: float) -> void:
	scrolled.emit(delta_y)
	if continuous:
		_update_view_chapter()


## Chương ở tiêu điểm đổi (cuộn qua cổng) ⇒ cập nhật header chương + rương
func _update_view_chapter() -> void:
	if map == null:
		return
	var id := map.focus_level_id()
	if id == 0:
		return
	var chapter := int((_gate_info.get(id, {}) as Dictionary).get("from", 0)) if id < 0 else _chapter_of(id)
	if chapter > 0 and chapter != _view_chapter:
		_view_chapter = chapter
		_refresh_chapter_chip()
		_refresh_chest()


## Dựng danh sách ĐƯỜNG LIỀN: màn từng chương (tăng dần) xen CỔNG trước mỗi chương cần Sao/đang khoá
func _build_line() -> void:
	_line_ids.clear()
	_gate_info.clear()
	var gm := _game_manager()
	var chapters := _chapter_ids()
	if chapters.is_empty():
		_line_ids.append_array(_level_ids)
		return
	var previous := 0
	for chapter_id in chapters:
		var ids: Array[int] = []
		for level_id in _level_ids:
			if _chapter_of(level_id) == chapter_id:
				ids.append(level_id)
		ids.sort()
		if ids.is_empty():
			continue
		if previous > 0 and gm != null:
			var need := int(gm.call("chapter_star_cost", chapter_id))
			var opened := bool(gm.call("is_chapter_unlocked", chapter_id))
			if need > 0 or not opened:
				var gate_id := -chapter_id
				_line_ids.append(gate_id)
				_gate_info[gate_id] = {"chapter": chapter_id, "from": previous,
					"own": int(gm.call("total_stars")), "need": need, "unlocked": opened}
		_line_ids.append_array(ids)
		previous = chapter_id


## Mở cổng thành công: cửa mở ra ⇒ bản đồ trượt sang màn đầu chương mới ⇒ các màn phía sau SÁNG DẦN
func _play_unlock_sequence(chapter_id: int) -> void:
	if map != null:
		await map.play_gate_open(-chapter_id)
		map.prepare_reveal(-chapter_id)
	_view_chapter = chapter_id
	_build_map()
	_refresh_chapter_chip()
	_refresh_chest()


## Bấm cổng (KHÔNG mở popup): chương còn khoá + ĐỦ Sao ⇒ mở khoá luôn (cổng mở + sang chương mới) ·
## chưa đủ Sao ⇒ cổng lắc (từ chối) · chương đã mở ⇒ không làm gì
func _on_gate_pressed(chapter_id: int) -> void:
	var gm := _game_manager()
	if gm == null or _unlocking or bool(gm.call("is_chapter_unlocked", chapter_id)):
		return
	if bool(gm.call("can_unlock_chapter", chapter_id)):
		_on_unlock_chapter_requested(chapter_id)
	elif map != null:
		map.reject_gate(-chapter_id)


func _all_bonus_ids() -> Array[int]:
	var ids: Array[int] = []
	for level_id in _level_ids:
		if _is_bonus(level_id):
			ids.append(level_id)
	return ids


func _on_level_selected(level_id: int) -> void:
	var gm := _game_manager()
	if continuous and gm != null and gm.has_method("set_chapter"):
		gm.call("set_chapter", _chapter_of(level_id))   # ván này thuộc chương nào thì "chương hiện tại" là chương đó
	if gm != null and gm.has_method("start_level"):
		gm.call("start_level", level_id)
	else:
		Nav.goto_game()


func _load_level_ids() -> void:
	_level_ids.clear()
	_level_data.clear()
	var lm: Node = Svc.level()
	if lm != null and lm.has_method("get_level_ids"):
		for level_id in lm.call("get_level_ids"):
			_level_ids.append(int(level_id))
		for level_id in _level_ids:
			_level_data[level_id] = lm.call("load_level", level_id)
		if not continuous:
			_filter_by_chapter()
	else:
		for level_id in range(1, 10):
			_level_ids.append(level_id)


func _filter_by_chapter() -> void:
	var chapter := _current_chapter()
	if chapter <= 0:
		return
	var filtered: Array[int] = []
	for level_id in _level_ids:
		if _chapter_of(level_id) == chapter:
			filtered.append(level_id)
	_level_ids = filtered


func _chapter_of(level_id: int) -> int:
	var data: LevelData = _level_data.get(level_id, null)
	return maxi(data.chapter, 1) if data != null else 1


func _current_chapter() -> int:
	var gm := _game_manager()
	if gm == null:
		return 0
	var value: Variant = gm.get("current_chapter")
	return maxi(int(value), 0) if value != null else 0


func _chapter_id() -> int:
	if continuous and _view_chapter > 0:
		return _view_chapter
	return maxi(_current_chapter(), 1)


func _unlocked_level() -> int:
	var gm := _game_manager()
	return maxi(int(gm.get("unlocked_levels")), 1) if gm != null else 1


## Màn "nên chơi tiếp" TRONG chương: màn CHƯA đạt sao đầu tiên
func chapter_continue_level() -> int:
	var stars := _stars_dict()
	if continuous:
		return _continue_level_line(stars)
	for level_id in _level_ids:
		if int(stars.get(level_id, 0)) <= 0:
			return level_id
	return _level_ids[_level_ids.size() - 1] if not _level_ids.is_empty() else 1


## Đường liền: màn CHƯA có sao đầu tiên trong các chương ĐÃ MỞ (không nhảy qua cổng khoá)
func _continue_level_line(stars: Dictionary) -> int:
	var gm := _game_manager()
	var sorted := _level_ids.duplicate()
	sorted.sort()
	var last_open := 1
	for level_id in sorted:
		var chapter := _chapter_of(level_id)
		if gm != null and chapter > 1 and not bool(gm.call("is_chapter_unlocked", chapter)):
			continue
		last_open = level_id
		if int(stars.get(level_id, 0)) <= 0 and not _is_bonus(level_id):
			return level_id
	return last_open


func _chapter_levels(chapter_id: int) -> Array[int]:
	var ids: Array[int] = []
	for level_id in _level_ids:
		if _chapter_of(level_id) == chapter_id:
			ids.append(level_id)
	ids.sort()
	return ids


func _is_bonus(level_id: int) -> bool:
	var lm: Node = Svc.level()
	return lm != null and lm.has_method("is_bonus_level") and bool(lm.call("is_bonus_level", level_id))


func main_level_ids() -> Array[int]:
	var ids: Array[int] = []
	for level_id in (_chapter_levels(_chapter_id()) if continuous else _level_ids):
		if not _is_bonus(level_id):
			ids.append(level_id)
	return ids


func bonus_level_ids() -> Array[int]:
	var ids: Array[int] = []
	for level_id in (_chapter_levels(_chapter_id()) if continuous else _level_ids):
		if _is_bonus(level_id):
			ids.append(level_id)
	return ids


## Tất cả màn CHÍNH của chương đã xong (BONUS không bắt buộc)
func chapter_cleared() -> bool:
	var stars := _stars_dict()
	var main_ids := main_level_ids()
	for level_id in main_ids:
		if int(stars.get(level_id, 0)) <= 0:
			return false
	return not main_ids.is_empty()


func _stars_dict() -> Dictionary:
	var gm := _game_manager()
	var stars: Variant = gm.get("level_stars") if gm != null else null
	return stars if stars is Dictionary else {}


func _game_manager() -> Node:
	return Svc.game()


func level_ids() -> Array[int]:
	return _level_ids.duplicate()


# ---------------------------------------------------------------------------
# Chương: chip ‹ CHƯƠNG n › + chuyển chương
# ---------------------------------------------------------------------------
func _chapters() -> Array:
	var lm: Node = Svc.level()
	if lm == null or not lm.has_method("get_chapters"):
		return []
	return lm.call("get_chapters")


## Mã các chương CÓ màn, tăng dần
func _chapter_ids() -> Array[int]:
	var ids: Array[int] = []
	var lm: Node = Svc.level()
	for chapter_v in _chapters():
		var chapter := chapter_v as ChapterData
		if chapter == null:
			continue
		if lm != null and lm.has_method("levels_in_chapter") \
				and (lm.call("levels_in_chapter", chapter.chapter_id) as Array).is_empty():
			continue
		ids.append(chapter.chapter_id)
	ids.sort()
	return ids


## Chương liền kề: `dir` = -1 (trước) / +1 (sau); 0 = không có
func _neighbor_chapter(dir: int) -> int:
	var current := _chapter_id()
	var best := 0
	for chapter_id in _chapter_ids():
		if dir < 0 and chapter_id < current:
			best = chapter_id   # lấy chương lớn nhất nhỏ hơn hiện tại
		elif dir > 0 and chapter_id > current:
			return chapter_id
	return best


func _refresh_chapter_chip() -> void:
	if chapter_chip == null:
		return
	if continuous:
		chapter_chip.visible = false   # đường liền: nhãn "CHƯƠNG n" nằm DƯỚI từng cổng, không cần chip nổi  # keep-code: trạng thái theo dữ liệu (runtime)
		return
	chapter_chip.setup(_chapter_id(), _neighbor_chapter(-1) > 0, _neighbor_chapter(1) > 0,
		chapter_cleared())


func _on_prev_chapter() -> void:
	_go_chapter(_neighbor_chapter(-1))


func _on_next_chapter() -> void:
	_go_chapter(_neighbor_chapter(1))


## Sang chương `chapter_id`: đã mở ⇒ đổi TẠI CHỖ (không đổi scene) · khoá ⇒ mở khung chương khoá
func _go_chapter(chapter_id: int) -> void:
	if chapter_id <= 0 or chapter_id == _chapter_id():
		return
	var gm := _game_manager()
	if gm == null:
		return
	if continuous:
		_scroll_to_chapter(chapter_id, bool(gm.call("is_chapter_unlocked", chapter_id)))
		return
	if not bool(gm.call("is_chapter_unlocked", chapter_id)):
		if lock_sheet != null:
			lock_sheet.open_chapter(chapter_id)
		return
	gm.call("set_chapter", chapter_id)
	_rebuild_for_chapter()


## Đường liền: ‹ › cuộn tới màn ĐẦU chương (đã mở) hoặc tới CỔNG chương (còn khoá)
func _scroll_to_chapter(chapter_id: int, opened: bool) -> void:
	var ids := _chapter_levels(chapter_id)
	if map == null or ids.is_empty():
		return
	map.scroll_to(ids[0] if opened else -chapter_id, true)
	_view_chapter = chapter_id
	_refresh_chapter_chip()
	_refresh_chest()


func _rebuild_for_chapter() -> void:
	_build_map()
	_refresh_chapter_chip()
	_refresh_chest()


# ---------------------------------------------------------------------------
# Rương mốc thưởng của chương
# ---------------------------------------------------------------------------
func _chapter_stars(chapter_id: int) -> int:
	var lm: Node = Svc.level()
	if lm != null and lm.has_method("chapter_stars"):
		return int(lm.call("chapter_stars", chapter_id))
	var own := 0
	for value in _stars_dict().values():
		own += int(value)
	return own


func _chapter_star_total(chapter_id: int) -> int:
	var lm: Node = Svc.level()
	if lm != null and lm.has_method("chapter_star_total"):
		return maxi(int(lm.call("chapter_star_total", chapter_id)), 1)
	return maxi(main_level_ids().size(), 1) * 3


func _refresh_chest() -> void:
	if chest == null:
		return
	var gm := _game_manager()
	if gm == null or not gm.has_method("chapter_chest_defs"):
		chest.visible = false  # keep-code: trạng thái theo dữ liệu (runtime)
		return
	var chapter_id := _chapter_id()
	var total := _chapter_star_total(chapter_id)
	var defs: Array = gm.call("chapter_chest_defs", total)
	var claimed: Array = []
	for i in defs.size():
		var is_claimed := gm.has_method("is_chapter_chest_claimed") \
			and bool(gm.call("is_chapter_chest_claimed", chapter_id, i))
		claimed.append(is_claimed)
	chest.setup(defs, _chapter_stars(chapter_id), total, claimed)


## Bấm rương (đủ Sao): trao thưởng 1 lần/chương rồi mở popup rương (dùng lại popup mốc Daily)
func _on_chest_claim_requested(index: int) -> void:
	var gm := _game_manager()
	if gm == null or not gm.has_method("claim_chapter_chest"):
		return
	var chapter_id := _chapter_id()
	var def: Dictionary = gm.call("claim_chapter_chest", chapter_id, index,
		_chapter_stars(chapter_id), _chapter_star_total(chapter_id))
	if def.is_empty():
		Sfx.play(Sfx.BTN_CLICK)
		return
	Sfx.play(Sfx.ACHIEVEMENT)
	_show_chest_reward(chapter_id, def)
	_refresh_chest()
	chest_claimed.emit()


func _show_chest_reward(chapter_id: int, def: Dictionary) -> void:
	var gm := _game_manager()
	var reward_text := ""
	if gm != null and gm.has_method("chapter_chest_reward_text"):
		reward_text = str(gm.call("chapter_chest_reward_text", def))
	Popups.open(Popups.DAILY_MILESTONE, {
		"stars": int(def.get("stars", 0)),
		"reward": def,
		"reward_text": reward_text,
		"title_text": TranslationServer.translate("STR_CHAPTER_CHEST_POPUP_TITLE").format([
			chapter_id, int(def.get("stars", 0))]),
		"sub_text": TranslationServer.translate("STR_CHAPTER_CHEST_POPUP_SUB"),
	})
