class_name CongratsFirstTimeTutorial
extends BaseTutorial
## Bài CHÚC MỪNG cuối luồng học lần đầu (xem `TutorialManager.FLOW`):
## chúc mừng người chơi đã xong 3 bài học + 4 màn thử sức, rồi cho CHỌN:
##   · CHƠI BÀN TIẾP THEO → vào luôn màn kế tiếp trong chương
##   · VỀ MÀN HÌNH CHÍNH  → về Main
## Màn này dùng 2 nút riêng ở đáy nên ẩn thanh điều hướng mặc định (nút Tiếp tục · chấm bước).

## Scene contract
## Exports:  stamp, btn_continue, btn_main, fx_anim, confetti, stat_cards, lbl_stat_a, lbl_stat_b
## Emits:    (none)
## Handlers wired in scene: _on_continue_pressed, _on_main_pressed
## Subscribes in code (EventBus/Model): (none)

const TITLE_KEY := "STR_TUT_CONGRATS_TITLE"

## Con dấu "HOÀN THÀNH" trang trí giữa màn + 2 nút lựa chọn (bind trong .tscn)
@export var stamp: TextureRect = null
@export var btn_continue: BaseButton = null
@export var btn_main: BaseButton = null
## Hiệu ứng riêng của bài (animation "congrats") — node tên `CongratsAnim` vì scene kế thừa
## `base_tutorial.tscn` đã có sẵn `AnimationPlayer` (hiệu ứng vào màn) — không được trùng tên.
@export var fx_anim: AnimationPlayer = null
## Confetti nền + 2 thẻ thống kê (3 bài học · 4 màn thử sức) hiện ra sau khi con dấu đóng xong
@export var confetti: Control = null
@export var stat_cards: Array[Control] = []
@export var lbl_stat_a: Label = null
@export var lbl_stat_b: Label = null


func _init_tutorial() -> void:
	tutorial_id = "congrats_first_time"


func _get_default_steps() -> Array:
	return [{
		"title_key": TITLE_KEY,
		"message_key": "STR_TUT_CONGRATS_BODY",
		"fallback_text": "Bạn đã hoàn thành 3 bài học đầu tiên và 4 màn thử sức. Giờ bạn đã sẵn sàng cho hành trình tiếp theo!",
		"advance_mode": "AUTO",
	}]


## Ẩn thanh điều hướng mặc định + chấm bước; đóng dấu "nở" ra khi vào bài
func _on_step_entered(_index: int, _data: Dictionary) -> void:
	if btn_continue != null:
		btn_continue.text = _tr_key("STR_TUT_CONGRATS_CONTINUE", "CHƠI BÀN TIẾP THEO")
	if btn_main != null:
		btn_main.text = _tr_key("STR_TUT_CONGRATS_MAIN", "VỀ MÀN HÌNH CHÍNH")
	if lbl_stat_a != null:
		lbl_stat_a.text = _tr_key("STR_TUT_CONGRATS_STAT_LESSONS", "bài học")
	if lbl_stat_b != null:
		lbl_stat_b.text = _tr_key("STR_TUT_CONGRATS_STAT_TRIALS", "màn thử sức")
	if confetti != null:
		confetti.modulate.a = 0.0
	for card in stat_cards:
		if card != null:
			card.pivot_offset = card.size * 0.5
			card.modulate.a = 0.0
	if wave != null:
		wave.visible = false  # keep-code: trạng thái theo dữ liệu (runtime)
	nav_bar.visible = false  # keep-code: trạng thái theo dữ liệu (runtime)
	btn_skip.visible = false  # keep-code: trạng thái theo dữ liệu (runtime)
	if lbl_step_num != null:
		lbl_step_num.get_parent().visible = false  # EXCEPTION(R2-keep): ẩn huy hiệu số bước ở màn chúc mừng
	if lbl_step_of != null:
		lbl_step_of.visible = false  # keep-code: trạng thái theo dữ liệu (runtime)
	if dots_container != null:
		dots_container.visible = false  # keep-code: trạng thái theo dữ liệu (runtime)
	# Pose ban đầu đặt NGAY bằng code (khung hình đầu đã đúng dáng, trước khi AnimationPlayer chạy);
	# phần rơi con dấu + hiện dần 2 nút khai trong animation "congrats" của scene.
	if stamp != null:
		stamp.pivot_offset = stamp.size * 0.5
		stamp.scale = Vector2(1.6, 1.6)  # EXCEPTION(R1-keep): hoạt cảnh/trạng thái runtime (tween)
		stamp.modulate.a = 0.0
		stamp.rotation = deg_to_rad(-5.0)
	for btn_node in [btn_continue, btn_main]:
		var b := btn_node as BaseButton
		if b != null:
			b.pivot_offset = b.size * 0.5
			b.modulate.a = 0.0
			b.scale = Vector2(0.88, 0.88)  # EXCEPTION(R1-keep): hoạt cảnh/trạng thái runtime (tween)
	if fx_anim != null and fx_anim.has_animation(&"congrats"):
		fx_anim.play(&"congrats")
		return
	# Fallback khi scene thiếu CongratsAnim: chạy bằng tween như trước
	if stamp != null:
		var tw := stamp.create_tween()  # EXCEPTION(R4-tween): endpoints tính lúc chạy (tween dựng bằng code — docs/refactor/tween_backlog.md)
		# Phase 1: con dấu rơi nhanh + squash nhẹ khi chạm
		tw.set_parallel(true)
		tw.tween_property(stamp, "scale", Vector2(0.88, 0.88), 0.22).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN)  # EXCEPTION(R4-tween): endpoints tính lúc chạy (tween dựng bằng code — docs/refactor/tween_backlog.md)
		tw.tween_property(stamp, "modulate:a", 1.0, 0.14)
		tw.tween_property(stamp, "rotation", 0.0, 0.22).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN)  # EXCEPTION(R4-tween): endpoints tính lúc chạy (tween dựng bằng code — docs/refactor/tween_backlog.md)
		# Phase 2: nảy lại về kích thước thật
		tw.set_parallel(false)
		tw.tween_callback(func() -> void: Sfx.play(Sfx.STAMP_IMPACT))
		tw.tween_property(stamp, "scale", Vector2.ONE, 0.34).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)  # EXCEPTION(R4-tween): endpoints tính lúc chạy (tween dựng bằng code — docs/refactor/tween_backlog.md)
		# Phase 3: nhạc chiến thắng + nút xuất hiện
		tw.tween_callback(func() -> void: Sfx.play(Sfx.LEVEL_WIN))
		tw.tween_callback(_reveal_extras)
		tw.tween_callback(func() -> void: _reveal_choice_buttons())
	else:
		Sfx.play(Sfx.LEVEL_WIN)
		_reveal_extras()
		_reveal_choice_buttons()


## Tiếng "đóng dấu" khi con dấu chạm mặt giấy — gọi từ method track của animation "congrats"
func _stamp_impact() -> void:
	Sfx.play(Sfx.STAMP_IMPACT)


## Nhạc chiến thắng khi con dấu nảy xong — gọi từ method track của animation "congrats"
func _level_win() -> void:
	Sfx.play(Sfx.LEVEL_WIN)
	_reveal_extras()


## Confetti rơi vào + 2 thẻ thống kê nảy ra (so le)
func _reveal_extras() -> void:
	if confetti != null:
		confetti.create_tween().tween_property(confetti, "modulate:a", 1.0, 0.4)  # EXCEPTION(R4-tween): endpoints tính lúc chạy (tween dựng bằng code — docs/refactor/tween_backlog.md)
	for i in stat_cards.size():
		var c := stat_cards[i]
		if c != null:
			UIAnim.play_pop_in(c, 0.08 + i * 0.12, 0.8, 0.3)


## Nút xuất hiện có stagger sau khi con dấu đóng xong
func _reveal_choice_buttons() -> void:
	var btns := [btn_continue, btn_main]
	for i in btns.size():
		var btn := btns[i] as BaseButton
		if btn != null:
			UIAnim.play_pop_in(btn, i * 0.12, 0.88, 0.28)


## "CHƠI BÀN TIẾP THEO": học xong luồng sẽ mở luôn màn kế trong chương
func _on_continue_pressed() -> void:
	var tm := Svc.tutorial()
	if tm != null and tm.has_method("request_continue_after_flow"):
		tm.call("request_continue_after_flow")
	Sfx.play(Sfx.BTN_CLICK)
	complete_tutorial()


## "VỀ MÀN HÌNH CHÍNH": học xong luồng về Main
func _on_main_pressed() -> void:
	Sfx.play(Sfx.BTN_WOOD_TAP)
	complete_tutorial()


## Dịch khoá chữ (chưa có khoá trong bảng dịch thì dùng chữ dự phòng)
func _tr_key(key: String, fallback: String) -> String:
	var text := tr(key)
	return fallback if text == key else text
