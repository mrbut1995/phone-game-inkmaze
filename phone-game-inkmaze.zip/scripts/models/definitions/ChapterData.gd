class_name ChapterData
extends Resource
## ============================================================================
## Resource: Dữ liệu 1 CHƯƠNG (màn "CHỌN CHƯƠNG" — mockup/chapter_selection.svg)
##
## Chương gom các màn theo `LevelData.chapter`; file này chỉ chứa phần HIỂN THỊ
## + điều kiện mở khóa (số Sao cần có, tính trên TỔNG Sao toàn game).
## Các file: resources/chapters/chapter_<id>.tres (LevelManager quét thư mục này).
## ============================================================================

@export var chapter_id: int = 1
## Tên chương (KHÔNG gồm chữ "CHƯƠNG n:" — UI tự ghép theo ngôn ngữ)
@export var title: String = ""
## Mô tả ngắn 1 dòng dưới tên chương
@export var subtitle: String = ""
## Khoá dịch của tên chương (có khoá -> dùng tr(title_key), không thì lấy `title`)
@export var title_key: String = ""
## Khoá dịch của mô tả ngắn
@export var subtitle_key: String = ""
## Nhãn kích thước bàn cờ hiện trên chip, ví dụ "3×3 – 5×5" (rỗng = ẩn chip)
@export var size_label: String = ""
## Số SAO cần có để mở khóa chương (0 = mở sẵn, không cần điều kiện)
@export var star_cost: int = 0
## Tên icon riêng của chương (intro/logic/trap/master — rỗng = tự suy theo số chương)
## Icon thật nằm ở assets/images/icons/icon_<tên>.svg (xem ChapterCard.ICON_KEYS)
@export var icon: String = ""
## Số màn CHÍNH của chương (tính theo thứ tự id tăng dần trong chương). Các màn đứng SAU đó là
## màn BONUS: không bắt buộc để hoàn thành chương, không tính vào Sao của chương / mốc rương.
## 0 = chương không có BONUS (mọi màn đều là màn chính).
@export var main_level_count: int = 0


func is_valid() -> bool:
	return chapter_id > 0 and not title.is_empty()


## Tên chương đã dịch (ưu tiên `title_key`)
func display_title() -> String:
	if not title_key.is_empty():
		return tr(title_key)
	return title


## Mô tả ngắn đã dịch (ưu tiên `subtitle_key`)
func display_subtitle() -> String:
	if not subtitle_key.is_empty():
		return tr(subtitle_key)
	return subtitle


## Nhãn hiển thị của chip kích thước (rỗng = không hiện)
func display_size() -> String:
	return size_label.strip_edges()


## Tên icon (rỗng = UI tự chọn theo số chương)
func display_icon() -> String:
	return icon.strip_edges()
