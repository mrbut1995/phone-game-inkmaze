class_name DebugScene
extends BaseScene
## ============================================================================
## Màn hình DEBUG / DEV CONSOLE (scenes/debug.tscn) — chỉ dùng khi phát triển.
##
## Cách mở:
##   - Phím F9 (input action "debug_console" do DebugManager tự đăng ký), bấm lần nữa để quay lại
##   - Bấm 5 lần vào con dấu phiên bản ở màn Settings (chỉ trong bản debug)
##   - Nav.goto_debug() từ code/test
##
## Nội dung các nhóm được dựng bằng code (dữ liệu khai báo trong _build()) để dễ
## thêm/bớt mục mà không phải sửa .tscn. Chữ trong màn này là chữ dev, không dịch.
## ============================================================================

## Art của các hàng/mục do code dựng — gán trong `scenes/debug.tscn` (ExtResource)
## Scene contract
## Exports:  ROW_NORMAL, ROW_PRESSED, ROW_FOCUS, ROW_DANGER_N, ROW_DANGER_P, ROW_DANGER_F, CHIP, DIVIDER, CHECK_ON, CHECK_OFF, CHECK_PRESS, CHECK_FOCUS, FALLBACK_TOTAL_LEVELS, DIFFICULTIES, TEST_FLOORS, STATS_REFRESH_SEC
## Emits:    (none)
## Handlers wired in scene: _on_back_pressed
## Subscribes in code (EventBus/Model): amount.value_changed, button.pressed, check.toggled, btn.pressed

@export var ROW_NORMAL: Texture2D = null
@export var ROW_PRESSED: Texture2D = null
@export var ROW_FOCUS: Texture2D = null
@export var ROW_DANGER_N: Texture2D = null
@export var ROW_DANGER_P: Texture2D = null
@export var ROW_DANGER_F: Texture2D = null
@export var CHIP: Texture2D = null
@export var DIVIDER: Texture2D = null
@export var CHECK_ON: Texture2D = null
@export var CHECK_OFF: Texture2D = null
@export var CHECK_PRESS: Texture2D = null
@export var CHECK_FOCUS: Texture2D = null

@export var FALLBACK_TOTAL_LEVELS := 9
@export var DIFFICULTIES := ["easy", "medium", "hard"]
@export var TEST_FLOORS := [1, 2, 3, 5]

## Node UI của màn nằm trong BỐ CỤC đang hiển thị (`Portrait` / `Landscape` — 2 hướng dùng
## CÙNG tên node). Các node đã BIND SẴN bằng `@export` trong `scenes/layout/<hướng>/debug.tscn`
## ⇒ code đọc qua `layout.<tên>`, KHÔNG tra đường dẫn; thêm/đổi node chỉ cần sửa scene + export.
var layout: DebugLayout = null

# Lựa chọn cho mục SPECIAL MODES (giữ nguyên giữa các lần dựng lại)
var _test_mode := true
var _difficulty := "medium"
var _floor := 1

## Nhịp cập nhật dòng thống kê (giây). Đổi text mỗi frame làm font phải reshape
## liên tục -> màn hình Debug bị giật; 0.2s (~5 lần/giây) là đủ để theo dõi.
@export var STATS_REFRESH_SEC := 0.2

var _stats_elapsed := 0.0
var _stats_text := ""

## Gắn node của layout đang hiển thị (2 layout giữ CÙNG đường dẫn node)
func _bind_refs() -> void:
	layout = active_layout() as DebugLayout
	if layout == null:
		push_warning("debug: bố cục chưa gắn DebugLayout — thiếu binding trong scenes/layout/<hướng>/debug.tscn")

func _ready() -> void:
	_bind_refs()
	_sync_special_selection()
	# Dây `Back.pressed → _on_back_pressed` khai trong `scenes/debug.tscn` (cả 2 bố cục)
	if layout.lbl_title != null:
		layout.lbl_title.text = "DEBUG CONSOLE"  # keep-code: chữ theo dữ liệu (runtime)
	if layout.lbl_footer != null:
		layout.lbl_footer.text = "~ F9 để đóng · chỉ hiển thị trong bản debug ~"  # keep-code: chữ theo dữ liệu (runtime)
	_build()

func _process(delta: float) -> void:
	if layout.lbl_stats == null:
		return
	_stats_elapsed += delta
	if _stats_elapsed < STATS_REFRESH_SEC:
		return
	_stats_elapsed = 0.0
	# Số căn độ rộng cố định để bề ngang dòng không nhảy theo từng frame
	var text := "FPS %3d · MEM %6.1f MB · Obj %6d · Locale %s · Mode %s" % [
		Engine.get_frames_per_second(),
		float(Performance.get_monitor(Performance.MEMORY_STATIC)) / 1048576.0,
		int(Performance.get_monitor(Performance.OBJECT_COUNT)),
		Loc.current(),
		_current_mode(),
	]
	if text != _stats_text:
		_stats_text = text
		layout.lbl_stats.text = text

# ---------------------------------------------------------------------------
# Dựng nội dung
# ---------------------------------------------------------------------------
func _build() -> void:
	if layout.rows_box == null:
		return
	# Bỏ row cũ NGAY trong frame này: chỉ queue_free sẽ để row cũ + row mới
	# cùng tồn tại 1 frame -> danh sách nhảy/nháy. Đồng thời giữ vị trí cuộn.
	var scroll := layout.rows_box.get_parent() as ScrollContainer
	var keep_scroll := 0
	if scroll != null:
		keep_scroll = scroll.scroll_vertical
	for child in layout.rows_box.get_children():
		layout.rows_box.remove_child(child)
		child.queue_free()

	_build_state()
	_build_tool_balances()
	_build_life_balances()
	_build_navigate()
	_build_progress()
	_build_daily()
	_build_events()
	_build_special_modes()
	_build_tutorials()
	_build_save()
	_build_popups()
	_build_debug_flags()

	if scroll != null:
		scroll.scroll_vertical = keep_scroll
		scroll.set_deferred("scroll_vertical", keep_scroll)  # keep-code: giữ vị trí cuộn (runtime)

func _build_state() -> void:
	_add_section("STATE")
	_add_value("Mode", _current_mode())
	_add_value("Current level", str(_gm_value("current_level", 1)))
	_add_value("Unlocked levels", str(_gm_value("unlocked_levels", 1)))
	_add_value("Save backend", "%s (cloud=%s)" % [Save.backend_id(), str(Save.is_cloud())])
	_add_value("Debug build", str(OS.is_debug_build()))
	_add_value("Platform", OS.get_name())
	_add_value("Test run", "%s · floor %d" % [str(_gm_value("debug_run", false)),
		int(_gm_value("start_floor_override", 0))])
	_add_value("Popups open", str(Popups.has_open()))

func _build_tool_balances() -> void:
	_add_section("TOOL BALANCES")
	_add_label("Số lượt dùng chung toàn bộ trò chơi; chỉ mua hàng/nhiệm vụ mới cấp thêm.",
		&"PopupSubtitle")
	var gm := _game_manager()
	if gm == null:
		_add_label("Không tìm thấy GameManager", &"PopupSubtitle")
		return
	for tool_data in [
		[ToolIds.SKIP, "Skip"],
		[ToolIds.TELEPORT, "Teleport"],
		[ToolIds.HINT, "Hint"],
	]:
		var tool_id := str(tool_data[0])
		var row := HBoxContainer.new()  # EXCEPTION(R2-runtime-node): node dựng từ dữ liệu runtime
		row.custom_minimum_size = Vector2(0, 58)
		row.add_theme_constant_override("separation", 16)  # EXCEPTION(R2-runtime-style): style tính từ dữ liệu runtime
		layout.rows_box.add_child(row)

		var label := Label.new()  # EXCEPTION(R2-runtime-node): node dựng từ dữ liệu runtime
		label.theme_type_variation = &"PopupRowLabel"
		label.text = str(tool_data[1])
		label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		row.add_child(label)

		var amount := SpinBox.new()
		amount.min_value = 0
		amount.max_value = 999999
		amount.step = 1
		amount.value = int(gm.call("tool_uses_left", tool_id))
		amount.custom_minimum_size = Vector2(180, 48)
		# EXCEPTION(R3-lambda): closure bắt biến cục bộ — tách _on_ method phải truyền thêm tham số
		amount.value_changed.connect(func(value: float) -> void:
			gm.call("debug_set_tool_uses", tool_id, int(value))
		)
		row.add_child(amount)

## LƯỢT CHƠI (life): xem số lượt, đặt lại số lượt, tua đồng hồ hồi lượt để thử luồng chờ.
func _build_life_balances() -> void:
	_add_section("LIVES")
	_add_label("Tối đa 5 lượt, mỗi 30 phút hồi 1 lượt. Thua mà không thử lại = mất 1 lượt.",
		&"PopupSubtitle")
	var gm := _game_manager()
	if gm == null:
		_add_label("Không tìm thấy GameManager", &"PopupSubtitle")
		return
	_add_value("Lives", "%d / %d" % [Life.count(), Life.max_count()])
	_add_value("Next life", "đầy lượt" if Life.seconds_to_next() <= 0
		else Life.clock_text(Life.seconds_to_next()))

	var row := HBoxContainer.new()  # EXCEPTION(R2-runtime-node): node dựng từ dữ liệu runtime
	row.custom_minimum_size = Vector2(0, 58)
	row.add_theme_constant_override("separation", 16)  # EXCEPTION(R2-runtime-style): style tính từ dữ liệu runtime
	layout.rows_box.add_child(row)

	var label := Label.new()  # EXCEPTION(R2-runtime-node): node dựng từ dữ liệu runtime
	label.theme_type_variation = &"PopupRowLabel"
	label.text = "Lives"
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(label)

	var amount := SpinBox.new()
	amount.min_value = 0
	amount.max_value = Life.max_count()
	amount.step = 1
	amount.value = Life.count()
	amount.custom_minimum_size = Vector2(180, 48)
	# EXCEPTION(R3-lambda): closure bắt biến cục bộ — tách _on_ method phải truyền thêm tham số
	amount.value_changed.connect(func(value: float) -> void:
		gm.call("debug_set_lives", int(value))
		_build()
	)
	row.add_child(amount)

	_add_action("Empty lives (0)", "Đặt lượt chơi về 0 để thử popup HẾT LƯỢT CHƠI", func() -> void:
		gm.call("debug_set_lives", 0)
		_build())
	_add_action("Fill lives (5)", "Hồi đầy 5 lượt chơi", func() -> void:
		gm.call("debug_set_lives", Life.max_count())
		_build())
	_add_action("Advance 30 min recharge", "Tua đồng hồ hồi lượt thêm 30 phút", func() -> void:
		gm.call("debug_advance_life_recharge", Life.RECHARGE_SECONDS)
		_build())

func _build_navigate() -> void:
	_add_section("NAVIGATE")
	_add_action("Main Menu", "scenes/main.tscn", func() -> void: Nav.goto_main())
	_add_action("Shop", "scenes/shop.tscn", func() -> void: Nav.goto_shop())
	_add_action("Select Level", "bản đồ nằm trong Main (đã gộp)", func() -> void: Nav.goto_levels())
	_add_action("Daily Mission", "scenes/daily.tscn", func() -> void: Nav.goto_daily())
	_add_action("Settings", "scenes/settings.tscn", func() -> void: Nav.goto_settings())
	_add_action("Credits", "scenes/credit.tscn", func() -> void: Nav.goto_credit())
	_add_action("Tutorial (menu)", "scenes/tutorial_list.tscn", func() -> void: Nav.goto_tutorial_list())
	_add_action("Badge Book", "scenes/achievement.tscn", func() -> void: Nav.goto_achievement())
	_add_action("Leaderboard", "scenes/ranking.tscn", func() -> void: Nav.goto_ranking())
	_add_action("Dungeon run", "DungeonGameMode - tầng 1", func() -> void: _gm_call("start_dungeon"))

func _build_progress() -> void:
	_add_section("PROGRESS")
	_add_label("Nhảy tới màn (màn có ◆ = chạy CHẾ ĐỘ SPECIAL ghi trong màn):", &"PopupSubtitle")
	_add_level_grid()
	_add_action("Unlock all levels", "Mở khoá 1..%d và lưu lại" % _top_level_id(), _unlock_all_levels)
	_add_action("Set 3 stars (màn đã mở)", "Ghi 3 sao cho mọi màn đang mở khoá", _set_all_stars)
	_add_action("Reset progress", "Xoá màn đã mở + sao + rương thưởng chương (không xoá Daily)",
		_reset_progress, true)

func _build_daily() -> void:
	_add_section("DAILY")
	_add_value("Today", str(_daily_value("get_today", 1)))
	_add_value("Streak", str(_daily_value("get_streak", 0)))
	_add_value("Play stars today", "%d / %d" % [
		DebugData.play_stars_today(), DebugData.play_stars_max()])
	_add_value("Stars today", "%d / %d" % [
		DebugData.stars_today(), DebugData.stars_max()])
	_add_value("Stars this month", "%d / %d" % [
		_daily_value("get_month_stars", 0), _daily_value("month_star_goal", 60)])
	_add_value("Next milestone", DebugData.next_milestone_text())
	_add_value("Milestones claimed", DebugData.claimed_milestones_text())
	_add_value("Yesterday", DebugData.yesterday_state_text())
	_add_value("AdsManager", DebugData.ads_state_text())
	_add_action("Play today's PLAY maze", "Màn CHƠI của ngày (3 nhiệm vụ = 3 Sao)",
		_play_today_classic)
	_add_action("Play today's CHALLENGE maze", "Màn THỬ THÁCH của ngày (thắng = 3 Sao)",
		_play_today_special)
	_add_action("Mark today done (6 Sao)", "Đánh dấu hôm nay xong trọn 6 Sao (3 CHƠI + 3 THỬ THÁCH)",
		_complete_today_daily)
	_add_action("Add +30 stars this month",
		"Cộng 30 Sao vào đầu tháng — test thanh tiến độ + huy hiệu mốc", _add_month_stars)
	_add_action("Claim next milestone",
		"Nhận mốc kế tiếp đã đủ Sao + mở POPUP thưởng (test luồng nhận)", _claim_next_milestone)
	_add_action("Test rewarded ad",
		"Gọi AdsManager.show_rewarded('daily_unlock') — placeholder, không ghi dữ liệu",
		_test_rewarded_ad)
	_add_action("Unlock yesterday (AD · free)",
		"Mở khoá ngày HÔM QUA như vừa xem quảng cáo — KHÔNG trừ Xu", _unlock_yesterday_by_ad)
	_add_action("Unlock all missed days (AD · free)",
		"Mở khoá MỌI ngày đã qua còn bỏ lỡ — KHÔNG trừ Xu", _unlock_all_missed)
	_add_action("Reset daily data", "Xoá toàn bộ ngày/Sao/mốc thưởng đã nhận", _reset_daily, true)

# ---------------------------------------------------------------------------
# EVENTS (Sự kiện — chỉ có ở bản dev)
# ---------------------------------------------------------------------------
func _build_events() -> void:
	_add_section("EVENTS")
	var em := _event_manager()
	if em == null:
		_add_value("EventManager", "không nạp được")
		return
	var active: Array = em.call("get_active_events")
	_add_value("Đang mở", "%d thẻ" % active.size())
	for item in active:
		var ev: EventData = item
		var prog: Dictionary = em.call("get_progress", ev.id)
		var note := "%d / %d" % [int(prog.get("done", 0)), int(prog.get("total", 0))]
		if bool(prog.get("claimed", false)):
			note += " · ĐÃ NHẬN"
		elif bool(prog.get("completed", false)):
			note += " · XONG (chờ nhận)"
		_add_value("  %s" % str(ev.id), note)
	_add_action("Bắt đầu ngay (mọi event)", "Ép cửa sổ thời gian quanh hiện tại",
		_events_start_all)
	_add_action("Kết thúc ngay (mọi event)", "Đóng cửa sổ thời gian của mọi event",
		_events_end_all)
	_add_action("+1 ngày (dịch giờ giả)", "Cộng 86400s vào now_utc() của EventManager",
		_events_shift.bind(86400))
	_add_action("-1 ngày (dịch giờ giả)", "Trừ 86400s khỏi now_utc() của EventManager",
		_events_shift.bind(-86400))
	_add_action("Hoàn thành màn kế", "Đánh dấu xong màn chưa xong đầu tiên của mỗi event series",
		_events_complete_next)
	_add_action("Đặt tiến độ = đủ", "Đẩy mọi event lên mốc cuối (để test nhận quà)",
		_events_set_full)
	_add_action("Nhận quà (mọi event)", "claim_reward cho mọi event đã hoàn thành",
		_events_claim_all)
	_add_action("Reset tiến độ + cờ đã nhận", "Xoá tiến độ và cờ claimed của mọi event",
		_events_reset, true)

func _event_manager() -> Node:
	return Svc.event()

func _events_start_all() -> void:
	var em := _event_manager()
	if em == null:
		return
	Sfx.play(Sfx.BTN_CLICK)
	for ev in em.call("get_active_events"):
		em.call("debug_set_window", (ev as EventData).id, -3600, 86400 * 7)

func _events_end_all() -> void:
	var em := _event_manager()
	if em == null:
		return
	Sfx.play(Sfx.BTN_CLICK)
	for ev in em.call("get_active_events"):
		em.call("debug_set_window", (ev as EventData).id, -86400 * 2, -3600)

func _events_shift(delta: int) -> void:
	var em := _event_manager()
	if em == null:
		return
	Sfx.play(Sfx.BTN_CLICK)
	em.call("debug_shift_time", delta)

func _events_complete_next() -> void:
	var em := _event_manager()
	if em == null:
		return
	Sfx.play(Sfx.BTN_CLICK)
	for ev in em.call("get_active_events"):
		em.call("debug_complete_next_level", (ev as EventData).id)
	_build()

func _events_set_full() -> void:
	var em := _event_manager()
	if em == null:
		return
	Sfx.play(Sfx.BTN_CLICK)
	for ev in em.call("get_active_events"):
		var ev_data: EventData = ev
		em.call("debug_set_progress", ev_data.id, maxi(ev_data.total_progress(), 1))
	_build()

func _events_claim_all() -> void:
	var em := _event_manager()
	if em == null:
		return
	Sfx.play(Sfx.BTN_CLICK)
	for ev in em.call("get_active_events"):
		var id: StringName = (ev as EventData).id
		if bool(em.call("can_claim", id)):
			em.call("claim_reward", id)
	_build()

func _events_reset() -> void:
	var em := _event_manager()
	if em == null:
		return
	Sfx.play(Sfx.BTN_CLICK)
	for ev in em.call("get_active_events"):
		em.call("debug_reset_event", (ev as EventData).id)
	_build()

# ---------------------------------------------------------------------------
# SPECIAL MODES: vào thẳng các chế độ Special còn lại (Blind Memory · Wall Builder) để test
# ---------------------------------------------------------------------------
func _build_special_modes() -> void:
	_add_section("SPECIAL MODES (TEST)")
	_add_label("Các chế độ Special còn lại — ở đây vào thẳng để thử, kèm chọn độ khó / tầng bắt đầu:",
		&"PopupSubtitle")

	_add_toggle("Test mode (không ghi tiến trình)",
		"Ván test KHÔNG đánh dấu Daily và KHÔNG tính vào danh hiệu",
		_test_mode, _set_test_mode)

	_add_label("Độ khó (áp dụng cho lần vào chế độ kế tiếp):", &"PopupSubtitle")
	for diff in DIFFICULTIES:
		_add_action(_choice_text("Độ khó", str(diff).to_upper(), diff == _difficulty),
			"Cho các mode có tham số độ khó", _set_difficulty.bind(diff))

	_add_label("Tầng bắt đầu:", &"PopupSubtitle")
	for floor_number in TEST_FLOORS:
		_add_action(_choice_text("Tầng", str(floor_number), floor_number == _floor),
			"Bắt đầu ván ở tầng %d" % floor_number, _set_test_floor.bind(floor_number))

	_add_label("Vào chế độ:", &"PopupSubtitle")
	var ids := _special_mode_ids()
	if ids.is_empty():
		_add_label("Không lấy được danh sách chế độ từ GameManager", &"PopupSubtitle")
		return
	var controller := GameModeController.new()  # EXCEPTION(R2-runtime-node): node dựng từ dữ liệu runtime
	for index in ids.size():
		var mode_id: String = ids[index]
		var mode: BaseGameMode = controller.set_mode_by_name(mode_id, _difficulty)
		var title := "%s   [%s]  ·  Daily ngày %d, %d, %d" % [mode.mode_name, mode_id, index + 1,
			index + 1 + ids.size(), index + 1 + ids.size() * 2]
		_add_action(title, mode.mode_description, _start_special_mode.bind(mode_id))
	controller.free()

	_add_action("Chế độ kế tiếp", "Xoay vòng qua các chế độ Special", _start_next_special_mode)
	_add_action("Chế độ ngẫu nhiên", "Random 1 trong các chế độ Special", _start_random_special_mode)

# ---------------------------------------------------------------------------
# TUTORIAL: vào thẳng từng bài + chạy lại chuỗi onboarding (không cần qua menu)
# ---------------------------------------------------------------------------
## Mô tả ngắn từng bài (chữ dev, không dịch) — khoá = id bài trong `TutorialController`
const TUTORIAL_LABELS := {
	"first_time": "Chào mừng + hoạt cảnh 3 ô S · ? · F",
	"how_to_play_move": "Bàn 1×3 — giữ & kéo đường S → F",
	"how_to_play_checking_wall": "Bàn 2×2 — đoán tường vô hình từ con số",
	"how_to_play_wall_builder": "Bàn 2×2 — tự vẽ tường rồi GỬI BÀI",
	"congrats_first_time": "Chúc mừng xong chuỗi mở đầu (về Main hoặc bàn kế)",
}

func _build_tutorials() -> void:
	_add_section("TUTORIAL (TEST)")
	_add_label("Vào thẳng từng bài học tương tác — bật “Test mode” nếu KHÔNG muốn ghi tiến trình:",
		&"PopupSubtitle")
	var ids := DebugData.tutorial_ids()
	_add_value("Đã hoàn thành", "%d / %d bài" % [DebugData.tutorial_done_count(), ids.size()])
	_add_toggle("Test mode (không ghi tiến trình)",
		"Bài chạy từ đây sẽ không đánh dấu là đã học xong", _test_mode, _set_test_mode)
	for id in ids:
		var mark := "●" if DebugData.tutorial_flag(id) else "○"
		_add_action("%s  %s" % [mark, id], str(TUTORIAL_LABELS.get(id, "")),
			_request_tutorial.bind(id))
	_add_action("Chạy chuỗi CORE (3 bài onboarding)", "first_time → move → checking wall",
		_request_core_sequence)
	_add_action("Đánh dấu xong hết", "Ghi cờ hoàn thành cho cả %d bài" % ids.size(),
		_mark_tutorials_done)
	_add_action("Xoá tiến trình tutorial", "Chạy lại onboarding từ đầu (không xoá màn chơi)",
		_reset_tutorials, true)

## Đặt yêu cầu mở THẲNG 1 bài rồi sang màn Tutorial (GameManager giữ yêu cầu qua scene change)
func _request_tutorial(tutorial_id: String) -> void:
	var gm := _game_manager()
	if gm != null and gm.has_method("request_tutorial"):
		gm.call("request_tutorial", tutorial_id)
	Sfx.play(Sfx.BTN_CLICK)
	Nav.goto_tutorial()

func _request_core_sequence() -> void:
	_request_tutorial(TutorialController.REQUEST_CORE)

func _mark_tutorials_done() -> void:
	var gm := _game_manager()
	if gm == null:
		return
	if gm.has_method("mark_core_tutorials_completed"):
		gm.call("mark_core_tutorials_completed")
	if gm.has_method("set_tutorial_completed"):
		for id in DebugData.tutorial_ids():
			gm.call("set_tutorial_completed", id, true)
	Save.queue_save()
	_rebuild_after_action("Đã đánh dấu xong %d bài tutorial" % DebugData.tutorial_ids().size())

func _reset_tutorials() -> void:
	var gm := _game_manager()
	if gm == null:
		return
	if gm.has_method("reset_tutorial_progress"):
		gm.call("reset_tutorial_progress")
	Save.queue_save()
	_rebuild_after_action("Đã xoá tiến trình tutorial")

func _build_save() -> void:
	_add_section("SAVE")
	_add_value("Backend", Save.backend_id())
	_add_value("Cloud available", str(Save.cloud_available()))
	_add_action("Save now", "SaveManager.save_now() - ghi file ngay", func() -> void: Save.flush())
	_add_action("Reload from disk", "Đọc lại blob và áp vào các manager", func() -> void: Save.reload_all())
	_add_action("Use local backend", "Lưu trên máy (mặc định)", func() -> void: Save.use_local())
	_add_action("Use Google Play backend", "Chỉ chạy khi đã cài plugin Play Games", func() -> void: Save.use_play_games())
	_add_action("Reset ALL saved data", "Xoá tiến trình + daily rồi ghi lại (nguy hiểm)", func() -> void: Save.reset_all(), true)
	_add_label("Blob hiện tại:", &"PopupSubtitle")
	_add_blob_dump()

func _build_popups() -> void:
	_add_section("POPUPS")
	_add_action("Win popup", "Thắng màn (Play mode)", func() -> void: _open_popup(Popups.WIN, _win_data()))
	_add_action("Next floor popup", "Qua tầng (Dungeon)", func() -> void: _open_popup(Popups.NEXT_FLOOR, _next_floor_data()))
	_add_action("Game over popup", "Hết bước / đâm tường", func() -> void: _open_popup(Popups.GAME_OVER, _game_over_data()))
	_add_action("Pause popup", "Tạm dừng + âm lượng", func() -> void: _open_popup(Popups.PAUSE, _pause_data()))
	_add_action("Language popup", "Chọn ngôn ngữ", func() -> void: _open_popup(Popups.LANGUAGE, {}))
	_add_action("Close all popups", "Đóng mọi popup đang mở", func() -> void: Popups.close_all())

func _build_debug_flags() -> void:
	_add_section("DEBUG FLAGS")
	var dbg := _debug_manager()
	if dbg == null:
		_add_label("Không tìm thấy DebugManager", &"PopupSubtitle")
		return
	_add_toggle("Debug logging", "Tắt/bật toàn bộ log debug", bool(dbg.get("enabled")),
		func(on: bool) -> void: dbg.call("set_enabled", on))
	for category in [dbg.CAT_GENERAL, dbg.CAT_SFX, dbg.CAT_FLOW, dbg.CAT_SAVE]:
		var name := str(category)
		var current := bool(dbg.call("is_flag_on", name))
		_add_toggle("· %s" % name, "Nhóm log", current,
			func(on: bool) -> void: dbg.call("set_flag", name, on))
	_add_action("Test log (all categories)", "In thử 4 dòng log", _test_logs)

# ---------------------------------------------------------------------------
# Hành động
# ---------------------------------------------------------------------------
func _unlock_all_levels() -> void:
	var gm := _game_manager()
	if gm == null:
		return
	var ids := _level_ids()
	gm.set("unlocked_levels", _top_level_id())
	var stars: Dictionary = gm.get("level_stars")
	for id in ids:
		if not stars.has(id):
			stars[id] = 0
	gm.set("level_stars", stars)
	Save.queue_save()
	_rebuild_after_action("Đã mở khoá %d màn" % ids.size())

func _set_all_stars() -> void:
	var gm := _game_manager()
	if gm == null:
		return
	var unlocked := int(gm.get("unlocked_levels"))
	var stars: Dictionary = gm.get("level_stars")
	for id in range(1, unlocked + 1):
		stars[id] = 3
	gm.set("level_stars", stars)
	Save.queue_save()
	_rebuild_after_action("Đã ghi 3 sao cho %d màn" % unlocked)

func _reset_progress() -> void:
	var gm := _game_manager()
	if gm == null:
		return
	gm.set("unlocked_levels", 1)
	gm.set("level_stars", { 1: 0 })
	gm.set("level_best_time", {})
	gm.set("current_level", 1)
	# Rương mốc thưởng của TỪNG CHƯƠNG (chapter_chests) cũng là tiến trình ⇒ xoá cùng
	if gm.has_method("reset_chapter_chests"):
		gm.call("reset_chapter_chests")
	Save.queue_save()
	_rebuild_after_action("Đã xoá tiến trình màn chơi + rương thưởng chương")

func _play_today_classic() -> void:
	_gm_call("start_daily_classic", int(_daily_value("get_today", 1)))

func _play_today_special() -> void:
	_gm_call("start_daily_challenge", int(_daily_value("get_today", 1)))

func _complete_today_daily() -> void:
	var daily := _daily_manager()
	if daily == null:
		return
	var day := int(daily.call("get_today"))
	var flags: Array[bool] = [true, true, true, true]
	daily.call("complete_day_missions", day, flags)
	_rebuild_after_action("Đã đánh dấu hôm nay hoàn thành (6 Sao: 3 CHƠI + 3 THỬ THÁCH)")

## Cộng Sao vào đầu tháng (mỗi ngày tối đa 6 Sao) — test thanh tiến độ + huy hiệu mốc
func _add_month_stars(amount := 30) -> void:
	var daily := _daily_manager()
	if daily == null:
		return
	var left := amount
	var day := 1
	while left > 0 and day <= 28:
		var play := mini(3, left)
		left -= play
		var challenge := mini(3, left)
		left -= challenge
		daily.call("set_day_stars_split", day,
			maxi(int(daily.call("get_day_play_stars", day)), play),
			maxi(int(daily.call("get_day_challenge_stars", day)), challenge))
		day += 1
	_rebuild_after_action("Đã cộng %d Sao (tổng tháng %d / %d)" % [
		amount, int(daily.call("get_month_stars")), int(daily.call("month_star_goal"))])

## Nhận mốc kế tiếp đã đủ Sao + mở popup thưởng (test luồng nhận thưởng)
func _claim_next_milestone() -> void:
	var daily := _daily_manager()
	if daily == null or not daily.has_method("milestone_defs"):
		return
	var stars := int(daily.call("get_month_stars"))
	for def in daily.call("milestone_defs"):
		var d: Dictionary = def
		var threshold := int(d.get("stars", 0))
		if stars < threshold or bool(daily.call("is_milestone_claimed", threshold)):
			continue
		if bool(daily.call("claim_milestone", threshold)):
			Popups.open(Popups.DAILY_MILESTONE, {"stars": threshold, "reward": d})
			_rebuild_after_action("Đã nhận mốc %d★ (xem popup thưởng)" % threshold)
			return
	_rebuild_after_action("Không có mốc nào đủ Sao để nhận (tháng %d Sao)" % stars)

## Thử quảng cáo thưởng (placeholder) — KHÔNG ghi dữ liệu, chỉ xem AdsManager trả gì
func _test_rewarded_ad() -> void:
	var ads := Svc.ads()
	if ads == null or not ads.has_method("show_rewarded"):
		_rebuild_after_action("Không có AdsManager")
		return
	var ok := bool(ads.call("show_rewarded", "daily_unlock"))
	_rebuild_after_action("Quảng cáo placeholder: %s" % ("xem xong ✔" if ok else "KHÔNG phát được ✘"))

## Mở khoá ngày HÔM QUA miễn phí (mô phỏng kết quả sau khi xem quảng cáo) — không trừ Xu
func _unlock_yesterday_by_ad() -> void:
	var daily := _daily_manager()
	if daily == null:
		return
	var day := int(daily.call("get_today")) - 1
	if day < 1:
		_rebuild_after_action("Hôm nay là ngày 01 — không có ngày bỏ lỡ")
		return
	daily.call("set_day_unlocked", day, true)
	_rebuild_after_action("Đã mở khoá ngày %d bằng quảng cáo (không trừ Xu)" % day)

## Mở khoá MỌI ngày đã qua còn bỏ lỡ (miễn phí) — test nhanh trạng thái lịch
func _unlock_all_missed() -> void:
	var daily := _daily_manager()
	if daily == null:
		return
	var today := int(daily.call("get_today"))
	var unlocked := 0
	for day in range(1, today):
		if int(daily.call("get_day_stars", day)) > 0 or bool(daily.call("is_day_unlocked", day)):
			continue
		daily.call("set_day_unlocked", day, true)
		unlocked += 1
	_rebuild_after_action("Đã mở khoá %d ngày bỏ lỡ bằng quảng cáo (không trừ Xu)" % unlocked)

func _reset_daily() -> void:
	var daily := _daily_manager()
	if daily == null:
		return
	if daily.has_method("reset_progress"):
		daily.call("reset_progress")
	Save.queue_save()
	_rebuild_after_action("Đã xoá dữ liệu Daily")

# ---------------------------------------------------------------------------
# SPECIAL MODES: lựa chọn + khởi động
# ---------------------------------------------------------------------------
## Đồng bộ lựa chọn hiển thị với GameManager (mở lại console vẫn nhớ độ khó/tầng)
func _sync_special_selection() -> void:
	var gm := _game_manager()
	if gm == null:
		return
	var diff := str(gm.get("current_difficulty"))
	if DIFFICULTIES.has(diff):
		_difficulty = diff
	var floor_override := int(gm.get("start_floor_override"))
	if floor_override > 0:
		_floor = floor_override

func _choice_text(prefix: String, value: String, selected: bool) -> String:
	return "%s: %s%s" % [prefix, value, "  ✔" if selected else ""]

func _special_mode_ids() -> Array[String]:
	var gm := _game_manager()
	var ids: Array[String] = []
	if gm != null and gm.has_method("special_mode_ids"):
		ids.assign(gm.call("special_mode_ids"))
	if not ids.has("wall_builder"):
		ids.append("wall_builder")
	return ids

func _set_test_mode(on: bool) -> void:
	_test_mode = on
	var gm := _game_manager()
	if gm != null:
		gm.set("debug_run", on)
	_rebuild_after_action("Test mode: %s" % ("BẬT — không ghi tiến trình" if on else "TẮT — có ghi tiến trình"))

func _set_difficulty(diff: String) -> void:
	_difficulty = diff
	_rebuild_after_action("Độ khó test: %s" % diff.to_upper())

func _set_test_floor(floor_number: int) -> void:
	_floor = floor_number
	_rebuild_after_action("Tầng bắt đầu test: %d" % floor_number)

## Vào thẳng 1 chế độ Special với độ khó / tầng / chế độ test đang chọn
func _start_special_mode(mode_id: String) -> void:
	var gm := _game_manager()
	if gm == null:
		return
	Sfx.play(Sfx.BTN_CLICK)
	gm.call("start_mode", mode_id, _difficulty, _test_mode, _floor)

func _start_next_special_mode() -> void:
	var ids := _special_mode_ids()
	if ids.is_empty():
		return
	var index := ids.find(_current_mode())
	_start_special_mode(ids[(index + 1) % ids.size()] if index >= 0 else ids[0])

func _start_random_special_mode() -> void:
	var ids := _special_mode_ids()
	if ids.is_empty():
		return
	_start_special_mode(ids[randi() % ids.size()])

func _test_logs() -> void:
	var dbg := _debug_manager()
	if dbg == null:
		return
	dbg.call("log", dbg.CAT_GENERAL, "debug console test - general")
	dbg.call("log", dbg.CAT_SFX, "debug console test - sfx")
	dbg.call("log", dbg.CAT_FLOW, "debug console test - flow")
	dbg.call("log", dbg.CAT_SAVE, "debug console test - save")

func _open_popup(id: String, data: Dictionary) -> void:
	if not Popups.has_open():
		Popups.open(id, data)

func _rebuild_after_action(message: String) -> void:
	Sfx.play(Sfx.CHECKBOX)
	if layout.lbl_footer != null:
		layout.lbl_footer.text = "~ %s ~" % message
	_build()

# ---------------------------------------------------------------------------
# Dữ liệu mẫu cho popup
# ---------------------------------------------------------------------------
func _win_data() -> Dictionary:
	return {
		"level": _gm_value("current_level", 1), "grid": "5×5", "time": 48.0,
		"steps_used": 11, "steps_max": 20, "wall_hits": 0, "score": 2850, "stars": 3,
	}

func _next_floor_data() -> Dictionary:
	return {
		"floor": 4, "next_floor": 5, "steps_bonus": 5, "base_score": 500,
		"move_bonus": 240, "perfect_bonus": 300, "total_score": 4690,
	}

func _game_over_data() -> Dictionary:
	return {"floor": 4, "progress": 75.0, "wall_hits": 3, "score": 850}

func _pause_data() -> Dictionary:
	return {"floor": 4, "steps_left": 14, "steps_max": 20, "mode_name": "dungeon"}

# ---------------------------------------------------------------------------
# Tiện ích dựng UI
# ---------------------------------------------------------------------------
func _add_section(title: String) -> void:
	var row := HBoxContainer.new()  # EXCEPTION(R2-runtime-node): node dựng từ dữ liệu runtime
	row.custom_minimum_size = Vector2(0, 58)
	layout.rows_box.add_child(row)

	var chip := TextureRect.new()  # EXCEPTION(R2-runtime-node): node dựng từ dữ liệu runtime
	chip.texture = CHIP
	chip.custom_minimum_size = Vector2(212, 40)
	chip.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(chip)

	var label := Label.new()  # EXCEPTION(R2-runtime-node): node dựng từ dữ liệu runtime
	label.theme_type_variation = &"PopupSectionLabel"
	label.text = title
	label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)  # keep-code: node sinh lúc chạy — đặt anchor khi dựng
	label.offset_left = 6
	label.offset_top = 6
	label.offset_right = -6
	label.offset_bottom = -6
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	chip.add_child(label)

	var divider := TextureRect.new()  # EXCEPTION(R2-runtime-node): node dựng từ dữ liệu runtime
	divider.texture = DIVIDER
	divider.custom_minimum_size = Vector2(0, 6)
	divider.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	divider.stretch_mode = TextureRect.STRETCH_TILE
	layout.rows_box.add_child(divider)

func _add_label(text: String, variation: StringName) -> void:
	var label := Label.new()  # EXCEPTION(R2-runtime-node): node dựng từ dữ liệu runtime
	label.theme_type_variation = variation
	label.text = text
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	layout.rows_box.add_child(label)

## Hàng chỉ để xem thông tin: tên bên trái, giá trị bên phải
func _add_value(name: String, value: String) -> void:
	var row := HBoxContainer.new()  # EXCEPTION(R2-runtime-node): node dựng từ dữ liệu runtime
	row.custom_minimum_size = Vector2(0, 42)
	layout.rows_box.add_child(row)

	var key := Label.new()  # EXCEPTION(R2-runtime-node): node dựng từ dữ liệu runtime
	key.theme_type_variation = &"PopupRowLabel"
	key.text = name
	key.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	key.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(key)

	var val := Label.new()  # EXCEPTION(R2-runtime-node): node dựng từ dữ liệu runtime
	val.theme_type_variation = &"PopupStatValueSm"
	val.text = value
	val.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	val.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(val)

## Nút hành động (danger = đỏ cho hành động phá dữ liệu)
func _add_action(text: String, desc: String, handler: Callable, danger := false) -> TextureButton:
	var button := TextureButton.new()
	button.custom_minimum_size = Vector2(0, 84)
	button.ignore_texture_size = true
	button.stretch_mode = TextureButton.STRETCH_SCALE
	if danger:
		button.texture_normal = ROW_DANGER_N
		button.texture_pressed = ROW_DANGER_P
		button.texture_hover = ROW_DANGER_P
		button.texture_focused = ROW_DANGER_F
	else:
		button.texture_normal = ROW_NORMAL
		button.texture_pressed = ROW_PRESSED
		button.texture_hover = ROW_PRESSED
		button.texture_focused = ROW_FOCUS
	button.pressed.connect(handler)
	layout.rows_box.add_child(button)

	var title := Label.new()  # EXCEPTION(R2-runtime-node): node dựng từ dữ liệu runtime
	title.theme_type_variation = &"PopupBtnTextMuted" if danger else &"PopupBtnText"
	title.text = text
	title.position = Vector2(30, 8)
	title.size = Vector2(660, 32)
	title.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	button.add_child(title)

	var sub := Label.new()  # EXCEPTION(R2-runtime-node): node dựng từ dữ liệu runtime
	sub.theme_type_variation = &"LangSub"
	sub.text = desc
	sub.position = Vector2(30, 44)
	sub.size = Vector2(660, 36)
	sub.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	sub.vertical_alignment = VERTICAL_ALIGNMENT_TOP
	button.add_child(sub)

	return button

## Hàng có checkbox bật/tắt
func _add_toggle(text: String, desc: String, value: bool, handler: Callable) -> void:
	var row := HBoxContainer.new()  # EXCEPTION(R2-runtime-node): node dựng từ dữ liệu runtime
	row.custom_minimum_size = Vector2(0, 74)
	row.add_theme_constant_override("separation", 16)  # EXCEPTION(R2-runtime-style): style tính từ dữ liệu runtime
	layout.rows_box.add_child(row)

	var text_box := VBoxContainer.new()  # EXCEPTION(R2-runtime-node): node dựng từ dữ liệu runtime
	text_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	text_box.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(text_box)

	var title := Label.new()  # EXCEPTION(R2-runtime-node): node dựng từ dữ liệu runtime
	title.theme_type_variation = &"PopupRowLabel"
	title.text = text
	text_box.add_child(title)

	var sub := Label.new()  # EXCEPTION(R2-runtime-node): node dựng từ dữ liệu runtime
	sub.theme_type_variation = &"LangSub"
	sub.text = desc
	text_box.add_child(sub)

	var check := TextureButton.new()
	check.custom_minimum_size = Vector2(50, 50)
	check.toggle_mode = true
	check.button_pressed = value
	check.ignore_texture_size = true
	check.stretch_mode = TextureButton.STRETCH_SCALE
	check.texture_normal = CHECK_OFF
	check.texture_pressed = CHECK_ON
	check.texture_hover = CHECK_PRESS
	check.texture_focused = CHECK_FOCUS
	check.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	# EXCEPTION(R3-lambda): closure bắt biến cục bộ — tách _on_ method phải truyền thêm tham số
	check.toggled.connect(func(on: bool) -> void:
		Sfx.play(Sfx.CHECKBOX)
		handler.call(on)
	)
	row.add_child(check)

## Danh sách level_id THẬT của dự án (LevelManager quét resources/levels/level_*.tres)
func _level_ids() -> Array[int]:
	var ids: Array[int] = []
	var lm := Svc.level()
	if lm != null and lm.has_method("get_level_ids"):
		for value in lm.call("get_level_ids"):
			ids.append(int(value))
	if ids.is_empty():
		for id in range(1, FALLBACK_TOTAL_LEVELS + 1):
			ids.append(id)
	return ids

## id màn lớn nhất đang có (dùng cho "Unlock all levels")
func _top_level_id() -> int:
	var ids := _level_ids()
	return ids[ids.size() - 1] if not ids.is_empty() else FALLBACK_TOTAL_LEVELS

## Chế độ riêng ghi trong màn ("" = màn thường) — hiện bằng dấu ◆ trên nút nhảy nhanh
func _level_mode(level_id: int) -> String:
	var gm := _game_manager()
	if gm == null or not gm.has_method("mode_id_of_level"):
		return ""
	var mode_id := str(gm.call("mode_id_of_level", level_id))
	return "" if mode_id == "play" else mode_id

## Lưới nút nhảy nhanh tới từng màn (màn chạy chế độ Special có thêm dấu ◆)
func _add_level_grid() -> void:
	var ids := _level_ids()
	var grid := GridContainer.new()  # EXCEPTION(R2-runtime-node): node dựng từ dữ liệu runtime
	grid.columns = mini(maxi(ids.size(), 1), 10)
	grid.add_theme_constant_override("h_separation", 10)  # EXCEPTION(R2-runtime-style): style tính từ dữ liệu runtime
	grid.add_theme_constant_override("v_separation", 10)  # EXCEPTION(R2-runtime-style): style tính từ dữ liệu runtime
	layout.rows_box.add_child(grid)

	for level_id in ids:
		var unlocked := level_id <= int(_gm_value("unlocked_levels", 1))
		var is_special := not _level_mode(level_id).is_empty()
		var btn := TextureButton.new()
		btn.custom_minimum_size = Vector2(0, 74)
		btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		btn.ignore_texture_size = true
		btn.stretch_mode = TextureButton.STRETCH_SCALE
		btn.texture_normal = ROW_NORMAL
		btn.texture_pressed = ROW_PRESSED
		btn.texture_hover = ROW_PRESSED
		btn.texture_focused = ROW_FOCUS
		# EXCEPTION(R3-lambda): closure bắt biến cục bộ — tách _on_ method phải truyền thêm tham số
		btn.pressed.connect(func() -> void:
			Sfx.play(Sfx.BTN_CLICK)
			_gm_call("start_level", level_id)
		)
		grid.add_child(btn)

		var num := Label.new()  # EXCEPTION(R2-runtime-node): node dựng từ dữ liệu runtime
		num.theme_type_variation = &"PopupTotalLabelSm"
		num.text = str(level_id) if not is_special else "%d\n◆" % level_id
		num.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)  # keep-code: node sinh lúc chạy — đặt anchor khi dựng
		num.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		num.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		num.modulate = Color(1, 1, 1, 1) if unlocked else Color(1, 1, 1, 0.45)
		btn.add_child(num)

## Xem nhanh blob lưu trữ (JSON) - hữu ích khi kiểm tra tiến trình
func _add_blob_dump() -> void:
	var sm := _save_manager()
	var dump := "(không có SaveManager)"
	if sm != null:
		var blob: Dictionary = sm.call("collect")
		dump = JSON.stringify(blob, "  ")
	var label := Label.new()  # EXCEPTION(R2-runtime-node): node dựng từ dữ liệu runtime
	label.theme_type_variation = &"LangSub"
	label.text = dump
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	layout.rows_box.add_child(label)

# ---------------------------------------------------------------------------
# Truy cập manager (dùng /root để chạy được cả trong test --script)
# ---------------------------------------------------------------------------
func _game_manager() -> Node:
	return Svc.game()

func _daily_manager() -> Node:
	return Svc.daily()

func _save_manager() -> Node:
	return Svc.save()

func _debug_manager() -> Node:
	return Svc.debug()

func _gm_value(key: String, fallback: Variant) -> Variant:
	var gm := _game_manager()
	return gm.get(key) if gm != null else fallback

func _gm_call(method: String, arg: Variant = null) -> void:
	var gm := _game_manager()
	if gm == null:
		return
	Sfx.play(Sfx.BTN_CLICK)
	if arg == null:
		gm.call(method)
	else:
		gm.call(method, arg)

func _daily_value(method: String, fallback: Variant) -> Variant:
	var daily := _daily_manager()
	return daily.call(method) if daily != null else fallback

func _current_mode() -> String:
	return str(_gm_value("current_mode", "dungeon"))

func _on_back_pressed() -> void:
	Sfx.play(Sfx.BTN_WOOD_TAP)
	Nav.goto_main()
