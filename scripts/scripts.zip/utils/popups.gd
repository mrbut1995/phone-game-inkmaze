class_name Popups
extends RefCounted
## ============================================================================
## Helper tĩnh: mở/đóng popup qua autoload PopupManager.
##
## Vì sao không gọi thẳng `PopupManager.open_popup(...)`?
##   Test runner chạy bằng `godot --script ...` -> identifier của autoload không
##   resolve được lúc parse. Vì vậy mọi nơi chỉ tham chiếu class `Popups` này,
##   node autoload được lấy qua `Svc.popup()`.
## ============================================================================

## Id các popup có sẵn (khớp PopupManager.POPUPS)
const WIN := "win"
## Popup thắng ván DAILY: nút "VỀ DAILY" thay cho "MÀN KẾ TIẾP"
const WIN_DAILY := "win_daily"
## CHALLENGE MODE: hoàn thành thử thách (popup riêng, dòng phụ đề riêng)
const WIN_CHALLENGE := "win_challenge"
const GAME_OVER := "game_over"
## Popup thua của Play/Level Mode: 3 nhiệm vụ + số Sao thay cho bước còn lại
const GAME_OVER_LEVEL := "game_over_level"
## CHALLENGE MODE: thua vì vi phạm / hết hạn thử thách (nêu rõ luật + lý do)
const GAME_OVER_CHALLENGE := "game_over_challenge"
## Popup thử lại màn trước khi vào game over
const RETRY := "retry"
const NEXT_FLOOR := "next_floor"
const PAUSE := "pause"
const LANGUAGE := "language"
## Popup đếm ngược pha GHI NHỚ của Blind Memory (không có nền mờ — vẫn thấy tường)
const MEMORIZE := "memory_countdown"
## Popup đổi diện mạo hồ sơ: avatar · viền khung · tên hiển thị
const EDIT_PROFILE := "edit_profile"
## Popup HỒ SƠ CÁ NHÂN (toàn khung) — Edit Profile mở chồng lên trên popup này
const PROFILER := "profiler"
## Popup NHỎ báo phần thưởng vừa nhận ở một MỐC SAO của màn Daily
const DAILY_MILESTONE := "daily_milestone"
## Hết LƯỢT CHƠI (life = 0): chọn thoát ra hoặc vào Cửa hàng mua thêm lượt
const OUT_OF_LIFE := "out_of_life"


static func _mgr() -> Node:
	return Svc.popup()


## Mở popup theo id. Trả về node popup (null nếu chưa có manager).
static func open(id: String, data: Dictionary = {}) -> BasePopup:
	var mgr := _mgr()
	if mgr == null:
		return null
	return mgr.call("open_popup", id, data) as BasePopup


## Mở popup từ đường dẫn scene
static func open_path(path: String, data: Dictionary = {}) -> BasePopup:
	var mgr := _mgr()
	if mgr == null:
		return null
	return mgr.call("open_path", path, data) as BasePopup


static func close_id(id: String) -> bool:
	var mgr := _mgr()
	return bool(mgr.call("close_id", id)) if mgr != null else false


static func close_top() -> bool:
	var mgr := _mgr()
	return bool(mgr.call("close_top")) if mgr != null else false


static func close_all() -> void:
	var mgr := _mgr()
	if mgr != null:
		mgr.call("close_all")


static func has_open() -> bool:
	var mgr := _mgr()
	return bool(mgr.call("has_open")) if mgr != null else false


static func is_open(id: String) -> bool:
	var mgr := _mgr()
	return bool(mgr.call("is_open", id)) if mgr != null else false


static func get_popup(id: String) -> BasePopup:
	var mgr := _mgr()
	if mgr == null:
		return null
	return mgr.call("get_popup", id) as BasePopup


static func top() -> BasePopup:
	var mgr := _mgr()
	if mgr == null:
		return null
	return mgr.call("top") as BasePopup
