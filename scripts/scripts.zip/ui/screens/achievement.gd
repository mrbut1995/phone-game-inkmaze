class_name AchievementScene
extends BaseScene
## ============================================================================
## View Controller: "Sổ tay thành tựu" (scenes/achievement.tscn)
##
## - Danh sách danh hiệu lấy từ AchievementManager (quét resources/achievements/*.tres)
##   => khi có NHIỀU danh hiệu: chia 5 thẻ/trang + VUỐT NGANG đổi trang + dots (giống màn Chọn màn).
## - 5 tab phân loại: TẤT CẢ · MÀN CHƠI · DUNGEON · DAILY · ĐẶC BIỆT (dựng lại trang theo tab).
## - Thẻ tổng kết: thanh tiến độ % đã mở khoá + "Đã mở: x / y Danh hiệu • Điểm: n AP".
## - Bấm "NHẬN +N" trên thẻ đủ điều kiện -> AchievementManager.claim() -> vẽ lại + cập nhật tổng kết.
##
## Cấu trúc node (scenes/achievement.tscn): TopBar/Sheet{Overview, Tabs, CardArea{Scroll/Pages}, Dots, Footer}
## ============================================================================

@export var CARD_SCENE: PackedScene = preload("res://nodes/achievements/card.tscn")
@export var PAGE_SCENE: PackedScene = preload("res://nodes/achievements/page.tscn")
@export var DOT_SCENE: PackedScene = preload("res://nodes/achievements/page_dot.tscn")
const UIAnim := preload("res://scripts/utils/ui_anim.gd")

## Số thẻ danh hiệu mỗi trang ở bản DỌC (1 cột × 5 hàng — khe nằm trong nodes/achievements/page.tscn)
@export var CARDS_PER_PAGE := 5
## Bản NGANG: lưới nhiều cột (thẻ 710px) × số hàng vừa khung cuộn
@export var PORTRAIT_COLUMNS := 1
## Cỡ 1 thẻ danh hiệu + khe (đọc theo `nodes/achievements/card.tscn`: 355×85 · khe 10)
@export var CARD_SIZE := Vector2(355.0, 85.0)
@export var GRID_SEP := Vector2(10.0, 10.0)
@export var SNAP_TIME := 0.22
@export var DRAG_THRESHOLD := 8.0
@export var CLICK_LOCK_TIME := 0.15

## Tab = "" (TẤT CẢ) + các category của AchievementManager
const TABS := ["", "levels", "dungeon", "daily", "special"]

## Node UI của màn nằm trong BỐ CỤC đang hiển thị (`Portrait` / `Landscape` — 2 hướng dùng
## CÙNG tên node). Các node đã BIND SẴN bằng `@export` trong `scenes/layout/<hướng>/achievement.tscn`
## ⇒ code đọc qua `layout.<tên>`, KHÔNG tra đường dẫn; thêm/đổi node chỉ cần sửa scene + export.
var layout: AchievementLayout = null

var _current_columns := PORTRAIT_COLUMNS
## Số thẻ mỗi trang ĐANG ÁP — khung đổi cỡ ⇒ chia lại trang cho vừa khung (xem `_apply_layout`)
var _current_per_page := CARDS_PER_PAGE
## Tăng mỗi lần hẹn áp layout — để bỏ qua các lần hẹn CŨ khi người dùng kéo cửa sổ liên tục
var _layout_apply_id := 0

var _category := ""
var _entries: Array = []
var _page := 0
var _page_count := 1
var _page_width := 0.0
var _scroll_tween: Tween = null
var _click_lock_until := 0.0
var _drag_active := false
var _drag_moved := false
var _drag_start_x := 0.0
var _drag_start_scroll := 0.0
## Chỉ số danh hiệu của thumb ĐẦU dải ảnh thu nhỏ (bố cục G — xem `_update_thumbs`)
var _thumb_start := 0


func _ready() -> void:
	_bind_refs()
	# Dây nút/tab khai trong `scenes/achievement.tscn` (cả 2 hướng) — guard chỉ nối lại nếu mất
	ensure_signal(layout.btn_back, &"pressed", &"_on_back_pressed")
	if layout.btn_back != null:
		UIAnim.attach_press_down(layout.btn_back)
	_connect_manager()
	orientation_changed.connect(_on_orientation_changed)

	Achievement.refresh()
	_collect_tabs()
	# Kéo cửa sổ: `resized` báo TRƯỚC khi container dàn lại ⇒ phải hẹn áp ở frame sau
	resized.connect(_schedule_apply_layout)
	_reload(true)
	call_deferred("_apply_layout")
	call_deferred("_go_to_page", _page_for_first_claimable(), false)
	# Bố cục dùng CONTAINER ⇒ khung thẻ chỉ có cỡ thật sau frame đầu → áp lại layout lần nữa
	await get_tree().process_frame
	await get_tree().process_frame
	_apply_layout()


## Phát lại EnterAnim mỗi khi màn được kích hoạt (quay lại từ màn khác)
func _on_active() -> void:
	UIAnim.play_layout_anim(active_layout(), "EnterAnim", &"enter")


## Gắn node của layout đang hiển thị (2 layout giữ cùng đường dẫn nên dùng `ui_path`)
func _bind_refs() -> void:
	layout = active_layout() as AchievementLayout
	if layout == null:
		push_warning("achievement: bố cục chưa gắn AchievementLayout — thiếu binding trong scenes/layout/<hướng>/achievement.tscn")
		return
	_connect_peek()


## Cỡ KHUNG NHÌN thật của vùng thẻ.
## Dùng `card_area` (khung cha do container dàn — ổn định) thay vì `scroll.size`: mỗi trang được đặt
## `custom_minimum_size.y = khung` nên đọc từ scroll sẽ khiến min-size của trang đẩy scroll cao lên
## (vòng lặp) ngay khi bố cục chuyển sang dùng container.
func _viewport_size() -> Vector2:
	var area := layout.card_area as Control
	if area != null and area.size.x > 0.0 and area.size.y > 0.0:
		return area.size
	if layout.scroll != null and layout.scroll.size.y < 1200.0:
		return layout.scroll.size
	return Vector2.ZERO


## Số thẻ mỗi trang: bản DỌC = 5 (1 cột × 5 hàng); bản NGANG = lưới nhiều cột × số hàng vừa khung
func _cards_per_page() -> int:
	# Bố cục "thẻ bài lớn" (G) ghim 1 thẻ/trang qua `layout.cards_per_page`
	if layout != null and layout.cards_per_page > 0:
		return layout.cards_per_page
	return _columns_per_page() * _rows_per_page()


## Số CỘT thẻ mỗi trang: cột của trang (`nodes/achievements/page.tscn`) là **VBoxContainer** ⇒ LUÔN 1 cột.
## (Bản NGANG không tự chia 2–3 cột theo bề rộng vì cột thẻ chỉ xếp được 1 cột
##  ⇒ trang nhận gấp đôi số thẻ và đẩy thẻ cuối tràn ra ngoài đáy trang.)
func _columns_per_page() -> int:
	return PORTRAIT_COLUMNS


func _rows_per_page() -> int:
	if not is_landscape:
		return CARDS_PER_PAGE
	var height := _viewport_size().y
	if height <= 0.0:
		return 3
	var rows := int((height + GRID_SEP.y * 0.5) / (CARD_SIZE.y + GRID_SEP.y))
	return clampi(rows, 2, 6)


## Xoay màn hình: gắn lại node của layout mới rồi chia lại trang theo số cột mới
func _on_orientation_changed(_is_landscape_now: bool) -> void:
	_rebind_after_orientation.call_deferred()


func _rebind_after_orientation() -> void:
	_bind_refs()
	_current_columns = _columns_per_page()
	_current_per_page = _cards_per_page()
	# Tab nằm trong layout ⇒ phải gom lại từ khay của layout MỚI (không thì bản ngang trống tab)
	_collect_tabs()
	_reload(true)
	# Cỡ khung của layout mới chỉ có sau vài frame ⇒ hẹn áp lại rồi mới nhảy tới trang cần xem
	_schedule_apply_layout()
	_go_to_page(_page_for_first_claimable(), false)


# ---------------------------------------------------------------------------
# API cho test / điều khiển từ ngoài
# ---------------------------------------------------------------------------
func current_category() -> String:
	return _category


func set_category(category: String, animate := false) -> void:
	_category = category if TABS.has(category) else ""
	_update_tabs()
	_reload(false)
	_go_to_page(_page_for_first_claimable(), animate)


func page_count() -> int:
	return _page_count


func current_page() -> int:
	return _page


func entry_count() -> int:
	return _entries.size()


func cards_on_page(page_index: int) -> int:
	var page := _page_node(page_index)
	if page == null:
		return 0
	return page.get_child(0).get_child_count() if page.get_child_count() > 0 else 0

func go_to_page(index: int, animate := true) -> void:
	_go_to_page(index, animate)


func overview_text() -> String:
	return layout.overview_summary.text if layout.overview_summary != null else ""


# ---------------------------------------------------------------------------
# Dựng nội dung
# ---------------------------------------------------------------------------
func _connect_manager() -> void:
	var manager := Achievement.manager()
	if manager != null and manager.has_signal("progress_changed"):
		if not manager.is_connected("progress_changed", _on_manager_changed):  # keep-code: signal của AUTOLOAD / node sinh lúc chạy — không phải node tĩnh
			manager.connect("progress_changed", _on_manager_changed)  # keep-code: signal của AUTOLOAD / node sinh lúc chạy — không phải node tĩnh


func _on_manager_changed() -> void:
	# Tránh dựng lại ngay giữa lúc đang bấm nút NHẬN
	call_deferred("_refresh_all")


func _refresh_all() -> void:
	if not is_inside_tree():
		return
	_reload(true)


func _reload(keep_page: bool) -> void:
	_entries = Achievement.entries(_category)
	_page_count = maxi(1, int(ceil(float(_entries.size()) / float(_cards_per_page()))))
	if not keep_page:
		_page = 0
	_page = clampi(_page, 0, _page_count - 1)

	_refresh_overview()
	_build_pages()
	_build_dots()
	_apply_layout()


func _refresh_overview() -> void:
	var total := Achievement.total_count()
	var unlocked := Achievement.unlocked_count()
	var percent := Achievement.unlocked_percent()

	if layout.overview_summary != null:
		layout.overview_summary.text = tr("STR_ACH_OVERVIEW_FORMAT").format([
			unlocked, total, Achievement.points()])
	if layout.overview_pct != null:
		layout.overview_pct.text = tr("STR_ACH_PERCENT").format([percent])
	if layout.overview_fill != null and layout.overview_bar != null:
		layout.overview_fill.size.x = maxf((layout.overview_bar.size.x - 2.0) * float(percent) / 100.0, 0.0)
	if layout.stamp_label != null:
		layout.stamp_label.text = tr("STR_ACH_BADGES_FORMAT").format([unlocked, total])


func _build_pages() -> void:
	if layout.pages_host == null:
		return
	for child in layout.pages_host.get_children():
		layout.pages_host.remove_child(child)
		child.queue_free()

	# Bố cục G (page_width > 0): đệm 2 đầu để thẻ đầu/cuối nằm GIỮA khung nhìn (rộng ra khi `_apply_layout`)
	var padded := layout.page_width > 0.0
	if padded:
		layout.pages_host.add_child(_make_pad("PadL"))

	var card_scene: PackedScene = layout.card_scene if layout.card_scene != null else CARD_SCENE
	# Số thẻ mỗi trang = số Ô VỪA KHUNG (cột × hàng). Dùng ĐÚNG con số này khi chia trang —
	# nếu ghim cứng CARDS_PER_PAGE thì ở bản NGANG (khung thấp hơn) thẻ cuối sẽ tràn ra ngoài và bị cắt.
	var per_page := maxi(_cards_per_page(), 1)
	for page_index in _page_count:
		var page := PAGE_SCENE.instantiate() as AchPage
		page.name = "Page%d" % (page_index + 1)
		layout.pages_host.add_child(page)

		var column := page.column()
		var grid := column as GridContainer
		if grid != null:
			grid.columns = maxi(_columns_per_page(), 1)
		if padded:
			# Thẻ lớn nằm GIỮA trang; thẻ nghiêng/phóng không bị cắt ở mép trang
			page.clip_contents = false
			page.mouse_filter = Control.MOUSE_FILTER_IGNORE   # trang kế bên (nằm sau trong cây) không được chặn nút của thẻ giữa
			var box := column as BoxContainer
			if box != null:
				box.alignment = BoxContainer.ALIGNMENT_CENTER
		for slot in per_page:
			var list_index := page_index * per_page + slot
			if list_index >= _entries.size():
				break
			var card: Control = card_scene.instantiate()
			column.add_child(card)
			if card.has_method("setup"):
				card.call("setup", _decorated_entry(list_index))
			if card.has_signal("claim_requested"):
				card.connect("claim_requested", _on_claim_requested)  # keep-code: signal của AUTOLOAD / node sinh lúc chạy — không phải node tĩnh
			# Thẻ lớn (G) có hiệu ứng thu/phóng riêng theo vị trí cuộn (`_update_peek`) ⇒ bỏ pop-in
			if not padded:
				UIAnim.play_pop_in(card, 0.02 * slot, 0.9, 0.18)

	if padded:
		layout.pages_host.add_child(_make_pad("PadR"))

	if layout.empty_label != null:
		layout.empty_label.visible = _entries.is_empty()


## Entry + các khoá phụ cho thẻ lớn: số thứ tự, tổng, phân loại (thẻ cũ bỏ qua các khoá này)
func _decorated_entry(list_index: int) -> Dictionary:
	var entry: Dictionary = (_entries[list_index] as Dictionary).duplicate()
	entry["index"] = list_index + 1
	entry["total"] = _entries.size()
	if not entry.has("category"):
		entry["category"] = _category
	return entry


func _make_pad(pad_name: String) -> Control:
	var pad := Control.new()
	pad.name = pad_name
	pad.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return pad


## Chỉ các TRANG (bỏ 2 ô đệm PadL/PadR của bố cục G)
func _pages() -> Array[AchPage]:
	var result: Array[AchPage] = []
	if layout == null or layout.pages_host == null:
		return result
	for child in layout.pages_host.get_children():
		var page := child as AchPage
		if page != null and not page.is_queued_for_deletion():
			result.append(page)
	return result


func _page_node(index: int) -> Control:
	var pages := _pages()
	if index < 0 or index >= pages.size():
		return null
	return pages[index]


func _on_claim_requested(id: String) -> void:
	var origin := _claim_origin(id)       # đo TRƯỚC khi dựng lại (thẻ cũ sẽ bị thay)
	if Achievement.claim(id):
		Sfx.play(Sfx.STAMP_IMPACT)
		_fly_coins(origin)
		_refresh_all()
		_play_claimed_fx(id)


# ---------------------------------------------------------------------------
# Hiệu ứng nhận thưởng: xu bay lên ví + dấu mộc đóng xuống thẻ
# ---------------------------------------------------------------------------
const FX_COIN := preload("res://assets/images-png/icons/icon_coin.png")  # keep-code: hằng dùng cho hiệu ứng/dữ liệu runtime (không phải bố cục tĩnh)
@export var FX_COIN_COUNT := 8

func _card_by_id(id: String) -> Control:
	for page in _pages():
		for card in page.column().get_children():
			if card.has_method("entry_id") and str(card.call("entry_id")) == id:
				return card as Control
	return null


func _claim_origin(id: String) -> Vector2:
	var card := _card_by_id(id)
	if card == null:
		return get_viewport_rect().size * 0.5
	if card.has_method("claim_origin"):
		return card.call("claim_origin")
	return card.get_global_rect().get_center()


## Ví xu ở thanh trên (CoinChip) — đích của xu bay
func _coin_target() -> Control:
	if layout == null:
		return null
	return layout.get_node_or_null("TopBar/CoinChip") as Control


func _fly_coins(from: Vector2) -> void:
	var target := _coin_target()
	var to := target.get_global_rect().get_center() if target != null else from + Vector2(0, -300)
	var half := Vector2(13, 13)
	for i in FX_COIN_COUNT:
		var coin := TextureRect.new()
		coin.texture = FX_COIN
		coin.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		coin.stretch_mode = TextureRect.STRETCH_SCALE
		coin.mouse_filter = Control.MOUSE_FILTER_IGNORE
		coin.size = half * 2.0
		coin.pivot_offset = half
		coin.z_index = 100
		coin.top_level = true
		add_child(coin)
		coin.global_position = from - half
		coin.scale = Vector2.ZERO
		var burst := from + Vector2(randf_range(-70.0, 70.0), randf_range(-80.0, -20.0)) - half
		var tw := create_tween()
		tw.tween_interval(0.04 * i)
		tw.tween_property(coin, "scale", Vector2.ONE, 0.1)
		tw.parallel().tween_property(coin, "global_position", burst, 0.2).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
		tw.tween_property(coin, "global_position", to - half, 0.5).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN)
		tw.parallel().tween_property(coin, "scale", Vector2.ONE * 0.55, 0.5)
		tw.tween_callback(_on_coin_arrived.bind(coin, i == FX_COIN_COUNT - 1, target))


func _on_coin_arrived(coin: Control, is_last: bool, target: Control) -> void:
	coin.queue_free()
	if target == null or not is_instance_valid(target):
		return
	# Ví nảy nhẹ mỗi lần xu chạm; xu cuối nảy mạnh hơn
	target.pivot_offset = target.size * 0.5
	var punch := 1.2 if is_last else 1.08
	var tw := create_tween().set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(target, "scale", Vector2.ONE * punch, 0.07)
	tw.tween_property(target, "scale", Vector2.ONE, 0.12)


## Chờ container dàn xong thẻ mới (đã ở trạng thái ĐÃ ĐẠT) rồi đóng dấu
func _play_claimed_fx(id: String) -> void:
	await get_tree().process_frame
	await get_tree().process_frame
	if not is_inside_tree():
		return
	var card := _card_by_id(id)
	if card != null and card.has_method("play_claimed_fx"):
		card.call("play_claimed_fx")


# ---------------------------------------------------------------------------
# Tab phân loại
# ---------------------------------------------------------------------------
## Gom các tab KHAI SẴN trong scene bố cục (`Sheet/Tabs/*` — "" · levels · dungeon · daily ·
## special), mỗi tab tự khai `category` + tự nối `pressed` → `tab_pressed`.
## Màn chỉ gom lại + nối 1 lần ⇒ KHÔNG còn dựng tab bằng code.
func _collect_tabs() -> void:
	if layout == null or layout.tabs_box == null:
		return
	for child in layout.tabs_box.get_children():
		var tab := child as AchTabButton
		if tab == null:
			continue
		ensure_signal(tab, &"tab_pressed", &"_on_tab_pressed")
	_update_tabs()


func _tab_text(category: String) -> String:
	match category:
		"":
			return tr("STR_ACH_TAB_ALL").format([Achievement.total_count()])
		"levels":
			return tr("STR_ACH_TAB_LEVELS")
		"dungeon":
			return tr("STR_ACH_TAB_DUNGEON")
		"daily":
			return tr("STR_ACH_TAB_DAILY")
		_:
			return tr("STR_ACH_TAB_SPECIAL")


func _update_tabs() -> void:
	if layout == null or layout.tabs_box == null:
		return
	for child in layout.tabs_box.get_children():
		var tab := child as AchTabButton
		if tab == null:
			continue
		tab.set_label_text(_tab_text(tab.category))
		tab.set_active(tab.category == _category)


func _on_tab_pressed(category: String) -> void:
	Sfx.play(Sfx.PAGE_TURN)
	set_category(category)


# ---------------------------------------------------------------------------
# Chỉ số trang (dots)
# ---------------------------------------------------------------------------
func _build_dots() -> void:
	# Bố cục G: dải ảnh thu nhỏ thay cho chấm trang
	if layout.thumbs_box != null and layout.thumb_scene != null:
		if layout.dots_box != null:
			layout.dots_box.visible = false  # keep-code: trạng thái theo dữ liệu (runtime)
		_build_thumbs()
		return
	if layout.dots_box == null:
		return
	for child in layout.dots_box.get_children():
		layout.dots_box.remove_child(child)
		child.queue_free()

	for index in _page_count:
		var dot := DOT_SCENE.instantiate() as AchPageDot
		dot.name = "Dot%d" % (index + 1)
		layout.dots_box.add_child(dot)
		dot.pressed.connect(_on_dot_pressed.bind(index))

	layout.dots_box.visible = _page_count > 1
	_update_dots()


func _update_dots() -> void:
	if layout.thumbs_box != null and layout.thumb_scene != null:
		_update_thumbs()
		return
	if layout.dots_box == null:
		return
	var dots := layout.dots_box.get_children()
	for index in dots.size():
		var dot := dots[index] as AchPageDot
		if dot != null:
			dot.set_current(index == _page)


func _on_dot_pressed(index: int) -> void:
	Sfx.play(Sfx.PAGE_TURN)
	_go_to_page(index)


# ---------------------------------------------------------------------------
# Điều hướng trang (giống màn Chọn màn: trang rộng bằng khung + vuốt ngang)
# ---------------------------------------------------------------------------
func _apply_layout() -> void:
	if layout.scroll == null or layout.pages_host == null:
		return
	var view_now := _viewport_size()
	if view_now.x <= 0.0 or view_now.y <= 0.0:
		return          # khung chưa dàn xong — sẽ được áp lại ở frame sau
	var columns := _columns_per_page()
	var per_page := _cards_per_page()
	if columns != _current_columns or per_page != _current_per_page:
		# Khung cuộn đổi cỡ (xoay màn hình / kéo cửa sổ) -> chia lại trang cho VỪA KHUNG
		_current_columns = columns
		_current_per_page = per_page
		_reload(true)
	_page = clampi(_page, 0, maxi(_page_count - 1, 0))
	var view := _viewport_size()
	# Bố cục G: trang hẹp hơn khung (lộ rìa thẻ bên cạnh) + đệm 2 đầu = (khung − trang) / 2
	_page_width = layout.page_width if layout.page_width > 0.0 else maxf(view.x, 1.0)
	_page_width = maxf(_page_width, 1.0)
	var pad := maxf((view.x - _page_width) * 0.5, 0.0) if layout.page_width > 0.0 else 0.0
	for pad_name in ["PadL", "PadR"]:
		var pad_node := layout.pages_host.get_node_or_null(pad_name) as Control
		if pad_node != null:
			pad_node.custom_minimum_size = Vector2(pad, view.y)
	for page in _pages():
		page.custom_minimum_size = Vector2(_page_width, view.y)
	_stop_tween()
	layout.scroll.scroll_horizontal = int(float(_page) * _page_width)
	_update_peek()
	# Khung còn đổi cỡ tiếp ở frame sau (container dàn lại) ⇒ hẹn áp lại cho khớp số mới
	if not _viewport_size().is_equal_approx(view):
		_schedule_apply_layout()


## Hẹn áp lại layout SAU khi container dàn xong.
## `resized`/đổi hướng báo trước lúc `card_area` nhận cỡ mới ⇒ áp NGAY sẽ dùng số CŨ
## (page rộng sai ⇒ trang sau lộ vào khung nhìn, hoặc trang hiện tại bị cắt nửa chừng).
## Kéo cửa sổ liên tục: chỉ lần hẹn CUỐI được áp (id tăng dần, lần cũ tự bỏ).
func _schedule_apply_layout() -> void:
	_layout_apply_id += 1
	var id := _layout_apply_id
	await get_tree().process_frame
	await get_tree().process_frame
	if id != _layout_apply_id or not is_inside_tree():
		return
	_apply_layout()


func _go_to_page(index: int, animate := true) -> void:
	_page = clampi(index, 0, maxi(_page_count - 1, 0))
	_update_dots()
	if layout.scroll == null or _page_width <= 0.0:
		return

	var target := int(float(_page) * _page_width)
	_stop_tween()
	if not animate:
		layout.scroll.scroll_horizontal = target
		return
	# (GIỮ tween) Đích cuộn = số trang × BỀ RỘNG TRANG đo lúc chạy (đổi theo cỡ khung)
	# nên không thể bake thành track tĩnh trong .tscn.
	_scroll_tween = create_tween()
	_scroll_tween.set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	_scroll_tween.tween_property(layout.scroll, "scroll_horizontal", target, SNAP_TIME)


func _stop_tween() -> void:
	if _scroll_tween != null and _scroll_tween.is_valid():
		_scroll_tween.kill()
	_scroll_tween = null


func _nearest_page() -> int:
	if _page_width <= 0.0:
		return 0
	return clampi(int(round(float(layout.scroll.scroll_horizontal) / _page_width)), 0, maxi(_page_count - 1, 0))


## Trang chứa danh hiệu đầu tiên đang chờ nhận thưởng (mở Sổ tay là thấy ngay)
func _page_for_first_claimable() -> int:
	var per_page := maxi(_cards_per_page(), 1)
	for index in _entries.size():
		if bool((_entries[index] as Dictionary).get("claimable", false)):
			return clampi(index / per_page, 0, maxi(_page_count - 1, 0))
	return 0


# ---------------------------------------------------------------------------
# Bố cục G: dải ảnh thu nhỏ + hiệu ứng thẻ bên cạnh
# ---------------------------------------------------------------------------
## Tạo (hoặc cắt bớt) các thumb: tối đa `layout.thumb_count` cái, cửa sổ trượt theo trang đang xem
func _build_thumbs() -> void:
	var box := layout.thumbs_box
	for child in box.get_children():
		box.remove_child(child)
		child.queue_free()
	var count := mini(maxi(layout.thumb_count, 1), _entries.size())
	for i in count:
		var thumb := layout.thumb_scene.instantiate() as AchThumb
		thumb.name = "Thumb%d" % (i + 1)
		box.add_child(thumb)
		thumb.pressed.connect(_on_thumb_pressed.bind(thumb))
	box.visible = count > 0
	_update_thumbs()


## Cửa sổ thumb: giữ trang hiện tại ở GIỮA dải, chạm đầu/cuối thì dừng
func _update_thumbs() -> void:
	var box := layout.thumbs_box
	if box == null:
		return
	var thumbs := box.get_children()
	var count := thumbs.size()
	if count == 0 or _entries.is_empty():
		return
	_thumb_start = clampi(_page - count / 2, 0, maxi(_entries.size() - count, 0))
	for i in count:
		var thumb := thumbs[i] as AchThumb
		var index := _thumb_start + i
		if thumb != null and index < _entries.size():
			thumb.setup(_entries[index], index, index == _page)


func _on_thumb_pressed(thumb: AchThumb) -> void:
	Sfx.play(Sfx.PAGE_TURN)
	_go_to_page(thumb.entry_index)


func _connect_peek() -> void:
	if layout.scroll == null:
		return
	var bar := layout.scroll.get_h_scroll_bar()
	if bar != null and not bar.value_changed.is_connected(_on_scroll_value_changed):
		bar.value_changed.connect(_on_scroll_value_changed)


func _on_scroll_value_changed(_value: float) -> void:
	_update_peek()


## Thẻ càng xa tâm khung càng nhỏ + mờ + nghiêng ra ngoài (chỉ khi bố cục khai `page_width`)
func _update_peek() -> void:
	if layout == null or layout.page_width <= 0.0 or layout.scroll == null or _page_width <= 0.0:
		return
	var scroll_x := float(layout.scroll.scroll_horizontal)
	var pages := _pages()
	for i in pages.size():
		var column := pages[i].column()
		if column.get_child_count() == 0:
			continue
		var card := column.get_child(0) as Control
		var offset := (float(i) * _page_width - scroll_x) / _page_width   # −1 = trang trái · 0 = giữa · +1 = trang phải
		var dist := absf(offset)
		var t := clampf(dist, 0.0, 1.0)
		card.pivot_offset = card.size * 0.5
		card.scale = Vector2.ONE * lerpf(1.0, layout.peek_scale, t)
		card.rotation = signf(offset) * layout.peek_tilt * t
		# Thẻ bên cạnh nằm DƯỚI thẻ giữa (đè lên nhau); thẻ cách 2 trang trở đi mờ dần rồi ẩn
		card.modulate.a = lerpf(1.0, layout.peek_alpha, t) * clampf(2.0 - dist, 0.0, 1.0)
		card.z_index = 10 - int(round(minf(dist, 3.0) * 3.0))
		# Chỉ thẻ ĐANG XEM nhận bấm: nút NHẬN của thẻ bên cạnh đè lên nửa phải thẻ giữa sẽ chặn chuột
		if card.has_method("set_interactive"):
			card.call("set_interactive", dist < 0.5)


# ---------------------------------------------------------------------------
# Vuốt đổi trang (tự xử lý gesture: thẻ là Button nên "ăn" sự kiện kéo)
# ---------------------------------------------------------------------------
func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch and event.index == 0:
		if event.pressed:
			_begin_drag(event.position)
		else:
			_end_drag()
	elif event is InputEventScreenDrag and event.index == 0:
		_update_drag(event.position)
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			_begin_drag(event.position)
		else:
			_end_drag()
	elif event is InputEventMouseMotion:
		if (event.button_mask & MOUSE_BUTTON_MASK_LEFT) != 0:
			_update_drag(event.position)
	elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
		_go_to_page(_page + 1)
	elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_WHEEL_UP:
		_go_to_page(_page - 1)


func _begin_drag(pos: Vector2) -> void:
	if layout.scroll == null or _page_count <= 1:
		return
	if not layout.scroll.get_global_rect().has_point(pos):
		return
	_stop_tween()
	_drag_active = true
	_drag_moved = false
	_drag_start_x = pos.x
	_drag_start_scroll = float(layout.scroll.scroll_horizontal)


func _update_drag(pos: Vector2) -> void:
	if not _drag_active:
		return
	var delta_x := pos.x - _drag_start_x
	if not _drag_moved and absf(delta_x) >= DRAG_THRESHOLD:
		_drag_moved = true
		_lock_clicks()
	if not _drag_moved:
		return
	layout.scroll.scroll_horizontal = int(_drag_start_scroll - delta_x)
	_lock_clicks()
	var index := _nearest_page()
	if index != _page:
		_page = index
		_update_dots()


func _end_drag() -> void:
	if not _drag_active:
		return
	_drag_active = false
	if _drag_moved:
		_go_to_page(_nearest_page(), true)


## Khoá bấm nút trong lúc vuốt (tránh vừa vuốt vừa kích hoạt NHẬN)
func _lock_clicks() -> void:
	_click_lock_until = float(Time.get_ticks_msec()) / 1000.0 + CLICK_LOCK_TIME


func _on_back_pressed() -> void:
	Nav.goto_main()
