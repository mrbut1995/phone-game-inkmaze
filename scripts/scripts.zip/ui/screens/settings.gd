class_name SettingsScene
extends BaseScene
## ============================================================================
## View Controller: Màn hình Cài đặt (Settings)
## Bám theo mockup mockup/settings_screen.svg:
##   1. Âm thanh        : slider Nhạc nền (BGM) + Hiệu ứng (SFX)
##   2. Bàn cờ          : 3 tuỳ chọn bật/tắt (Haptic, auto-mark, glow path)
##   3. Ngôn ngữ & lưu trữ: dropdown chọn ngôn ngữ (mở popup), chip cloud, player ID
##   4. Hỗ trợ          : xem hướng dẫn, khôi phục cài đặt mặc định
##   5. Chân trang      : câu quote + con dấu phiên bản
## Cài đặt lưu qua SettingManager (/root) nên không tham chiếu autoload trực tiếp.
## ============================================================================

signal guide_requested

@export var PLAYER_ID_PLACEHOLDER := "#NM-8924-VN"
const UIAnim := preload("res://scripts/utils/ui_anim.gd")

## Node UI của màn nằm trong BỐ CỤC đang hiển thị (`Portrait` / `Landscape` — 2 hướng dùng
## CÙNG tên node). Các node đã BIND SẴN bằng `@export` trong `scenes/layout/<hướng>/settings.tscn`
## ⇒ code đọc qua `layout.<tên>`, KHÔNG tra đường dẫn; thêm/đổi node chỉ cần sửa scene + export.
var layout: SettingsLayout = null

## Chặn ghi ngược khi đang đồng bộ UI từ SettingManager
var _syncing := false
## Số lần bấm vào con dấu phiên bản để mở màn debug
@export var DEBUG_TAP_COUNT := 5
var _stamp_taps := 0


func _ready() -> void:
	_bind_refs()
	_wire_buttons()
	orientation_changed.connect(_on_orientation_changed)

	if layout.content_root != null:
		UIAnim.play_slide_in(layout.content_root, Vector2(0, 25), 0.05, 0.25)

	_setup_debug_stamp_taps()
	_sync_from_settings()


## Gắn node của layout đang hiển thị
func _bind_refs() -> void:
	layout = active_layout() as SettingsLayout
	if layout == null:
		push_warning("settings: bố cục chưa gắn SettingsLayout — thiếu binding trong scenes/layout/<hướng>/settings.tscn")


## Nối signal + hiệu ứng (mỗi NODE chỉ nối 1 lần — xoay màn hình không nhân đôi)
func _wire_once(node: Node) -> bool:
	if node == null or node.has_meta("wired"):
		return false
	node.set_meta("wired", true)
	return true


func _wire_buttons() -> void:
	# Dây nút/slider/checkbox khai trong `scenes/settings.tscn` (cả 2 hướng)
	# — guard chỉ nối lại nếu dây bị mất (xoay màn hình gọi lại hàm này).
	ensure_signal(layout.btn_back, &"pressed", &"_on_back_pressed")
	ensure_signal(layout.bgm_slider, &"value_changed", &"_on_bgm_changed")
	ensure_signal(layout.sfx_slider, &"value_changed", &"_on_sfx_changed")
	ensure_signal(layout.chk_haptic, &"toggled", &"_on_haptic_toggled")
	ensure_signal(layout.chk_auto_mark, &"toggled", &"_on_auto_mark_toggled")
	ensure_signal(layout.chk_glow, &"toggled", &"_on_glow_toggled")
	ensure_signal(layout.btn_language, &"pressed", &"_on_language_pressed")
	ensure_signal(layout.btn_guide, &"pressed", &"_on_guide_pressed")
	ensure_signal(layout.btn_rules, &"pressed", &"_on_rules_pressed")
	ensure_signal(layout.btn_credits, &"pressed", &"_on_credits_pressed")
	ensure_signal(layout.btn_reset, &"pressed", &"_on_reset_pressed")

	for node in [layout.btn_back, layout.chk_haptic, layout.chk_auto_mark, layout.chk_glow,
			layout.btn_language, layout.btn_guide, layout.btn_rules, layout.btn_credits, layout.btn_reset]:
		if _wire_once(node):
			UIAnim.attach_press_down(node)


## Xoay màn hình: gắn lại node của layout mới rồi nạp lại giá trị cài đặt lên widget mới
func _on_orientation_changed(_is_landscape_now: bool) -> void:
	_rebind_after_orientation.call_deferred()


func _rebind_after_orientation() -> void:
	_bind_refs()
	_wire_buttons()
	_setup_debug_stamp_taps()
	_sync_from_settings()


## Bấm liên tiếp vào con dấu phiên bản để mở màn debug (chỉ trong bản debug)
func _setup_debug_stamp_taps() -> void:
	if layout.lbl_version == null:
		return
	var stamp := layout.lbl_version.get_parent() as Control
	if stamp == null:
		return
	stamp.mouse_filter = Control.MOUSE_FILTER_STOP  # keep-code: để bấm được con dấu version (runtime)
	for child in stamp.get_children():
		if child is Control:
			(child as Control).mouse_filter = Control.MOUSE_FILTER_IGNORE
	# Dây `gui_input → _on_stamp_gui_input` khai trong `scenes/settings.tscn`;
	# guard chỉ nối lại nếu dây bị mất (bấm 5 lần vào con dấu để mở màn debug)
	ensure_signal(stamp, &"gui_input", &"_on_stamp_gui_input")


func _on_stamp_gui_input(event: InputEvent) -> void:
	if not (event is InputEventMouseButton):
		return
	var mouse := event as InputEventMouseButton
	if not mouse.pressed or mouse.button_index != MOUSE_BUTTON_LEFT:
		return
	_stamp_taps += 1
	if _stamp_taps < DEBUG_TAP_COUNT:
		return
	_stamp_taps = 0
	var dbg: Node = Svc.debug()
	if dbg != null:
		dbg.call("toggle_console")


# ---------------------------------------------------------------------------
# Đồng bộ UI <-> SettingManager
# ---------------------------------------------------------------------------
func _sm() -> Node:
	return Svc.setting()


func _sync_from_settings() -> void:
	_syncing = true
	var sm := _sm()
	if sm != null:
		if layout.bgm_slider != null:
			layout.bgm_slider.value = float(sm.get("music_volume"))
		if layout.sfx_slider != null:
			layout.sfx_slider.value = float(sm.get("sfx_volume"))
		if layout.chk_haptic != null:
			layout.chk_haptic.button_pressed = bool(sm.get("vibration"))
		if layout.chk_auto_mark != null:
			layout.chk_auto_mark.button_pressed = bool(sm.get("auto_mark_safe"))
		if layout.chk_glow != null:
			layout.chk_glow.button_pressed = bool(sm.get("glow_path"))
	_update_volume_labels()
	_refresh_language()
	_refresh_version()
	_syncing = false


func _update_volume_labels() -> void:
	if layout.bgm_value != null and layout.bgm_slider != null:
		layout.bgm_value.text = _to_percent(layout.bgm_slider.value)
	if layout.sfx_value != null and layout.sfx_slider != null:
		layout.sfx_value.text = _to_percent(layout.sfx_slider.value)


func _to_percent(value: float) -> String:
	return "%d%%" % roundi(value * 100.0)


func _refresh_language() -> void:
	if layout.lbl_language != null:
		layout.lbl_language.text = Loc.display_name(Loc.current())


func _refresh_version() -> void:
	if layout.lbl_version != null:
		var app := Svc.app()
		var version := "1.0.0"
		if app != null:
			version = str(app.call("get_version"))
		layout.lbl_version.text = tr("STR_SETTINGS_VERSION").format([version])
	if layout.lbl_player_id != null:
		layout.lbl_player_id.text = PLAYER_ID_PLACEHOLDER  # keep-code: chữ theo dữ liệu (runtime)


# ---------------------------------------------------------------------------
# Âm thanh
# ---------------------------------------------------------------------------
func _on_volume_changed(value: float, kind: String, label: Label) -> void:
	_update_volume_labels()
	if _syncing:
		return
	var sm := _sm()
	if sm != null:
		sm.call("set_volume", kind, value)
	if label != null:
		label.text = _to_percent(value)
	# SFX: tiếng thước kẻ trượt khi kéo thanh âm lượng
	Sfx.play(Sfx.SLIDER_TICK)


## --- Dây từ slider/checkbox (khai trong `scenes/settings.tscn`) --------------------
func _on_bgm_changed(value: float) -> void:
	_on_volume_changed(value, "music", layout.bgm_value)


func _on_sfx_changed(value: float) -> void:
	_on_volume_changed(value, "sfx", layout.sfx_value)


func _on_haptic_toggled(on: bool) -> void:
	_on_toggle_changed(on, "vibration")


func _on_auto_mark_toggled(on: bool) -> void:
	_on_toggle_changed(on, "auto_mark_safe")


func _on_glow_toggled(on: bool) -> void:
	_on_toggle_changed(on, "glow_path")


# ---------------------------------------------------------------------------
# Tuỳ chọn bật/tắt
# ---------------------------------------------------------------------------
func _on_toggle_changed(toggled_on: bool, key: String) -> void:
	if _syncing:
		return
	var sm := _sm()
	if sm != null:
		sm.call("set_setting", key, toggled_on)
	# SFX: tiếng bút bi vẽ dấu tích
	Sfx.play(Sfx.CHECKBOX)


# ---------------------------------------------------------------------------
# Ngôn ngữ
# ---------------------------------------------------------------------------
func _on_language_pressed() -> void:
	Sfx.play(Sfx.BTN_WOOD_TAP)
	# Popup được PopupManager tạo khi mở và xoá khi đóng
	var popup := Popups.open(Popups.LANGUAGE)
	if popup == null:
		return
	if not popup.is_connected("locale_applied", _on_locale_applied):  # keep-code: signal của AUTOLOAD / node sinh lúc chạy — không phải node tĩnh
		popup.connect("locale_applied", _on_locale_applied)  # keep-code: signal của AUTOLOAD / node sinh lúc chạy — không phải node tĩnh


func _on_locale_applied(_code: String) -> void:
	_refresh_language()


# ---------------------------------------------------------------------------
# Hỗ trợ & khôi phục mặc định
# ---------------------------------------------------------------------------
func _on_guide_pressed() -> void:
	Sfx.play(Sfx.BTN_WOOD_TAP)
	# TODO: mở màn "Hướng dẫn & 9 bộ luật chơi" khi có scene tương ứng
	push_warning("[Settings] Chưa có scene hướng dẫn - cần bổ sung sau.")
	guide_requested.emit()


## LUẬT CHƠI (chuyển từ dock Main sang) → màn DANH SÁCH bài hướng dẫn
func _on_rules_pressed() -> void:
	Sfx.play(Sfx.BTN_WOOD_TAP)
	Nav.goto_tutorial_list()


func _on_credits_pressed() -> void:
	Sfx.play(Sfx.BTN_WOOD_TAP)
	Nav.goto_credit()


func _on_reset_pressed() -> void:
	var sm := _sm()
	if sm != null:
		sm.call("reset_to_defaults")
	# SFX: tiếng "cộp" con dấu khi khôi phục mặc định
	Sfx.play(Sfx.STAMP_IMPACT)
	_sync_from_settings()


# ---------------------------------------------------------------------------
# Điều hướng
# ---------------------------------------------------------------------------
func _on_back_pressed() -> void:
	Sfx.play(Sfx.BTN_WOOD_TAP)
	var gm := Svc.game()
	if gm != null and gm.has_method("go_to_main_menu"):
		gm.call("go_to_main_menu")
	else:
		Nav.goto_main()
