class_name ShopCoinTile
extends Control
## ============================================================================
## Thẻ GÓI NẠP XU 475×240 — lưới 2 cột ở tab NẠP XU (mockup/shopping_coin.svg):
##   vòng icon + ICON CẤP XU (coin_t1..coin_t5: xu đơn · cọc · đống · túi · rương)
##   · tên gói · mô tả · dòng ưu đãi · nút giá VNĐ (STUB IAP)
## ============================================================================

signal action_pressed(item_id: String)

const CARD_ART := preload("res://assets/images-png/shop/card_coin.png")  # keep-code: hằng dùng cho hiệu ứng/dữ liệu runtime (không phải bố cục tĩnh)
const ICONS := {
	"coin_t1": preload("res://assets/images-png/icons/icon_coin_t1.png"),
	"coin_t2": preload("res://assets/images-png/icons/icon_coin_t2.png"),
	"coin_t3": preload("res://assets/images-png/icons/icon_coin_t3.png"),
	"coin_t4": preload("res://assets/images-png/icons/icon_coin_t4.png"),
	"coin_t5": preload("res://assets/images-png/icons/icon_coin_t5.png"),
}

var item_id: String = ""
var item_data: Dictionary = {}
var _tap := ShopCardTap.new()


func setup(data: Dictionary) -> void:
	item_data = data
	item_id = str(data.get("id", ""))
	_refresh()


## Icon cấp Xu của gói (dùng cho test + đối chiếu mockup)
func icon_texture() -> Texture2D:
	var icon := get_node_or_null("Panel/Content/IconCircle/Icon") as TextureRect
	return icon.texture if icon != null else null


func _refresh() -> void:
	var color := Color(str(item_data.get("color", "#F59E0B")))
	var bar := get_node_or_null("Panel/Bar") as ColorRect
	if bar != null:
		bar.color = color
	# Texture vòng icon đã khai trong `coin_tile.tscn` — ở đây chỉ tô màu theo gói
	var circle := get_node_or_null("Panel/Content/IconCircle") as TextureRect
	if circle != null:
		circle.self_modulate = Color(color.r, color.g, color.b, 0.18)
	var icon := get_node_or_null("Panel/Content/IconCircle/Icon") as TextureRect
	if icon != null:
		icon.texture = ICONS.get(str(item_data.get("icon", "coin_t1")), ICONS["coin_t1"])
	_refresh_badge()
	_set_texts()
	_set_button()


func _refresh_badge() -> void:
	var badge := get_node_or_null("Panel/Badge") as NinePatchRect
	var badge_label := get_node_or_null("Panel/Badge/BadgeLabel") as Label
	var badge_key := str(item_data.get("badge_key", ""))
	if badge == null or badge_label == null:
		return
	if badge_key.is_empty():
		badge.visible = false  # keep-code: trạng thái theo dữ liệu (runtime)
		badge_label.visible = false  # keep-code: trạng thái theo dữ liệu (runtime)
		return
	badge.visible = true  # keep-code: trạng thái theo dữ liệu (runtime)
	badge_label.visible = true  # keep-code: trạng thái theo dữ liệu (runtime)
	badge_label.text = TranslationServer.translate(badge_key)


func _set_texts() -> void:
	var desc := TranslationServer.translate(str(item_data.get("desc_key", "")))
	_set_label("Panel/Content/Description/Name", TranslationServer.translate(str(item_data.get("name_key", ""))))
	_set_label("Panel/Content/Description/Desc", desc)
	# Dòng ưu đãi: chỉ hiện khi MÔ TẢ chưa nhắc tới số Xu thưởng (tránh lặp 2 dòng giống nhau)
	var bonus := int(item_data.get("bonus", 0))
	var bonus_label := get_node_or_null("Panel/Content/Description/Bonus") as Label
	if bonus_label != null:
		var show_bonus := bonus > 0 and not desc.contains(Shop.thousands(bonus))
		bonus_label.visible = show_bonus
		if show_bonus:
			bonus_label.text = "%s +%s %s" % [  # keep-code: chữ theo dữ liệu (runtime)
				TranslationServer.translate("STR_SHOP_BONUS_TAG"),
				Shop.thousands(bonus),
				TranslationServer.translate("STR_SHOP_UNIT_COIN")]


func _set_button() -> void:
	# Art nút (`btn_coin.svg`) + kiểu chữ giá VNĐ đã khai sẵn trong `coin_tile.tscn`
	# (cả 4 trạng thái) — ở đây chỉ điền số tiền của gói.
	var label := get_node_or_null("Panel/Action/ActionLabel") as Label
	if label != null:
		label.text = Shop.vnd_text(int(item_data.get("vnd", 0)))


func _set_label(path: String, text: String) -> void:
	var label := get_node_or_null(path) as Label
	if label != null:
		label.text = text

func _gui_input(event: InputEvent) -> void:
	match _tap.feed(event):
		ShopCardTap.Result.DOWN:
			ShopCardTap.press_fx(self, true)
		ShopCardTap.Result.TAP:
			ShopCardTap.press_fx(self, false)
			_on_card_tapped()
		ShopCardTap.Result.CANCEL:
			ShopCardTap.press_fx(self, false)


## CHẠM CẢ THẺ để mua (ô giá VNĐ chỉ là nhãn thông tin; cửa hàng hệ thống sẽ xác nhận lại)
func _on_card_tapped() -> void:
	action_pressed.emit(item_id)


func _on_action_pressed() -> void:
	_on_card_tapped()
