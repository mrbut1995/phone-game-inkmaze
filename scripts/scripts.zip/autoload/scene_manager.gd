class_name SceneManagerClass
extends Node
## ============================================================================
## Manager: SceneManager - Điều hướng giữa các scene + Animation chuyển cảnh
## phong cách "Sổ tay giấy & Mực" (Page Turn, Ink Bloom) + SFX lật trang.
## - Tự phát sfx_page_turn khi chuyển màn (đúng chất sổ tay giấy).
## - Ghi lịch sử vào ScreenManager để phục vụ nút Back trên Android.
## - Lớp phủ SceneTransition độc lập trên CanvasLayer chặn input khi đang đổi scene.
## ============================================================================

signal scene_changing(path: String, previous_path: String)
signal scene_changed(path: String)

const SCENE_MAIN := "res://scenes/main.tscn"
const SCENE_SPLASH := "res://scenes/splash.tscn"
const SCENE_TITLE := "res://scenes/title.tscn"
## Màn CHỌN MÀN đã GỘP vào Main (bản đồ nằm ngay trong Main)
const SCENE_LEVELS := "res://scenes/main.tscn"
const SCENE_GAME := "res://scenes/game.tscn"
const SCENE_DAILY := "res://scenes/daily.tscn"
const SCENE_SETTINGS := "res://scenes/settings.tscn"
const SCENE_DEBUG := "res://scenes/debug.tscn"
## Sổ tay thành tựu (danh hiệu) — xem scripts/ui/screens/achievement.gd
const SCENE_ACHIEVEMENT := "res://scenes/achievement.tscn"
## Bảng xếp hạng — xem scripts/ui/screens/ranking.gd
const SCENE_RANKING := "res://scenes/ranking.tscn"
## Màn CỬA HÀNG — xem scripts/ui/screens/shop.gd
const SCENE_SHOP := "res://scenes/shop.tscn"
## Màn CREDIT — soundtrack + ghi công đội ngũ
const SCENE_CREDIT := "res://scenes/credit.tscn"
## Màn CHI TIẾT SỰ KIỆN — xem scripts/ui/screens/event.gd
const SCENE_EVENT := "res://scenes/event.tscn"

## ID event sẽ nạp khi vào màn Event (truyền trước khi gọi goto_event)
var _pending_event_id: StringName = &""
## (HỒ SƠ CÁ NHÂN nay là POPUP — xem PopupManager.POPUPS["profiler"])
## Lớp phủ chuyển cảnh: node giao diện (trang giấy, mực loang, fade, chặn input)
## được khai báo SẴN trong scene này — xem scripts/ui/widgets/common/scene_transition.gd
const SCENE_LOADING := "res://scenes/loading.tscn"
const LoadingScene := preload("res://scenes/loading.tscn")

var transition: CanvasLayer = null


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_init_transition()


func _init_transition() -> void:
	if transition != null:
		return
	transition = LoadingScene.instantiate() as CanvasLayer
	if transition == null:
		push_error("[SceneManager] Khong tao duoc %s" % SCENE_LOADING)
		return
	transition.name = "Loading"
	add_child(transition)


# ---------------------------------------------------------------------------
# API chính
# ---------------------------------------------------------------------------
func change_scene(path: String, record_history := true, style := "auto") -> void:
	if path.is_empty() or not ResourceLoader.exists(path):
		push_warning("[SceneManager] Scene không tồn tại: %s" % path)
		return

	# Nạp TRƯỚC scene: file .tscn có thể tồn tại nhưng THIẾU PHỤ THUỘC (bản export lọc thiếu
	# script/asset) ⇒ `change_scene_to_file` thất bại GIỮA hiệu ứng và bỏ mặc người chơi ở
	# màn cũ (đã gặp: export thiếu `scripts/tools/*` → bấm vào MÀN 1 không mở được màn chơi
	# trên Android). Nạp trước ⇒ lỗi rõ ràng, không đổi màn nửa vời.
	var packed := load(path) as PackedScene
	if packed == null:
		push_error("[SceneManager] Không nạp được scene '%s' (thiếu phụ thuộc trong bản export?)." % path)
		return

	if transition != null and transition.has_method("is_busy") and bool(transition.call("is_busy")):
		push_warning("[SceneManager] Đang có chuyển cảnh đang diễn ra, bỏ qua yêu cầu mới.")
		return

	var previous := current_scene_path()
	if record_history and not previous.is_empty() and previous != path:
		var screen: Variant = Svc.screen()
		if screen != null and screen.has_method("push_history"):
			screen.call("push_history", previous)

	# Tự động xác định hiệu ứng nếu chọn "auto"
	var resolved_style := style
	if resolved_style == "auto":
		if not record_history:
			resolved_style = "page_turn_backward"
		elif path == SCENE_GAME:
			resolved_style = "ink_circle"
		else:
			resolved_style = "page_turn_forward"

	_play_transition_sfx(resolved_style)
	scene_changing.emit(path, previous)

	# Nếu chạy trong môi trường headless/test không cần frame render hoặc transition bị tắt
	var is_headless := DisplayServer.get_name() == "headless"
	if is_headless or transition == null or resolved_style == "none":
		get_tree().change_scene_to_packed(packed)
		scene_changed.emit(path)
		return

	# Chạy hiệu ứng mượt mà qua SceneTransition
	transition.call(
		"play_transition",
		path,
		func() -> void:
			get_tree().change_scene_to_packed(packed)
			scene_changed.emit(path),
		resolved_style
	)


## Đổi scene tức thì không cần hiệu ứng (dành cho test hoặc reset nhanh)
func change_scene_instant(path: String, record_history := true) -> void:
	change_scene(path, record_history, "none")


func is_transitioning() -> bool:
	return transition != null and transition.has_method("is_busy") and bool(transition.call("is_busy"))


func current_scene_path() -> String:
	var scene := get_tree().current_scene
	return scene.scene_file_path if scene != null else ""


func reload_current_scene() -> void:
	var path := current_scene_path()
	if not path.is_empty():
		change_scene(path, false)


# ---------------------------------------------------------------------------
# Lối tắt cho từng màn
# ---------------------------------------------------------------------------
func goto_main() -> void:
	change_scene(SCENE_MAIN)


func goto_splash() -> void:
	change_scene(SCENE_SPLASH, false)


func goto_title() -> void:
	change_scene(SCENE_TITLE, false)



## DEPRECATED — Levels đã GỘP vào Main: mở thẳng Main (bản đồ nằm trong Main).
func goto_levels() -> void:
	change_scene(SCENE_MAIN)


func goto_game() -> void:
	change_scene(SCENE_GAME)


func goto_daily() -> void:
	change_scene(SCENE_DAILY)


func goto_settings() -> void:
	change_scene(SCENE_SETTINGS)


func goto_achievement() -> void:
	change_scene(SCENE_ACHIEVEMENT)


func goto_ranking() -> void:
	change_scene(SCENE_RANKING)


func goto_shop() -> void:
	change_scene(SCENE_SHOP)


func goto_credit() -> void:
	change_scene(SCENE_CREDIT)


func goto_debug() -> void:
	change_scene(SCENE_DEBUG)


func is_debug_scene() -> bool:
	return current_scene_path() == SCENE_DEBUG


## Chuyển sang màn chi tiết sự kiện, truyền event_id để EventScene nạp đúng event.
func goto_event(event_id: StringName) -> void:
	_pending_event_id = event_id
	change_scene(SCENE_EVENT)


## Lấy event_id đang chờ (EventScene gọi khi _ready, sau đó xoá)
func consume_pending_event_id() -> StringName:
	var id := _pending_event_id
	_pending_event_id = &""
	return id


## Quay lại màn trước theo lịch sử ScreenManager.
## Hết lịch sử ⇒ về Main và KHÔNG ghi thêm lịch sử (nếu ghi, Back ở Main sẽ nhảy ngược lại
## màn vừa rời — lỗi "Back không về được" khi bấm liên tiếp).
func go_back() -> void:
	var screen: Node = Svc.screen()
	if screen != null and screen.has_method("pop_history"):
		var prev: String = screen.call("pop_history")
		if not prev.is_empty():
			change_scene(prev, false)
			return
	change_scene(SCENE_MAIN, false)


## Đang ở màn chính hay không (dùng cho luồng Back cứng Android)
func is_main_scene() -> bool:
	return current_scene_path() == SCENE_MAIN


func _play_transition_sfx(style: String) -> void:
	if style == "ink_circle":
		Sfx.play(Sfx.BTN_CLICK)
	else:
		Sfx.play(Sfx.PAGE_TURN)
